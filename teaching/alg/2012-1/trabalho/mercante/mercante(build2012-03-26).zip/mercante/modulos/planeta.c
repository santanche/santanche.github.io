#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "status.h"
#include "planeta.h"
#include "caixa.h"
#include "mercadoria.h"

static char* nomePlanetas[TOTAL_PLANETAS] = {
   "Mantor",
   "Zintor",
   "Asdropolis",
   "Zeta",
   "Bantor",
   "Tander",
   "Nova",
   "Pindora",
   "Castor",
   "Ra",
   "Re",
   "Ri"
};

static RegPlaneta dadosPlanetas[TOTAL_PLANETAS];

char** getNomePlanetas() {
   return nomePlanetas;
}

char* getNomePlaneta(TipoPlaneta planeta) {
   char *nPlaneta = "Desconhecido";
   if (planeta >= 0 || planeta < TOTAL_PLANETAS)
      nPlaneta = nomePlanetas[planeta];
   return nPlaneta;
}

void iGetNomePlanetas() {
   puts("\n+-----------------+");
   puts(  "|   [PLANETAS]    |");
   puts(  "| nn | planeta    |");
   puts(  "+----+------------+");
   int p;
   for (p = 0; p < TOTAL_PLANETAS; p++)
      printf("| %2d | %-10s |\n", p, nomePlanetas[p]);
   puts(  "+-----------------+");
}

RegPlaneta* getDadosPlanetas() {
   return dadosPlanetas;
}

void inicializaPlanetas() {
   RegMercadoria *dadosMercadorias = getDadosMercadorias();

   srand (time(NULL));

   int p;
   for (p = 0; p < TOTAL_PLANETAS; p++) {
      dadosPlanetas[p].mercadorias =
         malloc(sizeof(RegMercadoriaPlaneta)*TOTAL_MERCADORIAS);
      int m;
      for (m = 0; m < TOTAL_MERCADORIAS; m++) {
         dadosPlanetas[p].mercadorias[m].preco =
            dadosMercadorias[m].basePreco +
            (rand() % dadosMercadorias[m].variacaoPreco);
         dadosPlanetas[p].mercadorias[m].disponivel =
            dadosMercadorias[m].baseDisponivel +
            (rand() % dadosMercadorias[m].variacaoDisponivel);
      }
   }
}
