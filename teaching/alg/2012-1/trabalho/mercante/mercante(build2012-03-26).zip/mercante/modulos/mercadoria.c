#include <stdio.h>

#include "status.h"
#include "mercadoria.h"

static char* nomeMercadorias[TOTAL_MERCADORIAS] = {
   "cabeca",
   "corpo",
   "braco",
   "perna",
   "robo"
};

static RegMercadoria dadosMercadorias[TOTAL_MERCADORIAS] = {
   {50, 30, 7, 5},
   {80, 20, 12, 8},
   {30, 15, 15, 10},
   {40, 15, 12, 8},
   {450, 100, 5, 3}
};

static TipoMercadoria mercadoriaIndicada = merNada;

char** getNomeMercadorias() {
   return nomeMercadorias;
}

char* getNomeMercadoria(TipoMercadoria mercadoria) {
   char *nMercadoria = "Desconhecida";
   if (mercadoria >= 0 || mercadoria < TOTAL_MERCADORIAS)
      nMercadoria = nomeMercadorias[mercadoria];
   return nMercadoria;
}

RegMercadoria* getDadosMercadorias() {
   return dadosMercadorias;
}

int indicaMercadoria(TipoMercadoria mercadoria) {
   int status = STATUS_SUCESSO;
   if (mercadoria <= merNada || mercadoria >= TOTAL_MERCADORIAS)
      status = STATUS_MERCADORIA_INEXISTENTE;
   else
      mercadoriaIndicada = mercadoria;
   return status;
}

void iIndicaMercadoria() {
   int nMercadoria;
   puts("\n>>>>>>>>>>");
   printf("> mercadoria a indicar: ");
   scanf("%d", &nMercadoria);

   int status = indicaMercadoria(nMercadoria);
   if (status == STATUS_SUCESSO)
      puts("> Mercadoria indicada com sucesso.");
   else if (status == STATUS_MERCADORIA_INEXISTENTE)
      puts("> A mercadoria indicada nao existe.");

   puts(">>>>>>>>>>");
}

TipoMercadoria getMercadoriaIndicada() {
   return mercadoriaIndicada;
}

char* getNomeMercadoriaIndicada() {
   if (mercadoriaIndicada != merNada)
      return nomeMercadorias[mercadoriaIndicada];
   else
      return "";
}
