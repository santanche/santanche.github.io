#include "caixa.h"
#include "mercadoria.h"
#include "planeta.h"
#include "robo.h"

void programa() {
   viaja(plaTander);
   indicaMercadoria(merBraco);
   compraMercadoria(5);
   viaja(plaBantor);
   vendeMercadoria(5);
}
