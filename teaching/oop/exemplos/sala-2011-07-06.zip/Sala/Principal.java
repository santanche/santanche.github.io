public class Principal
{
    public static void main(String args[])
    {
    	new Relogio();
    	
    	try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
