package exemplos.html;

import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class HtmlToJsVar extends JFrame
{

    private static final long serialVersionUID = 1L;
    private JPanel jContentPane = null;
    private JLabel variableLabel = null;
    private JTextField variableField = null;
    private JLabel htmlLabel = null;
    private JTextArea htmlField = null;
    private JButton transformButton = null;
    private JLabel resultLabel = null;
    private JButton clearButton = null;
    private JTextArea resultField = null;
    /**
     * This method initializes variableField	
     * 	
     * @return javax.swing.JTextField	
     */
    private JTextField getVariableField()
    {
        if (variableField == null) {
            variableField = new JTextField();
        }
        return variableField;
    }

    /**
     * This method initializes htmlField	
     * 	
     * @return javax.swing.JTextArea	
     */
    private JTextArea getHtmlField()
    {
        if (htmlField == null) {
            htmlField = new JTextArea();
        }
        return htmlField;
    }

    /**
     * This method initializes transformButton	
     * 	
     * @return javax.swing.JButton	
     */
    private JButton getTransformButton()
    {
        if (transformButton == null) {
            transformButton = new JButton();
            transformButton.setText("Transform");
            transformButton.setPreferredSize(new Dimension(94, 15));
            transformButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent e)
                {
                    String html = htmlField.getText();
                    String code = "var " + variableField.getText() + " = \"\" +\r\n    \"";
                    char htmlChar[] = html.toCharArray();
                    for (int c = 0; c < htmlChar.length; c++) {
                        if (htmlChar[c] == '\r' || htmlChar[c] == '\n')
                        {
                            String returnChars = "" + htmlChar[c];
                            if (c+1 < htmlChar.length && htmlChar[c+1] == '\n') {
                                returnChars += htmlChar[c+1];
                                c++;
                            }
                            code += " \" + " + returnChars + "    \"";
                        }
                        else if (htmlChar[c] == '\"')
                            code += "'";
                        else
                            code += htmlChar[c];
                    }
                    code += "\";";
                    resultField.setText(code);
                }
            });
        }
        return transformButton;
    }

    /**
     * This method initializes clearButton	
     * 	
     * @return javax.swing.JButton	
     */
    private JButton getClearButton()
    {
        if (clearButton == null) {
            clearButton = new JButton();
            clearButton.setText("Clear");
            clearButton.setPreferredSize(new Dimension(64, 15));
            clearButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent e)
                {
                    variableField.setText("");
                    htmlField.setText("");
                    resultField.setText("");
                }
            });
        }
        return clearButton;
    }

    /**
     * This method initializes resultField	
     * 	
     * @return javax.swing.JTextArea	
     */
    private JTextArea getResultField()
    {
        if (resultField == null) {
            resultField = new JTextArea();
        }
        return resultField;
    }

    /**
     * @param args
     */
    public static void main(String[] args)
    {
        // TODO Auto-generated method stub

        SwingUtilities.invokeLater(new Runnable() {
            public void run()
            {
                HtmlToJsVar thisClass = new HtmlToJsVar();
                thisClass.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                thisClass.setVisible(true);
            }
        });
    }

    /**
     * This is the default constructor
     */
    public HtmlToJsVar()
    {
        super();
        initialize();
    }

    /**
     * This method initializes this
     * 
     * @return void
     */
    private void initialize()
    {
        this.setSize(300, 200);
        this.setContentPane(getJContentPane());
        this.setTitle("JFrame");
    }

    /**
     * This method initializes jContentPane
     * 
     * @return javax.swing.JPanel
     */
    private JPanel getJContentPane()
    {
        if (jContentPane == null) {
            resultLabel = new JLabel();
            resultLabel.setText("JavaScript code");
            htmlLabel = new JLabel();
            htmlLabel.setText("JavaScript variable");
            variableLabel = new JLabel();
            variableLabel.setText("HTML");
            GridLayout gridLayout = new GridLayout();
            gridLayout.setRows(4);
            gridLayout.setColumns(4);
            jContentPane = new JPanel();
            jContentPane.setLayout(gridLayout);
            jContentPane.add(htmlLabel, null);
            jContentPane.add(getVariableField(), null);
            jContentPane.add(variableLabel, null);
            jContentPane.add(getHtmlField(), null);
            jContentPane.add(getTransformButton(), null);
            jContentPane.add(getClearButton(), null);
            jContentPane.add(resultLabel, null);
            jContentPane.add(getResultField(), null);
        }
        return jContentPane;
    }

}
