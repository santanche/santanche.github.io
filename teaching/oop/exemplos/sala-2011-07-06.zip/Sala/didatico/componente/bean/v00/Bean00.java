package didatico.componente.bean.v00;

public class Bean00
{
    private String primeiroNome = "",
                   sobrenome = "";
    
    public Bean00()
    {
        /* nada */
    }
    
    public String getPrimeiroNome()
    {
        return primeiroNome;
    }
    
    public void setPrimeiroNome(String primeiroNome)
    {
        this.primeiroNome = primeiroNome;
    }

    public String getSobrenome()
    {
        return sobrenome;
    }

    public void setSobrenome(String sobrenome)
    {
        this.sobrenome = sobrenome;
    }

    public String getNomeCompleto()
    {
        return primeiroNome + " " + sobrenome;
    }
}
