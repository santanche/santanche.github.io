package didatico.componente.bean.v01;

import java.awt.Graphics;

import javax.swing.JComponent;

public class Bean01 extends JComponent
{
    private static final long serialVersionUID = 5781308947502712863L;

    private int raio = 50;

    public Bean01()
    {
        super();
    }

    public int getRaio()
    {
        return raio;
    }

    public void setRaio(int raio)
    {
        this.raio = raio;
        repaint();
    }

    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        g.drawOval(10, 10, raio*2, raio*2);
    }
}
