package didatico.componente.peixe;

public interface ComidaSubject
{

	public void addAlimentaListener(AlimentaListener al);

	public void removeAlimentaListener(AlimentaListener al);

}