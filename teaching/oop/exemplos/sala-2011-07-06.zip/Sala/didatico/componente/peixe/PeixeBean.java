package didatico.componente.peixe;

import java.awt.BorderLayout;

import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JLabel;

public class PeixeBean extends JComponent implements AlimentaListener
{
    private static final long serialVersionUID = -489307313091162132L;

    private int idade = 1,
	            comida = 0;

	private JLabel imagemPeixe;

	public PeixeBean()
	{
		super();
		this.setLayout(new BorderLayout());

		imagemPeixe = new JLabel();
		this.add(imagemPeixe, BorderLayout.CENTER);
		atualizaImagem();
	}

	public int getIdade()
	{
		return idade;
	}

	public void setIdade(int idade)
	{
		this.idade = idade;
		atualizaImagem();
	}

	public void alimentaPerformed(AlimentaEvent evento)
	{
		alimenta();
	}

	public void alimenta()
	{
		comida++;
		if (comida >= 3) {
			setIdade(idade + 1);
			comida = 0;
		}
	}
	
	public String imagem()
	{
		if (idade <= 4)
			return "peixe" + idade + ".gif";
		else
			return "peixe4.gif";
	}

	private void atualizaImagem()
	{
		try {
			imagemPeixe.setIcon(new ImageIcon(
					PeixeBean.class.getResource("imagem/" + imagem())));
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
