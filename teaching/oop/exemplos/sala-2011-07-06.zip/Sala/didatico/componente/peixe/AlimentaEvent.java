package didatico.componente.peixe;

import java.awt.Event;

public class AlimentaEvent extends Event
{
    private static final long serialVersionUID = -5573100287996877898L;
    
    public static int ALIMENTOU = 1;
	
	public AlimentaEvent(Object target, int id, Object arg)
	{
		super(target, id, arg);
	}

	public AlimentaEvent(Object target, long when, int id, int x, int y, int key, int modifiers, Object arg)
	{
		super(target, when, id, x, y, key, modifiers, arg);
	}

	public AlimentaEvent(Object target, long when, int id, int x, int y, int key, int modifiers)
	{
		super(target, when, id, x, y, key, modifiers);
	}
}
