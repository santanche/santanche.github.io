package didatico.componente.peixe;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.EventListener;

import javax.swing.JButton;
import javax.swing.event.EventListenerList;

public class ComidaBean extends JButton implements ComidaSubject, ActionListener
{
    private static final long serialVersionUID = 3650942307796042575L;

    private EventListenerList listaEscutas = new EventListenerList();

    public ComidaBean()
    {
        super();
        setText("Alimenta");
        addActionListener(this);
    }

    public void addAlimentaListener(AlimentaListener al)
    {
        listaEscutas.add(AlimentaListener.class, al);
    }

    public void removeAlimentaListener(AlimentaListener al)
    {
        listaEscutas.remove(AlimentaListener.class, al);
    }

    protected synchronized void fireAlimentaEvent()
    {
        EventListener le[] = listaEscutas.getListeners(AlimentaListener.class);

        if (le != null) {
            for (int i = 0; i < le.length; i++)
                ((AlimentaListener)le[i]).alimentaPerformed(
                        new AlimentaEvent(this, AlimentaEvent.ALIMENTOU, ""));
        }
    }

    public void actionPerformed(ActionEvent evento)
    {
        fireAlimentaEvent();
    }
}
