package didatico.componente.peixe;

import java.util.EventListener;

public interface AlimentaListener extends EventListener
{
    public void alimentaPerformed(AlimentaEvent evento);
}
