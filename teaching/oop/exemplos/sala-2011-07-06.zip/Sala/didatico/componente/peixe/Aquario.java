package didatico.componente.peixe;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class Aquario extends JFrame
{

	private static final long serialVersionUID = 1L;

	private JPanel jContentPane = null;

	private PeixeBean oPeixe = null;

	private ComidaBean aComida = null;

	/**
	 * This method initializes oPeixe	
	 * 	
	 * @return didatico.componente.peixe.PeixeBean	
	 */
	private PeixeBean getOPeixe() {
		if (oPeixe == null) {
			oPeixe = new PeixeBean();
			oPeixe.setIdade(1);
		}
		return oPeixe;
	}

	/**
	 * This method initializes aComida	
	 * 	
	 * @return didatico.componente.peixe.ComidaBean	
	 */
	private ComidaBean getAComida() {
		if (aComida == null) {
			aComida = new ComidaBean();
		}
		return aComida;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				Aquario thisClass = new Aquario();
				thisClass.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				thisClass.setVisible(true);
			}
		});
	}

	/**
	 * This is the default constructor
	 */
	public Aquario() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(372, 326);
		this.setContentPane(getJContentPane());
		this.setTitle("JFrame");
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(new BorderLayout());
			jContentPane.add(getOPeixe(), BorderLayout.CENTER);
			jContentPane.add(getAComida(), BorderLayout.SOUTH);
			
			aComida.addAlimentaListener(oPeixe);
		}
		return jContentPane;
	}

}  //  @jve:decl-index=0:visual-constraint="10,10"
