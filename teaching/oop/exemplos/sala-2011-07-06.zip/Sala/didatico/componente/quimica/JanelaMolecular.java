package didatico.componente.quimica;

import javax.swing.SwingUtilities;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JFrame;
import chemaxon.marvin.beans.MViewPane;
import javax.swing.JButton;
import java.awt.Dimension;

public class JanelaMolecular extends JFrame
{

	private static final long serialVersionUID = 1L;

	private JPanel jContentPane = null;

	private MViewPane aMolecula = null;

	private JButton oBotao = null;

	/**
	 * This method initializes aMolecula	
	 * 	
	 * @return chemaxon.marvin.beans.MViewPane	
	 */
	private MViewPane getAMolecula() {
		if (aMolecula == null) {
			aMolecula = new MViewPane();
			aMolecula.setParams("#\n# MarvinSketch and MarvinView properties\n#\nsketchHelp=chemaxon/marvin/help/sketch-index.html\nsketchQuickHelp=chemaxon/marvin/help/sketch.html\nviewQuickHelp=chemaxon/marvin/help/view.html\nviewHelp=chemaxon/marvin/help/view-index.html\n# background=#cccccc\nsketchMolbg=#ffffff\nsketchMolbg3d=#000000\nviewMolbg2d=#ffffff\nviewMolbg3d=#000000\natomstrings=smarts,alias,pseudo\nqueryatoms=any,arom,conn,H,hetero,list,notlist,Rgroup,rings,srs,val,mdl_subst,mdl_rbcnt,mdl_unsat,imp_hs,exp_conn\nextrabonds=arom,wedge,either,ctu,any,1or2,aromany,ez,topology\n# xtmpls=chemaxon/marvin/templates/wedgebonds.t\nttmpls0=*Generic*chemaxon/marvin/templates/generic.t\nttmpls1=*Rings*chemaxon/marvin/templates/rings.t\n# ttmpls2=*Bond Types*chemaxon/marvin/templates/extrabonds.t\ntmpls128=*My Templates*chemaxon/marvin/templates/custom.t\ntmpls0=*Amino Acids*chemaxon/marvin/templates/aminoacids.t\ntmpls1=*Aromatics*chemaxon/marvin/templates/aromatics.t\ntmpls2=*Bicycles*chemaxon/marvin/templates/bicycles.t\ntmpls3=*Bridged Polycycles*chemaxon/marvin/templates/bridged_polycycles.t\ntmpls4=*Crown Ethers*chemaxon/marvin/templates/crown_ethers.t\ntmpls5=*Cycloalkanes*chemaxon/marvin/templates/cycloalkanes.t\ntmpls6=*Heterocycles*chemaxon/marvin/templates/heterocycles.t\ntmpls7=*Polycyclics*chemaxon/marvin/templates/polycyclics.t\n# gives the Tools menu configuration file names \n# in the marvin root directory\n# toolfiles=chemaxon/marvin/calculations/plugins.properties,test/pp.properties\n#\n# MarvinView properties\n#\n mol=file:///H:/lab/java/javabeans/marvin/caffeine.smi");
		}
		return aMolecula;
	}

	/**
	 * This method initializes oBotao	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getOBotao() {
		if (oBotao == null) {
			oBotao = new JButton();
			oBotao.setText("Anima��o");
			oBotao.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					aMolecula.setAnimated(true);
				}
			});
		}
		return oBotao;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				JanelaMolecular thisClass = new JanelaMolecular();
				thisClass.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				thisClass.setVisible(true);
			}
		});
	}

	/**
	 * This is the default constructor
	 */
	public JanelaMolecular() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(300, 227);
		this.setContentPane(getJContentPane());
		this.setTitle("JFrame");
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(new BorderLayout());
			jContentPane.add(getAMolecula(), BorderLayout.CENTER);
			jContentPane.add(getOBotao(), BorderLayout.SOUTH);
		}
		return jContentPane;
	}

}  //  @jve:decl-index=0:visual-constraint="10,10"
