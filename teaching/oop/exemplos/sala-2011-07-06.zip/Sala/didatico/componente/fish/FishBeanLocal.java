package didatico.componente.fish;

public class FishBeanLocal implements FishLocal
{

    /*   .  _
         |\/O\
         |/\_/
         
         .    __
         |\  /  \
         | \/  0 \
         | /\    /
         |/  \__/
         
         .      ____
         |\    /    \
         | \  /    O \
         |  \/        \
         |  /\        /
         | /  \      /
         |/    \____/
     */

    private int age = 1;
    
    public int getAge()
    {
        return age;
    }
    
    public void setAge(int age)
    {
        this.age = age;
    }
    
    public String fishImage()
    {
        String image;
        
        switch (age)
        {
            case 1 : image = ".  _\n" +
                             "|\\/O\\\n" +
                             "|/\\_/\n";
                     break;
            case 2 : image = ".    __\n" +
                             "|\\  /  \\\n" +
                             "| \\/  0 \\\n" +
                             "| /\\    /\n" +
                             "|/  \\__/\n";
                     break;
            default : image = ".      ____\n" +
                              "|\\    /    \\\n" +
                              "| \\  /    O \\\n" +
                              "|  \\/        \\\n" +
                              "|  /\\        /\n" +
                              "| /  \\      /\n" +
                              "|/    \\____/\n";
        }
        
        return image;
    }
    
    public void grow()
    {
        age = (age < 3) ? age + 1 : age;
    }

}
