package didatico.componente.fish;

public interface FishLocal
{
    public int getAge();
    public void setAge(int age);
    public String fishImage();
    public void grow();
}
