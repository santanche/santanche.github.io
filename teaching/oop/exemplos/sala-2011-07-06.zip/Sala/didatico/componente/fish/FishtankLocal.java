package didatico.componente.fish;

public class FishtankLocal
{

    public static void main(String[] args)
    {
        FishLocal theFish = new FishBeanLocal();
        
        System.out.println(theFish.fishImage());
        theFish.grow();
        System.out.println(theFish.fishImage());
        theFish.grow();
        System.out.println(theFish.fishImage());
    }

}
