package didatico.componente.sistema.compframe;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletRequest;

import didatico.componente.sistema.compframe.exception.DataObjectException;
import didatico.componente.sistema.compframe.exception.InvalidFieldException;

public interface DataInterface extends Cloneable
{
    public Object clone() throws CloneNotSupportedException;

    public String tableName();
    public String keyFieldName();
    public String[] displayFields();
    public boolean autoIncrementKey();
    
    public String getKey();
    public void setKey(String key);

    public void toObject(ResultSet result) throws SQLException;
    public void toObject(ServletRequest request) throws InvalidFieldException;
    
    public String toSQLInsert();
    public String toSQLUpdate();
    
    public boolean validateFields() throws DataObjectException;
}
