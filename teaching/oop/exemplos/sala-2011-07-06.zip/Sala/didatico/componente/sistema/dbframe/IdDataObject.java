package didatico.componente.sistema.dbframe;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletRequest;

import didatico.componente.sistema.dbframe.exception.DataObjectException;
import didatico.componente.sistema.dbframe.exception.DuplicateKeyException;
import didatico.componente.sistema.dbframe.exception.EmptyFieldException;
import didatico.componente.sistema.dbframe.exception.InvalidFieldException;


/*
 * Created on 29/04/2005
 *
 */

/**
 * @author Simone Almeida Chaves Santanch�
 *
 */
public abstract class IdDataObject extends DataObject
{
    protected boolean autoIncrementKey()
    {
        return false;
    }
    
    private String id = null;
    
    public IdDataObject()
    {
        super();
    }
    
    public IdDataObject(String id)
    {
        super();
        this.id = id;
    }
    
    /**
     * @return Returns the id.
     */
    public String getId()
    {
        return id;
    }
    
    /**
     * @param id The id to set.
     */
    public void setId(String id)
    {
        if (!autoIncrementKey())
            this.id = id;
    }
    
    /* (non-Javadoc)
     * @see DatabaseObject#toObject(java.sql.ResultSet)
     */
    protected void toObject(ResultSet result) throws SQLException
    {
        if (autoIncrementKey())
            id = Integer.toString(result.getInt(keyFieldName()));
        else
            id = result.getString(keyFieldName());
    }

    /* (non-Javadoc)
     * @see dbframe.DataObject#toObject(javax.servlet.ServletRequestWrapper)
     */
    public void toObject(ServletRequest request) throws InvalidFieldException
    {
        if (!autoIncrementKey())
            id = request.getParameter("id");
    }
    
    /* (non-Javadoc)
     * @see kdb.DatabaseObject#getDB(java.lang.String)
     */
    public void getDB(String id) throws SQLException
    {
        if (!autoIncrementKey())
            super.getDB(id);
        else
            getDBSQL("SELECT * " +
                    "FROM " + tableName() + " " +
                    "WHERE " + keyFieldName() + " = " + id);
    }

    /* (non-Javadoc)
     * @see dbframe.DataObject#insertDB()
     */
    public void insertDB() throws SQLException, DataObjectException
    {
        validateFields();
        verifyDuplicated();        
        actionDB((autoIncrementKey()) ?
                     "INSERT INTO " + tableName() + " () VALUES ()" :
                     "INSERT INTO " + tableName() + " VALUES ('" + id + "')");
    }
    
    /* (non-Javadoc)
     * @see dbframe.DataObject#updateDB()
     */
    public void updateDB() throws SQLException, DataObjectException
    {
        validateFields();
    }

    /**
     * Validate object fields.
     * @throws SQLException
     * @throws DataObjectException
     */
    protected void validateFields() throws DataObjectException
    {
        if (!autoIncrementKey() && empty(id))
            throw new EmptyFieldException("identification");
    }
    
    /**
     * Verify duplicated key.
     * @throws SQLException
     * @throws DataObjectException
     */
    protected void verifyDuplicated() throws SQLException, DataObjectException
    {
        if (!autoIncrementKey())
        {
            IdDataObject sdo = null;
            try {
                sdo = (IdDataObject)this.clone();
                sdo.setId(null);
                sdo.getDBSQL("SELECT * " +
                             "FROM " + tableName() + " " +
                             "WHERE UPPER(" + keyFieldName() + ") = '" + id.toUpperCase() + "'");
            } catch (CloneNotSupportedException e) {
                /* nothing */
            }
            if (sdo != null && sdo.getId() != null)
                throw new DuplicateKeyException();
        }
    }
    
    /* (non-Javadoc)
     * @see dbframe.DataObject#deleteDB()
     */
    public void deleteDB() throws SQLException
    {
        if (autoIncrementKey())
            actionDB("DELETE FROM " + tableName() + " " +
                    "WHERE " + keyFieldName() + " = " + id);
        else
            actionDB("DELETE FROM " + tableName() + " " +
                    "WHERE " + keyFieldName() + " = '" + id + "'");
    }
}