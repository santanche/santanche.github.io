package didatico.componente.sistema.compobj;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletRequest;

import didatico.componente.sistema.compframe.DataInterface;
import didatico.componente.sistema.compframe.exception.DataObjectException;
import didatico.componente.sistema.compframe.exception.EmptyFieldException;
import didatico.componente.sistema.compframe.exception.InvalidFieldException;


/*
 * Created on 29/04/2005
 *
 */

public abstract class IdDataObject implements Cloneable, DataInterface
{
    public Object clone() throws CloneNotSupportedException
    {
        return super.clone();
    }
    
    public boolean autoIncrementKey()
    {
        return false;
    }
    
    private String id = null;
    
    public IdDataObject()
    {
        super();
    }
    
    public IdDataObject(String id)
    {
        super();
        this.id = id;
    }
    
    public String getKey()
    {
    	return getId();
    }
    
    public void setKey(String key)
    {
    	setId(key);
    }
    
    /**
     * @return Returns the id.
     */
    public String getId()
    {
        return id;
    }
    
    /**
     * @param id The id to set.
     */
    public void setId(String id)
    {
        if (!autoIncrementKey())
            this.id = id;
    }
    
    public void toObject(ResultSet result) throws SQLException
    {
        if (autoIncrementKey())
            id = Integer.toString(result.getInt(keyFieldName()));
        else
            id = result.getString(keyFieldName());
    }

    public void toObject(ServletRequest request) throws InvalidFieldException
    {
        if (!autoIncrementKey())
            id = request.getParameter("id");
    }
    
    public String toSQLInsert()
    {
    	return (autoIncrementKey()) ?
                "INSERT INTO " + tableName() + " () VALUES ()" :
                    "INSERT INTO " + tableName() + " VALUES ('" + id + "')";
    }
    
    public String toSQLUpdate()
    {
        return "";
    }

    /**
     * Validate object fields.
     * @throws SQLException
     * @throws DataObjectException
     */
    public boolean validateFields() throws DataObjectException
    {
        if (!autoIncrementKey() && empty(id))
            throw new EmptyFieldException("identification");
        return true;
    }
    
    public static boolean empty(String field)
    {
        return (field == null) ? true : (field.trim().length() == 0) ? true : false;
    }
}