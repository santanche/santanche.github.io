/*
 * Created on 20/04/2005
 *
 */
package didatico.componente.sistema.reference;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletRequest;

import didatico.componente.sistema.dbframe.IdDataObject;
import didatico.componente.sistema.dbframe.exception.DataObjectException;
import didatico.componente.sistema.dbframe.exception.EmptyFieldException;
import didatico.componente.sistema.dbframe.exception.InvalidFieldException;

public class Person extends IdDataObject
{
    protected String tableName()
    {
        return "PERSON";
    }
    
    protected String keyFieldName()
    {
        return "PERSON_ID";
    }
    
    public String[] displayFields()
    {
        String f[] = {"Identification",
                      "Name"};
        return f;
    }
    
    private String name = null,
                   password = null;
    
    /**
     * 
     */
    public Person()
    {
        super();
    }

    /**
     * @param id
     * @param name
     * @param password
     */
    public Person(String id, String name, String password)
    {
        super(id);
        this.name = name;
        this.password = password;
    }
    
    /**
     * @return Returns the name.
     */
    public String getName()
    {
        return name;
    }
    /**
     * @param name The name to set.
     */
    public void setName(String name)
    {
        this.name = name;
    }
    /**
     * @return Returns the password.
     */
    public String getPassword()
    {
        return password;
    }
    /**
     * @param password The password to set.
     */
    public void setPassword(String password)
    {
        this.password = password;
    }
    
    /* (non-Javadoc)
     * @see dbframe.DataObject#toObject(java.sql.ResultSet)
     */
    protected void toObject(ResultSet result) throws SQLException
    {
        super.toObject(result);
        name = result.getString("NAME");
        password = result.getString("PASSWORD");
    }
    
    /* (non-Javadoc)
     * @see dbframe.DataObject#toObject(javax.servlet.ServletRequestWrapper)
     */
    public void toObject(ServletRequest request) throws InvalidFieldException
    {
        super.toObject(request);
        name = request.getParameter("name");
        password = request.getParameter("password");
        String password2 = request.getParameter("password2");
        if (password != null && !password.equals(password2)) {
            password = null;
            throw new InvalidFieldException("Passwords do not match.");
        }
    }

    /* (non-Javadoc)
     * @see dbframe.DataObject#insertDB()
     */
    public void insertDB() throws SQLException, DataObjectException
    {
        validateFields();
        verifyDuplicated();
        actionDB("INSERT INTO PERSON VALUES (" +
                 "'" + getId() + "', " +
                 "'" + name + "', " +
                 "'" + password + "')");
    }

    /* (non-Javadoc)
     * @see dbframe.DataObject#updateDB()
     */
    public void updateDB() throws SQLException, DataObjectException
    {
        validateFields();
        actionDB("UPDATE PERSON " +
                 "SET NAME = '" + name + "', " +
                 "PASSWORD = '" + password + "' " +
                 "WHERE PERSON_ID = '" + getId() + "'");
    }

    /**
     * Validate object fields.
     * @throws SQLException
     * @throws DataObjectException
     */
    protected void validateFields() throws DataObjectException
    {
        super.validateFields();
        if (empty(name))
            throw new EmptyFieldException("name");
        else if (empty(password))
            throw new EmptyFieldException("password");
    }
}
