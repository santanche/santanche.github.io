package didatico.componente.sistema.compframe;

public interface IdInterface extends DataInterface
{
    public String getId();
    public void setId(String id);
}
