package didatico.componente.sistema.compframe;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/*
 * Created on 14/04/2005
 *
 */

public class Database
{
    private static Connection conn = null;
    
    public static Connection getConnection() throws SQLException
    {
        if (conn == null)
            try {
                Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
                conn = DriverManager.getConnection("jdbc:derby:C:\\Andre\\eclipse\\Sala\\didatico\\componente\\sistema\\db\\referencedb", "", "");
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }

        return conn;
    }
    
    public static void closeConnection() throws SQLException
    {
        if (conn != null) {
            conn.close();
            conn = null;
        }
    }
}
