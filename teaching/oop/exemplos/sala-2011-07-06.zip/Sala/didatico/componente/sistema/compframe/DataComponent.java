package didatico.componente.sistema.compframe;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletRequest;

import didatico.componente.sistema.compframe.exception.DataObjectException;
import didatico.componente.sistema.compframe.exception.DuplicateKeyException;
import didatico.componente.sistema.compframe.exception.InvalidFieldException;

/*
 * Created on 14/04/2005
 *
 */

public class DataComponent implements IDataComponent
{
    private DataInterface handledObj;
	
    public String[] displayFields()
    {
    	return handledObj.displayFields();
    }
    
    private DataComponent(DataInterface handledObj)
    {
    	this.handledObj = handledObj;
    }
    
    /**
     * Transforms a current record of a ResultSet in the an object of the class
     * whose <code>toObject</code> method is declared.
     * @param result  the source ResultSet
     * @throws SQLException
     */
    protected void toObject(ResultSet result) throws SQLException
    {
    	handledObj.toObject(result);
    }

    public void toObject(ServletRequest request) throws InvalidFieldException
    {
    	handledObj.toObject(request);
    }
    
    /**
     * Retrieve an record of the database using the <code>sql</code> parameter
     * and transforms it in the current object content.
     * Retrieves only one object (the first resulted of the SQL query).
     * @param sql  SQL sentence to retrive an desired record.
     */
    public static IDataComponent create(String sql, DataInterface handledObj) throws SQLException
    {
    	DataComponent newDC = new DataComponent(handledObj);
        if (sql != null) {
            Connection conn = Database.getConnection();
            Statement stm = conn.createStatement();
            ResultSet result = stm.executeQuery(sql);
              
            boolean hasNext = result.next();
            if (hasNext)
                newDC.toObject(result);
            
            stm.close();
        }
        return newDC;
    }

    /* (non-Javadoc)
     * @see kdb.DatabaseObject#getDB(java.lang.String)
     */
    public static IDataComponent createById(String id, DataInterface handledObj) throws SQLException
    {
        if (handledObj.autoIncrementKey())
            return create("SELECT * " +
                          "FROM " + handledObj.tableName() + " " +
                          "WHERE " + handledObj.keyFieldName() + " = " + id,
                          handledObj);
        else
            return create("SELECT * " +
                    "FROM " + handledObj.tableName() + " " +
                    "WHERE " + handledObj.keyFieldName() + " = '" + id + "'",
                    handledObj);
    }
    
    /**
     * Stores <code>obj</code> in the database. 
     */
    public void insertDB() throws SQLException, DataObjectException
    {
        if (handledObj.validateFields() && verifyDuplicated())
            actionDB(handledObj.toSQLInsert());
    }
    
    /**
     * Updates <code>obj</code> in the database. 
     */
    public void updateDB() throws SQLException, DataObjectException
    {
        if (handledObj.validateFields())
            actionDB(handledObj.toSQLUpdate());
    }

    /**
     * Removes <code>obj</code> from the database. 
     */
    public void deleteDB() throws SQLException
    {
        if (handledObj.autoIncrementKey())
            actionDB("DELETE FROM " + handledObj.tableName() + " " +
                     "WHERE " + handledObj.keyFieldName() + " = " + handledObj.getKey());
        else
            actionDB("DELETE FROM " + handledObj.tableName() + " " +
                     "WHERE " + handledObj.keyFieldName() + " = '" + handledObj.getKey() + "'");
    }

    /**
     * Support method for <code>insertDB</code>, <code>updateDB</code>
     * and <code>deleteDB</code>  
     */
    protected void actionDB(String sql) throws SQLException
    {
        Connection conn = Database.getConnection();
        Statement stm = conn.createStatement();
        stm.executeUpdate(sql);
        stm.close();
    }
    
    /**
     * Verify duplicated key.
     * @throws SQLException
     * @throws DataObjectException
     */
    protected boolean verifyDuplicated() throws SQLException, DataObjectException
    {
        if (!handledObj.autoIncrementKey())
        {
            DataInterface sdo = null;
            try {
                sdo = (DataInterface)handledObj.clone();
                sdo.setKey(null);
                create("SELECT * " +
                       "FROM " + handledObj.tableName() + " " +
                       "WHERE UPPER(" + handledObj.keyFieldName() + ") = '" +
                       handledObj.getKey().toUpperCase() + "'",
                                             sdo);
            } catch (CloneNotSupportedException e) {
                // nothing
            }
            if (sdo != null && sdo.getKey() != null)
                throw new DuplicateKeyException();
        }
        return true;
    }
    
    protected String listSQL(String selection)
    {
        return "SELECT * FROM " + handledObj.tableName() + " WHERE " + selection;
    }
    
    protected String listSQL()
    {
        return "SELECT * FROM " + handledObj.tableName();
    }
}