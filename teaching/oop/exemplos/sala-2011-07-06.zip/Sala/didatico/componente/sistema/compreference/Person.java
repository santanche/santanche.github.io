/*
 * Created on 20/04/2005
 *
 */
package didatico.componente.sistema.compreference;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletRequest;

import didatico.componente.sistema.compframe.exception.DataObjectException;
import didatico.componente.sistema.compframe.exception.EmptyFieldException;
import didatico.componente.sistema.compframe.exception.InvalidFieldException;
import didatico.componente.sistema.compobj.IdDataObject;

public class Person extends IdDataObject
{
    public String tableName()
    {
        return "PERSON";
    }
    
    public String keyFieldName()
    {
        return "PERSON_ID";
    }
    
    public String[] displayFields()
    {
        String f[] = {"Identification",
                      "Name"};
        return f;
    }
    
    private String name = null,
                   password = null;
    
    /**
     * 
     */
    public Person()
    {
        super();
    }

    /**
     * @param id
     * @param name
     * @param password
     */
    public Person(String id, String name, String password)
    {
        super(id);
        this.name = name;
        this.password = password;
    }
    
    /**
     * @return Returns the name.
     */
    public String getName()
    {
        return name;
    }
    /**
     * @param name The name to set.
     */
    public void setName(String name)
    {
        this.name = name;
    }
    /**
     * @return Returns the password.
     */
    public String getPassword()
    {
        return password;
    }
    /**
     * @param password The password to set.
     */
    public void setPassword(String password)
    {
        this.password = password;
    }
    
    public void toObject(ResultSet result) throws SQLException
    {
        super.toObject(result);
        name = result.getString("NAME");
        password = result.getString("PASSWORD");
    }
    
    public void toObject(ServletRequest request) throws InvalidFieldException
    {
        super.toObject(request);
        name = request.getParameter("name");
        password = request.getParameter("password");
        String password2 = request.getParameter("password2");
        if (password != null && !password.equals(password2)) {
            password = null;
            throw new InvalidFieldException("Passwords do not match.");
        }
    }

    public String toSQLInsert()
    {
    	return "INSERT INTO PERSON VALUES (" +
               "'" + getId() + "', " +
               "'" + name + "', " +
               "'" + password + "')";
    }
    
    public String toSQLUpdate()
    {
        return "UPDATE PERSON " +
               "SET NAME = '" + name + "', " +
               "PASSWORD = '" + password + "' " +
               "WHERE PERSON_ID = '" + getId() + "'";
    }

    public boolean validateFields() throws DataObjectException
    {
        boolean status = super.validateFields();
        if (empty(name))
            throw new EmptyFieldException("name");
        else if (empty(password))
            throw new EmptyFieldException("password");
        return status;
    }
}
