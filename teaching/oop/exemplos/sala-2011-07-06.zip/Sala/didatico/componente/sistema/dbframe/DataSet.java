/*
 * Created on 15/04/2005
 *
 */
package didatico.componente.sistema.dbframe;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Enumeration;
import java.util.NoSuchElementException;


/**
 * @author Simone Almeida Chaves Santanch�
 *
 * Inner class that enumerates a set of DatabaseObjects.
 */
public class DataSet implements Enumeration
{
    Statement stat = null;
    ResultSet result = null;
    DataObject obj = null;
    
    boolean hasElement = false;
    
    public DataSet(DataObject obj)
    {
        if (obj != null)
            try {
                Connection conn = Database.getConnection();
                stat = conn.createStatement();
                result = stat.executeQuery(obj.listSQL());
               if (result != null) hasElement = result.next();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            
        this.obj = obj;
    }
    
    public Object nextElement() throws NoSuchElementException
    {
        DataObject newObj = null;
        
        if (result == null || obj == null)
            throw new NoSuchElementException();
        else try
        {
            if (!hasElement)
                throw new NoSuchElementException();
            else {
                newObj = (DataObject)obj.clone();
                newObj.toObject(result);
                hasElement = result.next();
            }
        } catch (SQLException e) {
            throw new NoSuchElementException(e.getMessage());
        } catch (CloneNotSupportedException e) {
            throw new NoSuchElementException(e.getMessage());
        }
        
        return newObj;
    }
    
    /* (non-Javadoc)
     * @see java.util.Enumeration#hasMoreElements()
     */
    public boolean hasMoreElements()
    {
        return hasElement;
    }
    
    public void close()
    {
        if (stat != null)
            try {
                stat.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
    }
}
