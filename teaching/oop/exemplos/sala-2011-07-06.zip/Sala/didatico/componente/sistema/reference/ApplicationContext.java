/*
 * Created on 28/04/2005
 *
 */
package didatico.componente.sistema.reference;

import didatico.componente.sistema.dbframe.DataObject;

/**
 * @author Simone Almeida Chaves Santanch�
 *
 */
public class ApplicationContext
{
    private Person user = null;
    private String table = null;
    private DataObject regClass = null,
                       regObj   = null;
    private String module = null;
    private String readonlyId     = "",
                   readonlyFields = "";
    
    public ApplicationContext()
    {
    }

    /**
     * @return Returns the user.
     */
    public Person getUser()
    {
        return user;
    }

    /**
     * @param user The user to set.
     */
    public void setUser(Person user)
    {
        this.user = user;
    }

    /**
     * @return Returns the table.
     */
    public String getTable()
    {
        return table;
    }

    /**
     * @param table The table to set.
     */
    public void setTable(String table)
    {
        this.table = table;
    }

    /**
     * @return Returns the dclass.
     */
    public DataObject getRegClass()
    {
        return regClass;
    }
    
    /**
     * @param regClass The regClass to set.
     */
    public void setRegClass(DataObject regClass)
    {
        this.regClass = regClass;
    }
    
    /**
     * @return Returns the dobj.
     */
    public DataObject getRegObj()
    {
        if (regObj == null && regClass != null)
            try {
                regObj = (DataObject)regClass.clone();
            } catch (CloneNotSupportedException e) {
            }
        return regObj;
    }

    /**
     * @param regObj The regObj to set.
     */
    public void setRegObj(DataObject regObj)
    {
        this.regObj = regObj;
    }
    
    /**
     * @return Returns the module.
     */
    public String getModule()
    {
        return module;
    }
    /**
     * @param module The module to set.
     */
    public void setModule(String module)
    {
        this.module = module;
    }
 
    /**
     * @return Returns the readonlyId.
     */
    public String getReadonlyId()
    {
        return readonlyId;
    }

    /**
     * @param readonlyId The readonlyId to set.
     */
    public void setReadonlyId(String readonlyId)
    {
        this.readonlyId = readonlyId;
    }

    /**
     * @return Returns the readonlyFields.
     */
    public String getReadonlyFields()
    {
        return readonlyFields;
    }

    /**
     * @param readonlyFields The readonlyFields to set.
     */
    public void setReadonlyFields(String readonlyFields)
    {
        this.readonlyFields = readonlyFields;
    }
}