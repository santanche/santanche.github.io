package didatico.componente.sistema.dbframe;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletRequest;

import didatico.componente.sistema.dbframe.exception.DataObjectException;
import didatico.componente.sistema.dbframe.exception.InvalidFieldException;

/*
 * Created on 14/04/2005
 *
 */

public abstract class DataObject implements Cloneable
{
    abstract protected String tableName();
    abstract protected String keyFieldName();
    abstract public String[] displayFields();

    public Object clone() throws CloneNotSupportedException
    {
        return super.clone();
    }
    
    /**
     * Transforms a current record of a ResultSet in the an object of the class
     * whose <code>toObject</code> method is declared.
     * @param result  the source ResultSet
     * @throws SQLException
     */
    abstract protected void toObject(ResultSet result) throws SQLException;

    abstract public void toObject(ServletRequest request) throws InvalidFieldException;
    
    /**
     * Retrieve an record of the database using the <code>sql</code> parameter
     * and transforms it in the current object content.
     * Retrieves only one object (the first resulted of the SQL query).
     * @param sql  SQL sentence to retrive an desired record.
     */
    public void getDBSQL(String sql) throws SQLException
    {
        if (sql != null) {
            Connection conn = Database.getConnection();
            Statement stm = conn.createStatement();
            ResultSet result = stm.executeQuery(sql);
              
            boolean hasNext = result.next();
            if (hasNext)
                toObject(result);
            
            stm.close();
        }
    }

    /* (non-Javadoc)
     * @see kdb.DatabaseObject#getDB(java.lang.String)
     */
    public void getDB(String id) throws SQLException
    {
        getDBSQL("SELECT * " +
                 "FROM " + tableName() + " " +
                 "WHERE " + keyFieldName() + " = '" + id + "'");
    }
    
    /**
     * Stores <code>obj</code> in the database. 
     */
    public abstract void insertDB() throws SQLException, DataObjectException;
    
    /**
     * Updates <code>obj</code> in the database. 
     */
    public abstract void updateDB() throws SQLException, DataObjectException;

    /**
     * Removes <code>obj</code> from the database. 
     */
    public abstract void deleteDB() throws SQLException;

    /**
     * Support method for <code>insertDB</code>, <code>updateDB</code>
     * and <code>deleteDB</code>  
     */
    protected void actionDB(String sql) throws SQLException
    {
        Connection conn = Database.getConnection();
        Statement stm = conn.createStatement();
        stm.executeUpdate(sql);
        stm.close();
    }
    
    protected String listSQL(String selection)
    {
        return "SELECT * FROM " + tableName() + " WHERE " + selection;
    }
    
    /* (non-Javadoc)
     * @see dbframe.DataObject#listSQL()
     */
    protected String listSQL()
    {
        return "SELECT * FROM " + tableName();
    }

    public static boolean empty(String field)
    {
        return (field == null) ? true : (field.trim().length() == 0) ? true : false;
    }
}