package didatico.componente.sistema.compframe;

import java.sql.SQLException;

import javax.servlet.ServletRequest;

import didatico.componente.sistema.compframe.exception.DataObjectException;
import didatico.componente.sistema.compframe.exception.InvalidFieldException;

public interface IDataComponent
{

	public String[] displayFields();

	public void toObject(ServletRequest request) throws InvalidFieldException;

	/**
	 * Stores <code>obj</code> in the database. 
	 */
	public void insertDB() throws SQLException, DataObjectException;

	/**
	 * Updates <code>obj</code> in the database. 
	 */
	public void updateDB() throws SQLException, DataObjectException;

	/**
	 * Removes <code>obj</code> from the database. 
	 */
	public void deleteDB() throws SQLException;

}