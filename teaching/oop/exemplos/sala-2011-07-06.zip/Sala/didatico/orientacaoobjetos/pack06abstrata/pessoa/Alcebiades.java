package didatico.orientacaoobjetos.pack06abstrata.pessoa;

public class Alcebiades extends Alguem
{
    public String getNome()
    {
        return "Alcebiades";
    }
}
