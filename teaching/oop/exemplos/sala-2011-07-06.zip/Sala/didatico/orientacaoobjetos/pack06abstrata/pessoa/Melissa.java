package didatico.orientacaoobjetos.pack06abstrata.pessoa;

public class Melissa extends Alguem
{
    public String getNome()
    {
        return "Melissa";
    }
}
