package didatico.orientacaoobjetos.pack06abstrata.pessoa;

public abstract class Alguem
{
    public abstract String getNome();
}
