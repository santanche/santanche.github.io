package didatico.orientacaoobjetos.pack07interface.tempo;

public interface Tempo
{
    public long quantidade();

    public String toString();
}
