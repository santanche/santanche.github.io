package didatico.orientacaoobjetos.pack04heranca.listaexercicios.l02q02;

import didatico.biblioteca.EntradaTecladoBasica;
import didatico.orientacaoobjetos.pack04heranca.listaexercicios.l02q01.Prova;
import didatico.orientacaoobjetos.pack04heranca.listaexercicios.l02q01.ProvaAluno;

public class Questao02
{
    public static final int NUMERO_ALUNOS = 15;
    
    public static void calculaMedia(char respostasCorretas[])
    {
        double somaNotas = 0;

        for (int a = 1; a <= NUMERO_ALUNOS; a++)
        {
            ProvaAluno umaProva = new ProvaAluno();
            umaProva.setRespostasCorretas(respostasCorretas);
            
            System.out.println("Digite as resposta da prova " + a);
            for (int q = 1; q <= Prova.NUMERO_QUESTOES; q++)
            {
                System.out.print("Questao " + q + ": ");
                char resposta = EntradaTecladoBasica.leiaChar();
                umaProva.respostaAluno(resposta);
            }
            
            System.out.println("Este aluno tirou: " + umaProva.nota());
            somaNotas += umaProva.nota();
        }
        
        System.out.println("\nMedia da turma: " +
                           (somaNotas / NUMERO_ALUNOS));
    }
    
    
    // este main nao faz parte da questao, eh soh para teste
    public static void main(String args[])
    {
        char respostasCorretas[] = {'c', 'a', 'b'};
        
        calculaMedia(respostasCorretas);
    }
}
