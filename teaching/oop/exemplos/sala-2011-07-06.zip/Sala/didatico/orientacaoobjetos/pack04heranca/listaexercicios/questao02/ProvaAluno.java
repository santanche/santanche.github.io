package didatico.orientacaoobjetos.pack04heranca.listaexercicios.questao02;

public class ProvaAluno extends Prova
{
    public static final int TOTAL_QUESTOES = 15;
    
    private char respAluno[];
    private int ultimaResposta;
    
    public ProvaAluno()
    {
        super();
        respAluno = new char[TOTAL_QUESTOES];
        ultimaResposta = 0;
    }
    
    public void respostaAluno(char aResposta)
    {
        if (ultimaResposta < TOTAL_QUESTOES) {
            respAluno[ultimaResposta] = aResposta;
            ultimaResposta++;
        }
    }
    
    public int acertos()
    {
        int qAcertos = 0;
        for (int q = 0; q < ultimaResposta; q++)
            if (respAluno[q] == respostaQuestao(q))
                qAcertos++;
        return qAcertos;
    }
    
    public double nota()
    {
        double aNota = 0;
        for (int q1 = 0; q1 < ultimaResposta && q1 < 10; q1++)
            if (respAluno[q1] == respostaQuestao(q1))
                aNota += .5;
        for (int q2 = 10; q2 < ultimaResposta; q2++)
            if (respAluno[q2] == respostaQuestao(q2))
                aNota++;
        
        return aNota;
    }
    
    public double maior(ProvaAluno outro)
    {
        int meusAcertos = acertos(),
            outroAcertos = outro.acertos();
        
        double minhaNota = nota(),
               outraNota = outro.nota();
        
        double aMaior = minhaNota;
        
        if (meusAcertos < outroAcertos)
            aMaior = outraNota;
        else if (meusAcertos == outroAcertos) {
            if (minhaNota < outraNota)
                aMaior = outraNota;
        }

        return aMaior;
    }
}
