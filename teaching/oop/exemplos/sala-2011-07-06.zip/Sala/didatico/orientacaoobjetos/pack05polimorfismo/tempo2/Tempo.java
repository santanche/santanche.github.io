package didatico.orientacaoobjetos.pack05polimorfismo.tempo2;

public class Tempo
{
  public long quantidade()
  {
    return 0;
  }

  public String toString()
  {
    return "";
  }

  public long diferenca(Tempo externo)
  {
    return quantidade() - externo.quantidade();
  }
}
