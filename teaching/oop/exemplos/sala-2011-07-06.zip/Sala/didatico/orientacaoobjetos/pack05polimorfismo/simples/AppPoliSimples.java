package didatico.orientacaoobjetos.pack05polimorfismo.simples;

public class AppPoliSimples
{
    public static void main(String args[])
    {
        Individuo i;
        
        i = new IndividuoImpl("Asdrubal", "Silva");
        
        System.out.println(Usuario.getNomeCompleto(i));
    }
}
