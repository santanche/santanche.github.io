package didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l05q04;

public interface MovimentoConta
{
    public String getCPFCorrentista();
    public float getValorMovimento();
}
