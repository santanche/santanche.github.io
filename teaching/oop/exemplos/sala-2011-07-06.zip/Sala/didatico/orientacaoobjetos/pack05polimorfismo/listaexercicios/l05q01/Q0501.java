package didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l05q01;

public class Q0501
{
    public static Resultado[] contabiliza(Animal a[], Ferramentas ferr)
    {
        String especies[] = ferr.classificaEspecies(a);
        
        Resultado result[] = new Resultado[especies.length];
        
        for (int e = 0; e < especies.length; e++)
        {
            Animal af[] = ferr.filtraEspecie(a, especies[e]);
            result[e] = new Resultado(especies[e], af.length);
        }
        
        return result;
    }
}
