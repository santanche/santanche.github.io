package didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l04q02a;

public class Pluviometro
{
    private static final String tipos[] =
        {"ordinario", "da pro gasto", "porradao"};
    private static final int pesoTipos[] =
        {50, 30, 25};
    private static final int capacidadeTipos[] =
        {10, 200, 1500};
	
	protected String tipo;
	
	private int peso = -1,
	            capacidade = -1;
    
    public Pluviometro(String tipo)
    {
    	this.tipo = tipo;
    	int t;
    	for (t = 0; t < tipos.length && !tipo.equalsIgnoreCase(tipos[t]); t++)
    	    /* nada */;
    	
    	if (t < tipos.length)
    	{
    		peso = pesoTipos[t];
    		capacidade = capacidadeTipos[t];
    	}
    }
    
    public String getTipo()
    {
    	return tipo;
    }
    
    public int getPeso()
    {
    	return peso;
    }
    
    public int getCapacidade()
    {
    	return capacidade;
    }
}
