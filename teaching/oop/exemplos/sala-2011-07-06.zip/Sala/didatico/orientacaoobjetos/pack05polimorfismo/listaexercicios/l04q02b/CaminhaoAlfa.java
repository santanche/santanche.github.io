package didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l04q02b;

import java.util.Vector;

public class CaminhaoAlfa extends Caminhao
{
    private Vector<Pluviometro> osPluviometros;
    private int somaPeso = 0;
    
    public CaminhaoAlfa(int quantidade)
    {
        super(quantidade);
        osPluviometros = new Vector<Pluviometro>();
    }
    
    public void inserePluviometro(Pluviometro novo)
    {
        if (somaPeso + novo.getPeso() < 5000)
        {
            osPluviometros.addElement(novo);
            somaPeso += novo.getPeso();
        }
    }
}
