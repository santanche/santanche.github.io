package didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l05q04;

public class Questao04
{
    public void atualizaSaldos(Correntista vcorrentista[],
                               MovimentoConta vmovimento[],
                               OperacoesBanco operacoes)
    {
        for (int m = 0; m < vmovimento.length; m++)
        {
            String cpf = vmovimento[m].getCPFCorrentista(); 
            Correntista corr = 
                operacoes.encontraCorrentista(vcorrentista, cpf);
            if (corr != null) {
                float saldo = corr.getSaldo();
                saldo += vmovimento[m].getValorMovimento();
                corr.setSaldo(saldo);
            }
        }
    }
}
