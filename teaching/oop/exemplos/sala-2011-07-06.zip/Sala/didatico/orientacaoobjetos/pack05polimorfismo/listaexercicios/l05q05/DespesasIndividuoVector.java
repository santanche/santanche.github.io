package didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l05q05;

import java.util.Vector;

public class DespesasIndividuoVector
{
    private String cpf;
    private Vector<DespesaMes> despesas;
    
    public DespesasIndividuoVector(String cpf, Vector<DespesaMes> despesa)
    {
        this.cpf = cpf;
        this.despesas = despesa;
    }
    
    public String getCPF()
    {
        return cpf;
    }
    
    public DespesaMes totalizaMes(int mes)
    {
        float total = 0;
        
        for (int d = 0; d < despesas.size(); d++)
        {
            DespesaMes dm = despesas.get(d);
            if (dm.getMes() == mes)
                total += dm.getValor();
        }
        
        DespesaMes despesaTotal = new DespesaMes(mes, total);
        return despesaTotal;
    }
}
