package didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l05q03;

import didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l05q01.Animal;
import didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l05q02.ItemOrcamentoComplexo;

public interface AnimalOrcamento extends Animal
{
    public ItemOrcamentoComplexo orcamentoGastosAnimal();
}