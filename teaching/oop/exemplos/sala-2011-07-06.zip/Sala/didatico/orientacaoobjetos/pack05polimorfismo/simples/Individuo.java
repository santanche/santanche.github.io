package didatico.orientacaoobjetos.pack05polimorfismo.simples;

public interface Individuo
{
    public String getPrimeiroNome();
    public String getSobrenome();
}
