package didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l05q01compl;

import didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l05q01.Animal;

public class AnimalImpl implements Animal
{
    private String nomeEspecie;
    private String nomeAnimal;
    
    public AnimalImpl(String nomeEspecie, String nomeAnimal)
    {
        this.nomeEspecie = nomeEspecie;
        this.nomeAnimal = nomeAnimal;
    }
    
    public String getNomeEspecie()
    {
        return nomeEspecie;
    }

    public String getNomeAnimal()
    {
        return nomeAnimal;
    }
}
