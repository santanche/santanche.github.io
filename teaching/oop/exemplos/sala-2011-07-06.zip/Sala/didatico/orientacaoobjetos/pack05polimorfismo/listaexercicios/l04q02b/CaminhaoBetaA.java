package didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l04q02b;

import java.util.Vector;

public class CaminhaoBetaA extends Caminhao
{
    private Vector<Pluviometro> osPluviometros;
    
    public CaminhaoBetaA(int quantidade)
    {
        super(quantidade);
        osPluviometros = new Vector<Pluviometro>();
    }
    
    public void inserePluviometro(Pluviometro novo)
    {
        String tipoNovo = novo.getTipo();
        int tamanho = osPluviometros.size();
        int p;
        for (p = 0;
             p < tamanho &&
              !tipoNovo.equals(osPluviometros.elementAt(p).getTipo());
             p++)
            /* novo */ ;
        if (p == tamanho)
            osPluviometros.addElement(novo);
    }
}
