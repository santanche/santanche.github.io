package didatico.orientacaoobjetos.pack05polimorfismo.tempo1;

public class Tempo
{
    public long quantidade()
    {
        return 0;
    }

    public String toString()
    {
        return "";
    }
}
