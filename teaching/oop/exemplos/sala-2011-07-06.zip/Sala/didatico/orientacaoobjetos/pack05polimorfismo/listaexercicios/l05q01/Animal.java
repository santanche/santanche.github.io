package didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l05q01;

public interface Animal
{
    public String getNomeEspecie();
    public String getNomeAnimal();
}