package didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l05q06b;

public class AppQ06
{
    public CorrentistaDespesa[] filtra(CorrentistaDespesa origem[])
    {
        int d = 0;
        CorrentistaDespesa vetor[] = new CorrentistaDespesa[origem.length];
        
        for (int c = 0; c < origem.length; c++) {
            if (origem[c].getSaldo() >= 
                origem[c].getDespesasPrevistas().totalizaMes(3).getValor()) {
                vetor[d] = origem[c];
                d++;
            }
        }
        CorrentistaDespesa resultado[] = new CorrentistaDespesa[d];
        System.arraycopy(vetor, 0, resultado, 0, d);
        
        return vetor;
    }
}
