package didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l04q01;

//representa genericamente uma pessoa
public interface Pessoa
{
    public String getCPF(); // retorna o CPF da pessoa
    public String getNome();  // retorna o nome da pessoa
}