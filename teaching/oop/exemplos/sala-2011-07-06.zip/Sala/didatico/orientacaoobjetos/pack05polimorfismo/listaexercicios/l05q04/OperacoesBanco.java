package didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l05q04;

public interface OperacoesBanco
{
    public Correntista encontraCorrentista(
                          Correntista todosCorrentistas[],
                          String cpfProcurado);
}