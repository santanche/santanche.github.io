package didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l05q06;

import java.util.Vector;

import didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l05q05.DespesasIndividuo;

public class App0506
{
    public CorrentistaDespesa[] filtraCorrentistas(CorrentistaDespesa correntistas[])
    {
        Vector<CorrentistaDespesa> filtrados = new Vector<CorrentistaDespesa>();
        
        for (int c = 0; c < correntistas.length; c++)
        {
            DespesasIndividuo di = correntistas[c].getDespesasPrevistas();
            if (di.totalizaMes(3).getValor() <= correntistas[c].getSaldo())
                filtrados.add(correntistas[c]);
        }
        
        return filtrados.toArray(new CorrentistaDespesa[0]);
    }
}
