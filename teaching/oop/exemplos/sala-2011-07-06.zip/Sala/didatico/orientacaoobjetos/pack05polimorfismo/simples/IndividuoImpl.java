package didatico.orientacaoobjetos.pack05polimorfismo.simples;

public class IndividuoImpl implements Individuo
{
    private String primeiroNome, sobrenome;
    
    public IndividuoImpl(String primeiroNome, String sobrenome)
    {
        this.primeiroNome = primeiroNome;
        this.sobrenome = sobrenome;
    }
    
    public String getPrimeiroNome()
    {
        return primeiroNome;
    }
    
    public String getSobrenome()
    {
        return sobrenome;
    }
}
