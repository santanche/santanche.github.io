package didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l05q02;

public class ItemOrcamentoComplexo extends ItemOrcamento
{
    private ItemOrcamento subitens[];
    
    public ItemOrcamentoComplexo(String historico, float valor,
                                 ItemOrcamento subitens[])
    {
        super(historico, valor);
        this.subitens = subitens;
    }
    
    public float getValor()
    {
        float soma = 0;
        
        /*
        for (int i = 0; i < subitens.length; i++)
        {
            ItemOrcamento s = subitens[i];
            soma += s.getValor();
        }
        */
        
        for (ItemOrcamento s : subitens)
            soma += s.getValor();
        
        return soma;
    }
    
    public ItemOrcamento encontraItem(String historicoProcurado)
    {
        ItemOrcamento itemProcurado = null;
        
        for (int i = 0; i < subitens.length && itemProcurado == null; i++)
            if (historicoProcurado.equalsIgnoreCase(subitens[i].getHistorico()))
                itemProcurado = subitens[i];
        
        return itemProcurado;
    }

    public ItemOrcamento encontraItemRecursivo(String historicoProcurado)
    {
        ItemOrcamento itemProcurado = null;
        
        for (int i = 0; i < subitens.length && itemProcurado == null; i++)
            if (historicoProcurado.equalsIgnoreCase(subitens[i].getHistorico()))
                itemProcurado = subitens[i];
            else if (subitens[i] instanceof ItemOrcamentoComplexo)
                itemProcurado = ((ItemOrcamentoComplexo)subitens[i]).
                                   encontraItemRecursivo(historicoProcurado);
        
        return itemProcurado;
    }

}
