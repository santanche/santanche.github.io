package didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l04q02a;

public class CaminhaoBeta extends Caminhao
{
    private Pluviometro osPluviometros[];
    private int proximoLivre = 0;
    
    public CaminhaoBeta(int quantidade)
    {
        super(quantidade);
        osPluviometros = new Pluviometro[quantidade];
    }
    
    public void inserePluviometro(Pluviometro novo)
    {
        if (proximoLivre < osPluviometros.length)
        {
            String tipoNovo = novo.getTipo();
            int p;
            for (p = 0;
                 p < proximoLivre &&
                  !tipoNovo.equals(osPluviometros[p].getTipo());
                 p++)
                /* nada */ ;
            if (p == proximoLivre)
            {
                osPluviometros[proximoLivre] = novo;
                proximoLivre++;
            }
        }
    }
}
