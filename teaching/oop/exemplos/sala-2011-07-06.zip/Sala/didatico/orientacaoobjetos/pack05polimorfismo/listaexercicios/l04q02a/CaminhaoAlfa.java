package didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l04q02a;

public class CaminhaoAlfa extends Caminhao
{
    private Pluviometro osPluviometros[];
    private int proximoLivre = 0;
    private int somaPeso = 0;
    
    public CaminhaoAlfa(int quantidade)
    {
        super(quantidade);
        osPluviometros = new Pluviometro[quantidade];
    }
    
    public void inserePluviometro(Pluviometro novo)
    {
        if (proximoLivre < osPluviometros.length &&
            somaPeso + novo.getPeso() <= 5000)
        {
            osPluviometros[proximoLivre] = novo;
            proximoLivre++;
            somaPeso += novo.getPeso();
        }
    }
}
