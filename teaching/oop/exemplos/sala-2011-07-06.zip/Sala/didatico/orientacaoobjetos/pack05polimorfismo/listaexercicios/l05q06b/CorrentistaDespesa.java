package didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l05q06b;

import didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l05q04.Correntista;
import didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l05q05.DespesasIndividuo;

public class CorrentistaDespesa extends Correntista
{
    private DespesasIndividuo despesasPrevistas; // despesas previstas
    
    public CorrentistaDespesa(String cpfCliente, float saldo,
                              DespesasIndividuo despesas)
    {
        super(cpfCliente, saldo);
        this.despesasPrevistas = despesas;
    }
    
    public DespesasIndividuo getDespesasPrevistas()
    {
        return despesasPrevistas;
    }
}