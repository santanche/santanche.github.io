package didatico.orientacaoobjetos.pack05polimorfismo.simples;

public class Usuario
{
    public static String getNomeCompleto(Individuo i)
    {
        String nomeCompleto = i.getPrimeiroNome() + " " +
                              i.getSobrenome();
        return nomeCompleto;
    }
}
