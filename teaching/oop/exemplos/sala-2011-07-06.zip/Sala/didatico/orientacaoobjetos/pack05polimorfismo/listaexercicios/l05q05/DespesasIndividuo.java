package didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l05q05;

public class DespesasIndividuo
{
    private String cpf;
    private DespesaMes despesas[];
    
    public DespesasIndividuo(String cpf, DespesaMes despesas[])
    {
        this.cpf = cpf;
        this.despesas = despesas;
    }
    
    public String getCPF()
    {
        return cpf;
    }
    
    public DespesaMes totalizaMes(int mes)
    {
        float total = 0;
        
        for (int d = 0; d < despesas.length; d++)
            if (despesas[d].getMes() == mes)
                total += despesas[d].getValor();

        DespesaMes despesaTotal = new DespesaMes(mes, total);
        return despesaTotal;
    }
}
