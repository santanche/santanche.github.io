package didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l04q02a;

public abstract class Caminhao
{
    public Caminhao(int quantidade)
    {
        /* nada */
    }
    
    public abstract void inserePluviometro(Pluviometro novo);
}
