package didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l05q01compl;

import didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l05q01.Animal;
import didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l05q01.Ferramentas;
import didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l05q01.Q0501;
import didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l05q01.Resultado;

public class App0501
{
    public static void main(String args[])
    {
        Animal anim[] = {
                new AnimalImpl("Rinoceronte", "Asdrubal"),
                new AnimalImpl("Leao", "Zandor"),
                new AnimalImpl("Rinoceronte", "Melissa"),
                new AnimalImpl("Sabia", "Quincas"),
                new AnimalImpl("Sabia", "Doriana"),
                new AnimalImpl("Rinoceronte", "Alcebiades")
        };
        
        Ferramentas ferr = new FerramentasImpl();
        
        Resultado result[] = Q0501.contabiliza(anim, ferr);
        
        System.out.println("Contabilizacao");
        System.out.println("==============");
        for (int r = 0; r < result.length; r++) {
            System.out.print("Especie: " + result[r].getNomeEspecie());
            System.out.println("; quantidade: " + result[r].getQuantidade());
        }
    }
}
