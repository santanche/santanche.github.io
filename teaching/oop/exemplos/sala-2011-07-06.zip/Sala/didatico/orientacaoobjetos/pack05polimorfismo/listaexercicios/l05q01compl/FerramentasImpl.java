package didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l05q01compl;

import java.util.Vector;

import didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l05q01.Animal;
import didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l05q01.Ferramentas;

public class FerramentasImpl implements Ferramentas
{
    public Animal[] filtraEspecie(Animal[] completo, String especieFiltrar)
    {
        Vector<Animal> selecao = new Vector<Animal>();
        
        for (int a = 0; a < completo.length; a++)
            if (completo[a].getNomeEspecie().
                    equalsIgnoreCase(especieFiltrar))
                selecao.add(completo[a]);
        
        return selecao.toArray(new Animal[0]);
    }

    public String[] classificaEspecies(Animal[] completo)
    {
        Vector<String> especies = new Vector<String>();
        
        for (int a = 0; a < completo.length; a++)
        {
            if (especies.indexOf(completo[a].getNomeEspecie()) == -1)
                especies.add(completo[a].getNomeEspecie());
        }
        
        return especies.toArray(new String[0]);
    }
}
