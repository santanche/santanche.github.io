package didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l05q03;

import java.util.Vector;

import didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l05q02.ItemOrcamentoComplexo;

public class Q0503
{
    public AnimalOrcamento[] comVacina(AnimalOrcamento animais[])
    {
        Vector<AnimalOrcamento> selecionados =
            new Vector<AnimalOrcamento>();
        
        for (int o = 0; o < animais.length; o++)
        {
            ItemOrcamentoComplexo orcamento =
                animais[o].orcamentoGastosAnimal();
            
            if (orcamento.encontraItem("Vacina W") != null)
                selecionados.add(animais[o]);
        }
        
        return selecionados.toArray(new AnimalOrcamento[0]);
    }
}
