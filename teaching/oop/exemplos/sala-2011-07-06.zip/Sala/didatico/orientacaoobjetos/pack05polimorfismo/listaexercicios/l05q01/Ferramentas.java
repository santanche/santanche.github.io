package didatico.orientacaoobjetos.pack05polimorfismo.listaexercicios.l05q01;

public interface Ferramentas
{
    public Animal[] filtraEspecie(Animal[] completo, String especieFiltrar);
    public String[] classificaEspecies(Animal[] completo);
}