package didatico.orientacaoobjetos.pack01classe.bastiao01;

public class AppBastiao01
{
    public static void main(String[] args)
    {
        Bastiao theBastian;
        theBastian = new Bastiao();
        theBastian.aparece();
    }

}
