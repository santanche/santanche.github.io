package didatico.orientacaoobjetos.pack01classe.listaexercicios.l01q02;

public class Data
{
    private int dia = 1,
                mes = 1,
                ano = 1;
    
    public Data(int dia, int mes, int ano)
    {
        define(dia, mes, ano);
    }
    
    public void define(int dia, int mes, int ano)
    {
        if (ano >= 1 && mes >= 1 && mes <= 12 &&
            dia >= 1 && dia <= diasMes(mes, ano))
        {
            this.dia = dia;
            this.mes = mes;
            this.ano = ano;
        }
    }
    
    private int diasMes(int mes, int ano)
    {
        int dm[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        
        int resultado = dm[mes];
        if (mes == 2 && ano % 4 == 0)
            resultado = 29;
        
        return resultado;
    }
    
    public int compara(Data outro)
    {
        int resultado = 0;
        
        if (ano > outro.ano)
            resultado = 1;
        else if (ano < outro.ano)
            resultado = -1;
        else {
            if (mes > outro.mes)
                resultado = 1;
            else if (mes < outro.mes)
                resultado = -1;
            else {
                if (dia > outro.dia)
                    resultado = 1;
                else if (dia < outro.dia)
                    resultado = -1;
            }
        }
        
        return resultado;
    }

    public int getDia()
    {
        return dia;
    }

    public int getMes()
    {
        return mes;
    }

    public int getAno()
    {
        return ano;
    }
    
    public String mesExtenso()
    {
        String extenso[] = {"",
                            "janeiro",
                            "fevereiro",
                            "marco",
                            "abril",
                            "maio",
                            "junho",
                            "julho",
                            "agosto",
                            "setembro",
                            "outubro",
                            "novembro",
                            "dezembro"
                          };
        return extenso[mes];
    }
    
    public boolean bissexto()
    {
        return (ano % 4 == 0);
    }
}
