package didatico.orientacaoobjetos.pack01classe.listaexercicios.l01q01;

import didatico.biblioteca.EntradaTecladoBasica;

public class PrincipalQuestao01
{
    public static void main(String[] args)
    {
        System.out.print("Digite matricula: ");
        String matricula = EntradaTecladoBasica.leiaString();
        System.out.print("Digite nome: ");
        String nome = EntradaTecladoBasica.leiaString();
        System.out.print("Digite nota da prova 1: ");
        int prova1 = EntradaTecladoBasica.leiaInt();
        System.out.print("Digite nota da prova 2: ");
        int prova2 = EntradaTecladoBasica.leiaInt();
        System.out.print("Digite nota do trabalho: ");
        int trabalho = EntradaTecladoBasica.leiaInt();
        
        Aluno umAluno = new Aluno(matricula, nome, prova1, prova2, trabalho);
        System.out.println("A media do aluno eh " + umAluno.media());
        double aFinal = umAluno.calculaFinal();
        if (aFinal == 0)
            System.out.println("O aluno nao vai para a final");
        else
            System.out.println("O aluno precisa de " + aFinal +
                               " para a final");
    }

}
