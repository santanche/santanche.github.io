package didatico.orientacaoobjetos.pack01classe.listaexercicios.l01q03;

import didatico.biblioteca.EntradaTecladoBasica;
import didatico.orientacaoobjetos.pack01classe.listaexercicios.l01q02.Data;

public class Principal
{
    public static void main(String[] args)
    {
        System.out.print("Digite o numero do voo: ");
        String numeroVoo = EntradaTecladoBasica.leiaString();
        System.out.print("Digite o dia do voo: ");
        int dia = EntradaTecladoBasica.leiaInt();
        System.out.print("Digite o mes do voo: ");
        int mes = EntradaTecladoBasica.leiaInt();
        System.out.print("Digite o ano do voo: ");
        int ano = EntradaTecladoBasica.leiaInt();
        
        Data dataVoo = new Data(dia, mes, ano);
        Voo umVoo = new Voo(numeroVoo, dataVoo);
        
        System.out.println("Digite as cadeiras a serem ocupadas\n");
        
        System.out.print("Digite o numero da cadeira (" +
                         umVoo.proximoLivre() + " vaga): ");
        int cadeira = EntradaTecladoBasica.leiaInt();
        while (cadeira != 0)
        {
            boolean status = umVoo.ocupa(cadeira);
            if (status)
                System.out.println("*** Cadeira ocupada com sucesso");
            else
                System.out.println("*** Nao foi possivel ocupar a cadeira");
            
            System.out.print("Digite o numero da cadeira (" +
                             umVoo.proximoLivre() + " vaga): ");
            cadeira = EntradaTecladoBasica.leiaInt();
        }
        
        System.out.println("\nSobraram " + umVoo.vagas() + " cadeiras");
    }

}
