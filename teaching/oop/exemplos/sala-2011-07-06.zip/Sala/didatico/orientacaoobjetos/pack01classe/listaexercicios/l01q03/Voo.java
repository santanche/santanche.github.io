package didatico.orientacaoobjetos.pack01classe.listaexercicios.l01q03;

import didatico.orientacaoobjetos.pack01classe.listaexercicios.l01q02.Data;

public class Voo
{
    private String numeroVoo;
    private Data dataVoo;
    
    private boolean ocupado[];
    
    public Voo(String numeroVoo, Data dataVoo)
    {
        configura(numeroVoo, dataVoo);
    }
    
    public void configura(String numeroVoo, Data dataVoo)
    {
        this.numeroVoo = numeroVoo;
        this.dataVoo = dataVoo;
        ocupado = new boolean[100];
    }
    
    public int proximoLivre()
    {
        int proximo = 0;
        int l;
        for (l = 0; l < ocupado.length && ocupado[l]; l++)
            /* nada */ ;
        if (l < ocupado.length)
            proximo = l + 1;
        return proximo;
    }
    
    public boolean verifica(int numeroCadeira)
    {
        boolean cadeiraOcupada = true;
        if (numeroCadeira >= 1 && numeroCadeira <= 100)
            cadeiraOcupada = ocupado[numeroCadeira - 1];
        return cadeiraOcupada;
    }
    
    public boolean ocupa(int numeroCadeira)
    {
        boolean resultado = false;
        if (!verifica(numeroCadeira))
        {
            ocupado[numeroCadeira - 1] = true;
            resultado = true;
        }
        return resultado;
    }
    
    public int vagas()
    {
        int numero = 0;
        for (int v = 0; v < ocupado.length; v++)
            if (!ocupado[v])
                numero++;
        
        return numero;
    }
    
    public String getVoo()
    {
        return numeroVoo;
    }
    
    public Data getData()
    {
        return dataVoo;
    }
}
