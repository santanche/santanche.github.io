package didatico.orientacaoobjetos.pack01classe.listaexercicios.l01q01;

//Resolucao da questao 01 da primeira lista de classe e heranca
//(com incrementos para tornar o objeto mais usavel)

public class AlunoPower
{
    private String matricula,
                   nome;
    private int prova1 = 0,
                prova2 = 0,
                trabalho = 0;
    
    public AlunoPower()
    {
        /* nada */
    }
    
    public AlunoPower(String matricula, String nome,
                      int prova1, int prova2, int trabalho)
    {
        this.matricula = matricula;
        this.nome = nome;
        this.prova1 = prova1;
        this.prova2 = prova2;
        this.trabalho = trabalho;
    }
    
    public double media()
    {
        return (prova1 * 2.5 + prova2 * 2.5 + trabalho * 2) / 7;
    }
    
    public int calculaFinal()
    {
        double totalPontos = prova1 * 2.5 + prova2 * 2.5 + trabalho * 2;
        int aFinal = 0;
        
        if (totalPontos >= 28 && totalPontos < 49)
            aFinal = (int)Math.round((50 - totalPontos) / 3);
        
        return aFinal;
    }

    public String getMatricula()
    {
        return matricula;
    }

    public void setMatricula(String matricula)
    {
        this.matricula = matricula;
    }

    public String getNome()
    {
        return nome;
    }

    public void setNome(String nome)
    {
        this.nome = nome;
    }

    public int getProva1()
    {
        return prova1;
    }

    public void setProva1(int prova1)
    {
        this.prova1 = prova1;
    }

    public int getProva2()
    {
        return prova2;
    }

    public void setProva2(int prova2)
    {
        this.prova2 = prova2;
    }

    public int getTrabalho()
    {
        return trabalho;
    }

    public void setTrabalho(int trabalho)
    {
        this.trabalho = trabalho;
    }
}
