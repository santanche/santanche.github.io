package didatico.orientacaoobjetos.pack01classe.listaexercicios.questao04;

import didatico.orientacaoobjetos.pack01classe.listaexercicios.questao02.Data;
import didatico.orientacaoobjetos.pack01classe.listaexercicios.questao03.Voo;

public class VooEstendido extends Voo
{
    private int maxVagas;
    private int cadeirasFumantes;
    
    public VooEstendido(int numeroVoo, Data dataVoo,
                        int maxVagas, int cadeirasFumantes)
    {
        super(numeroVoo, dataVoo);
        poltronas = new boolean[maxVagas];
        this.maxVagas = maxVagas;
        this.cadeirasFumantes = cadeirasFumantes;
    }
    
    public int getMaxVagas()
    {
        return maxVagas;
    }
    
    public int getCadeirasFumantes()
    {
        return cadeirasFumantes;
    }
    
    public char tipo(int cadeiraDesejada)
    {
        char resultado = 'N';
        if (cadeiraDesejada < 1 || cadeiraDesejada > maxVagas)
            resultado = 'E';
        else if (cadeiraDesejada > maxVagas - cadeirasFumantes)
            resultado = 'F';
        return resultado;
    }
}
