package didatico.referencia;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;

public abstract class Publicacao
{
    private String titulo,
                   autor;
    private Calendar dataPublicacao;
    
    public Publicacao()
    {
    }

    public Publicacao(String titulo, String autor, Calendar dataPublicacao) {
		super();
		this.titulo = titulo;
		this.autor = autor;
		this.dataPublicacao = dataPublicacao;
	}

	/**
	 * @return the autor
	 */
	public String getAutor() {
		return autor;
	}

	/**
	 * @param autor the autor to set
	 */
	public void setAutor(String autor) {
		this.autor = autor;
	}

	/**
	 * @return the dataPublicacao
	 */
	public Calendar getDataPublicacao() {
		return dataPublicacao;
	}

	/**
	 * @param dataPublicacao the dataPublicacao to set
	 */
	public void setDataPublicacao(Calendar dataPublicacao) {
		this.dataPublicacao = dataPublicacao;
	}

	/**
	 * @return the titulo
	 */
	public String getTitulo() {
		return titulo;
	}

	/**
	 * @param titulo the titulo to set
	 */
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
    
	public String chave()
	{
		String aux = autor + dataPublicacao.get(Calendar.YEAR);
		return aux.replaceAll(" ", "_");
	}
	
	protected String mioloBibTeX()
	{
        return chave() + ",\n" +
		       "  author = {" + autor + "},\n" +
	           "  title = {" + titulo + "},\n" +
	           "  year = {" + dataPublicacao.get(Calendar.YEAR) + "},\n";
	}
	
	protected String mioloString()
	{
        return "Autor: " + autor + "\n" +
               "Titulo: " + titulo + "\n" +
               "Ano publicacao: " + dataPublicacao.get(Calendar.YEAR) + "\n";
	}
	
    protected void mioloGrava(PrintWriter pw)
    {
    	if (pw != null)
    	{
    		pw.println(titulo);
    		pw.println(autor);
    		pw.println(dataPublicacao.getTimeInMillis());
    	}
    }
    
    protected void mioloLe(BufferedReader br) throws IOException
    {
    	if (br != null)
    	{
    		titulo = br.readLine();
    		autor = br.readLine();
    		dataPublicacao = Calendar.getInstance();
    		dataPublicacao.setTimeInMillis(Long.parseLong(br.readLine()));
    	}
    }
	
	public abstract String toString();
    
    public abstract String toBibTeX();
    
    public abstract void gravaArquivo(PrintWriter pw);
    
    public abstract void leArquivo(BufferedReader br) throws IOException;
    
    public static Publicacao lePublicacaoArquivo(BufferedReader br)
    {
    	Publicacao publ = null;
    	
    	if (br != null)
    	{
    		try {
    			String tipo = br.readLine();
    			if (tipo != null)
    			{
    				if (tipo.equalsIgnoreCase("#ARTIGO"))
    					publ = new Artigo();
    				else if (tipo.equalsIgnoreCase("#LIVRO"))
    					publ = new Livro();
    				else if (tipo.equalsIgnoreCase("#CONGRESSO"))
    					publ = new PublicacaoCongresso();
    				
    				publ.leArquivo(br);
    			}
    		} catch (Exception erro) {
    			erro.printStackTrace();
    		}
    	}
    	
    	return publ;
    }
}
