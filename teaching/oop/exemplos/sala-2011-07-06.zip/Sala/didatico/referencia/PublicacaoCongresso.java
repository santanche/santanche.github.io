package didatico.referencia;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;

public class PublicacaoCongresso extends Publicacao
{
    private String congresso;

    public PublicacaoCongresso()
    {
    	super();
    }
    
	public PublicacaoCongresso(String titulo, String autor, Calendar dataPublicacao, String congresso)
	{
		super(titulo, autor, dataPublicacao);
		this.congresso = congresso;
	}

	/**
	 * @return the congresso
	 */
	public String getCongresso() {
		return congresso;
	}

	/**
	 * @param congresso the congresso to set
	 */
	public void setCongresso(String congresso) {
		this.congresso = congresso;
	}
    
	@Override
	public String toBibTeX()
	{
		return "@INPROCEEDINGS{" +
		           mioloBibTeX() +
		           "  booktitle = {Proceeding of " + congresso + "}\n" +
		       "}";
	}

	@Override
	public String toString() {
		return "Publicacao em Congresso:\n" +
		       mioloString() +
		       "Congresso: " + congresso;
	}

	/* (non-Javadoc)
	 * @see didatico.referencia.Publicacao#gravaArquivo(java.io.PrintWriter)
	 */
	@Override
	public void gravaArquivo(PrintWriter pw)
	{
        if (pw != null)
        {
        	pw.println("#CONGRESSO");
        	mioloGrava(pw);
        	pw.println(congresso);
        }
	}

	/* (non-Javadoc)
	 * @see didatico.referencia.Publicacao#leArquivo(java.io.BufferedReader)
	 */
	@Override
	public void leArquivo(BufferedReader br) throws IOException
	{
		if (br != null)
		{
			mioloLe(br);
			congresso = br.readLine();
		}
	}
}
