package didatico.referencia.teste;

import didatico.referencia.Publicacao;
import didatico.referencia.Repositorio;
import didatico.referencia.RepositorioDisco;

public class CarregaRepositorio
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		Repositorio armazem = new RepositorioDisco("armazem.txt");
		
		Publicacao publ = armazem.primeiro();
        while (publ != null)
        {
        	System.out.println(publ);
        	System.out.println();
        	publ = armazem.proximo();
        }
	}

}
