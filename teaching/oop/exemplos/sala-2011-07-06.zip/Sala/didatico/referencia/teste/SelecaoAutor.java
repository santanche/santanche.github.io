package didatico.referencia.teste;

import java.util.Calendar;

import didatico.referencia.Artigo;
import didatico.referencia.ConjuntoPublicacoes;
import didatico.referencia.Livro;
import didatico.referencia.Publicacao;
import didatico.referencia.PublicacaoCongresso;

public class SelecaoAutor
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
        Publicacao vpublicacoes[] = {
            new Livro("O destino dos dinossauros", "Asdrubal Oliveira", Calendar.getInstance(), "50893465"),
            new Artigo("Porque os dinossauros nao choram", "Quincas Ferreira", Calendar.getInstance(), "Dino Planet"),
            new PublicacaoCongresso("Quando os dinossauros tinham sede", "Asdrubal Oliveira", Calendar.getInstance(), "Simposio dos Dinossauros"),
            new Livro("Dinossauros coloridos", "Melissa Oliveira", Calendar.getInstance(), "65784365")
        };
        
		ConjuntoPublicacoes conjunto = new ConjuntoPublicacoes(vpublicacoes);
		
		System.out.println(conjunto.geraBibTeX("Asdrubal Oliveira"));
	}

}
