package didatico.referencia.teste;

import java.util.Calendar;

import didatico.referencia.Artigo;
import didatico.referencia.Livro;
import didatico.referencia.Publicacao;
import didatico.referencia.PublicacaoCongresso;
import didatico.referencia.Repositorio;
import didatico.referencia.RepositorioDisco;
import didatico.referencia.RepositorioMemoria;

public class GravaLeRepositorio
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
    	Repositorio armazemMemoria = new RepositorioMemoria();
    	System.out.println("Na Memoria");
    	System.out.println("----------\n");
    	gravaLe(armazemMemoria);
    	
    	Repositorio armazemDisco = new RepositorioDisco("armazem.txt");
    	System.out.println("Em Disco");
    	System.out.println("--------\n");
    	gravaLe(armazemDisco);
	}

	public static void gravaLe(Repositorio armazem)
	{
        armazem.guarda(new Livro("O destino dos dinossauros", "Asdrubal Oliveira", Calendar.getInstance(), "50893465"));
        armazem.guarda(new Artigo("Porque os dinossauros nao choram", "Quincas Ferreira", Calendar.getInstance(), "Dino Planet"));
        armazem.guarda(new PublicacaoCongresso("Quando os dinossauros tinham sede", "Asdrubal Oliveira", Calendar.getInstance(), "Simposio dos Dinossauros"));
        armazem.guarda(new Livro("Dinossauros coloridos", "Melissa Oliveira", Calendar.getInstance(), "65784365"));
        
		Publicacao publ = armazem.primeiro();
        while (publ != null)
        {
        	System.out.println(publ);
        	System.out.println();
        	publ = armazem.proximo();
        }
	}
}
