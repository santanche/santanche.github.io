package didatico.referencia.teste;

import java.util.Calendar;

import didatico.referencia.Artigo;
import didatico.referencia.Livro;
import didatico.referencia.PublicacaoCongresso;
import didatico.referencia.Repositorio;
import didatico.referencia.RepositorioDisco;

public class GeraRepositorio
{
    public static void main(String args[])
    {
        Repositorio armazem = new RepositorioDisco("armazem.txt");
	
        armazem.guarda(new Livro("O destino dos dinossauros", "Asdrubal Oliveira", Calendar.getInstance(), "50893465"));
        armazem.guarda(new Artigo("Porque os dinossauros nao choram", "Quincas Ferreira", Calendar.getInstance(), "Dino Planet"));
        armazem.guarda(new PublicacaoCongresso("Quando os dinossauros tinham sede", "Asdrubal Oliveira", Calendar.getInstance(), "Simposio dos Dinossauros"));
        armazem.guarda(new Livro("Dinossauros coloridos", "Melissa Oliveira", Calendar.getInstance(), "65784365"));
    }
}
