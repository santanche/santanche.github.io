package didatico.referencia;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;

public class Artigo extends Publicacao
{
    private String revista;
    
    public Artigo()
    {
    	super();
    }
	
	public Artigo(String titulo, String autor, Calendar dataPublicacao, String revista)
	{
		super(titulo, autor, dataPublicacao);
		this.revista = revista;
	}

	/**
	 * @return the revista
	 */
	public String getRevista() {
		return revista;
	}

	/**
	 * @param revista the revista to set
	 */
	public void setRevista(String revista) {
		this.revista = revista;
	}

	@Override
	public String toBibTeX()
	{
		return "@ARTICLE{" +
		           mioloBibTeX() +
		           "  journal = {" + revista + "}\n" +
		       "}";
	}

	@Override
	public String toString() {
		return "Artigo:\n" +
		       mioloString() +
		       "Revista: " + revista;
	}

	/* (non-Javadoc)
	 * @see didatico.referencia.Publicacao#gravaArquivo(java.io.PrintWriter)
	 */
	@Override
	public void gravaArquivo(PrintWriter pw)
	{
        if (pw != null)
        {
        	pw.println("#ARTIGO");
        	mioloGrava(pw);
        	pw.println(revista);
        }
	}

	/* (non-Javadoc)
	 * @see didatico.referencia.Publicacao#leArquivo(java.io.BufferedReader)
	 */
	@Override
	public void leArquivo(BufferedReader br) throws IOException
	{
		if (br != null)
		{
			mioloLe(br);
			revista = br.readLine();
		}
	}
}
