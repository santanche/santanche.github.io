package didatico.referencia;

public class ConjuntoPublicacoes
{
    Publicacao vpublicacoes[];
    
    public ConjuntoPublicacoes(Publicacao vpublicacoes[])
    {
    	this.vpublicacoes = vpublicacoes;
    }
    
    public String geraBibTeX(String autor)
    {
    	String bibtex = "";
    	
    	if (vpublicacoes != null)
    	{
    		for (int p = 0; p < vpublicacoes.length; p++)
    			if (vpublicacoes[p] != null && vpublicacoes[p].getAutor().equalsIgnoreCase(autor))
    				bibtex += vpublicacoes[p].toBibTeX() + "\n\n";
    	}
    	
    	return bibtex;
    }
}
