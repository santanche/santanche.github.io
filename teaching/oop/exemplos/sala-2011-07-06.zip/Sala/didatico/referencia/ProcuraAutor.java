package didatico.referencia;

import java.util.Calendar;

public class ProcuraAutor
{
	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		Publicacao vpublicacoes[] = {
			new Artigo("Vida dos dinossauros", "Asdrubal Silva", Calendar.getInstance(), "Revista dos Dinossauros"),
			new Livro("Quando os dinossauros morreram", "Quincas Oliveira", Calendar.getInstance(), "45678"),
			new PublicacaoCongresso("Dinossauros vermelhos", "Asdrubal Silva", Calendar.getInstance(), "III Dino Congresso")
		};

		ConjuntoPublicacoes conjunto = new ConjuntoPublicacoes(vpublicacoes);
		
		System.out.print(conjunto.geraBibTeX("Asdrubal Silva"));
	}
}
