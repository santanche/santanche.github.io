package didatico.referencia;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class RepositorioDisco implements Repositorio
{
    private String nomeArquivo;
    private BufferedReader linear;
    
    public RepositorioDisco(String nomeArquivo)
    {
    	this.nomeArquivo = nomeArquivo;
    }
	
	public void guarda(Publicacao nova)
	{
		fechaLinear();
		if (nomeArquivo != null)
		{
			try {
				PrintWriter pw = new PrintWriter(new FileWriter(nomeArquivo, true));
				nova.gravaArquivo(pw);
				pw.close();
			} catch (IOException erro) {
			 	erro.printStackTrace();
			}
		}
	}

	public Publicacao recupera(String chave)
	{
		Publicacao publ = null;
		
		fechaLinear();
		
		if (nomeArquivo != null)
		{
			try {
				BufferedReader br = new BufferedReader(new FileReader(nomeArquivo));
				
				publ = Publicacao.lePublicacaoArquivo(br);
				while (publ != null && !chave.equalsIgnoreCase(publ.chave()))
					publ = Publicacao.lePublicacaoArquivo(br);
				
				br.close();
			} catch (Exception erro) {
				erro.printStackTrace();
			}
		}
		
		return publ;
	}

	private void fechaLinear()
	{
		if (linear != null)
			try {
			    linear.close();
			} catch (IOException erro) {
				erro.printStackTrace();
			}
		linear = null;
	}
	
	public Publicacao primeiro()
	{
		Publicacao publ = null;
		
		fechaLinear();
		if (nomeArquivo != null)
		{
			try {
			    linear = new BufferedReader(new FileReader(nomeArquivo));
			    publ = Publicacao.lePublicacaoArquivo(linear);
			} catch (Exception erro) {
				erro.printStackTrace();
			}
		}
		
		return publ;
	}

	public Publicacao proximo()
	{
		Publicacao publ = null;
		
		if (linear == null)
			publ = primeiro();
		else {
			try {
				publ = Publicacao.lePublicacaoArquivo(linear);
			} catch (Exception erro) {
				erro.printStackTrace();
			}
		}
		
		return publ;
	}

	public int quantidade()
	{
		int q = 0;
		
		if (nomeArquivo != null)
		{
			try {
				BufferedReader br = new BufferedReader(new FileReader(nomeArquivo));
				
				String linha = br.readLine();
				while (linha != null)
				{
					q++;
					linha = br.readLine();
				}
				
				br.close();
				
				q /= 5;
			} catch (Exception erro) {
				erro.printStackTrace();
			}
		}
			
	    return q;
	}

}
