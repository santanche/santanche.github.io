package didatico.referencia;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;

public class Livro extends Publicacao
{
    private String isbn;
    
    public Livro()
    {
    	super();
    }
    
	public Livro(String titulo, String autor, Calendar dataPublicacao, String isbn) {
		super(titulo, autor, dataPublicacao);
		this.isbn = isbn;
	}

	/**
	 * @return the isbn
	 */
	public String getIsbn() {
		return isbn;
	}

	/**
	 * @param isbn the isbn to set
	 */
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	@Override
	public String toBibTeX()
	{
		return "@BOOK{" +
		           mioloBibTeX() +
		           "  isbn = {" + isbn + "}\n" +
		       "}";
	}

	@Override
	public String toString() {
		return "Livro:\n" +
		       mioloString() +
		       "ISBN: " + isbn;
	}

	/* (non-Javadoc)
	 * @see didatico.referencia.Publicacao#gravaArquivo(java.io.PrintWriter)
	 */
	@Override
	public void gravaArquivo(PrintWriter pw)
	{
        if (pw != null)
        {
        	pw.println("#LIVRO");
        	mioloGrava(pw);
        	pw.println(isbn);
        }
	}

	/* (non-Javadoc)
	 * @see didatico.referencia.Publicacao#leArquivo(java.io.BufferedReader)
	 */
	@Override
	public void leArquivo(BufferedReader br) throws IOException
	{
		if (br != null)
		{
			mioloLe(br);
			isbn = br.readLine();
		}
	}
}
