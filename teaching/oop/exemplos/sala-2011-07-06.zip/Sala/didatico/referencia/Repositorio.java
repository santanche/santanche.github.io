package didatico.referencia;

public interface Repositorio
{
    public void guarda(Publicacao nova);
    public Publicacao recupera(String chave);
    public Publicacao primeiro();
    public Publicacao proximo();
    public int quantidade();
}
