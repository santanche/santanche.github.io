package didatico.referencia;

import java.util.Enumeration;
import java.util.Hashtable;

public class RepositorioMemoria implements Repositorio
{
    Hashtable<String,Publicacao> bau;
    Enumeration<Publicacao> linear;
	
    public RepositorioMemoria()
    {
    	bau = new Hashtable<String,Publicacao>();
    }
    
	public void guarda(Publicacao nova)
	{
		if (nova != null)
	        bau.put(nova.chave(), nova);
	}

	public Publicacao recupera(String chave)
	{
		return bau.get(chave);
	}

	public Publicacao primeiro()
	{
		linear = bau.elements();
		return (linear.hasMoreElements()) ? linear.nextElement() : null;
	}

	public Publicacao proximo()
	{
		Publicacao resultado = null;
		if (linear == null)
			resultado = primeiro();
		else
			resultado = (linear.hasMoreElements()) ? linear.nextElement() : null;
	    return resultado;
	}

	public int quantidade()
	{
		return bau.size();
	}
}
