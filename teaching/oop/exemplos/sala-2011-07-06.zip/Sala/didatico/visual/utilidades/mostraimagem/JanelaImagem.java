package didatico.visual.utilidades.mostraimagem;

import java.awt.BorderLayout;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class JanelaImagem extends JFrame
{
    public JanelaImagem()
    {
        super();
        setBounds(0, 0, 200, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        JLabel imagem = new JLabel();
        imagem.setIcon(new ImageIcon(JanelaImagem.class.getResource("peixe1.gif")));
        getContentPane().add(imagem, BorderLayout.CENTER);
        
        setVisible(true);
    }
    
    public static void main(String args[])
    {
        JanelaImagem ji = new JanelaImagem();
    }
}
