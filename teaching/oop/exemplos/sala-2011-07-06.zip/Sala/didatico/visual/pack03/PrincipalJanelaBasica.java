package didatico.visual.pack03;

public class PrincipalJanelaBasica
{

    public static void main(String[] args)
    {
        JanelaBasica janela = new JanelaBasica();
        
    }

}
