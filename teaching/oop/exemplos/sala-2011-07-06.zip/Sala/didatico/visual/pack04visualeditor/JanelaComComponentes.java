package didatico.visual.pack04visualeditor;

import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JButton;

public class JanelaComComponentes extends JFrame
{

    private static final long serialVersionUID = 1L;
    private JPanel jContentPane = null;
    private JTextField campoTexto = null;
    private JButton botaoExplosao = null;

    /**
     * This is the default constructor
     */
    public JanelaComComponentes()
    {
        super();
        initialize();
    }

    /**
     * This method initializes this
     * 
     * @return void
     */
    private void initialize()
    {
        this.setSize(300, 200);
        this.setContentPane(getJContentPane());
        this.setTitle("Janela com Componentes");
    }

    /**
     * This method initializes jContentPane
     * 
     * @return javax.swing.JPanel
     */
    private JPanel getJContentPane()
    {
        if (jContentPane == null) {
            jContentPane = new JPanel();
            jContentPane.setLayout(new BorderLayout());
            jContentPane.add(getCampoTexto(), BorderLayout.CENTER);
            jContentPane.add(getBotaoExplosao(), BorderLayout.SOUTH);
        }
        return jContentPane;
    }

    /**
     * This method initializes campoTexto	
     * 	
     * @return javax.swing.JTextField	
     */
    private JTextField getCampoTexto()
    {
        if (campoTexto == null) {
            campoTexto = new JTextField();
        }
        return campoTexto;
    }

    /**
     * This method initializes botaoExplosao	
     * 	
     * @return javax.swing.JButton	
     */
    private JButton getBotaoExplosao()
    {
        if (botaoExplosao == null) {
            botaoExplosao = new JButton();
            botaoExplosao.setText("Explode");
        }
        return botaoExplosao;
    }

}
