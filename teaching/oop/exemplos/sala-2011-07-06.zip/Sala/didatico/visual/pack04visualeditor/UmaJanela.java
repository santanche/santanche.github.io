package didatico.visual.pack04visualeditor;

import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JFrame;

public class UmaJanela extends JFrame
{
    private static final long serialVersionUID = 3698760792093642125L;
    private JPanel jContentPane = null;

    /**
     * This is the default constructor
     */
    public UmaJanela()
    {
        super();
        initialize();
    }

    /**
     * This method initializes this
     * 
     * @return void
     */
    private void initialize()
    {
        this.setSize(300, 200);
        this.setContentPane(getJContentPane());
        this.setTitle("Minha Janela");
    }

    /**
     * This method initializes jContentPane
     * 
     * @return javax.swing.JPanel
     */
    private JPanel getJContentPane()
    {
        if (jContentPane == null) {
            jContentPane = new JPanel();
            jContentPane.setLayout(new BorderLayout());
        }
        return jContentPane;
    }

}
