package didatico.visual.pack02;

public class PrincipalJanelaBasica
{

    public static void main(String[] args)
    {
        JanelaBasica janela = new JanelaBasica();
        
        janela.insereLina("Tum tum");
        janela.insereLina("Quem �?");
        janela.insereLina("Sou eu");
    }

}
