package didatico.visual;

public class Principal
{
    public static void main(String args[])
    {
	    Janela jan = new Janela();
        jan.setVisible(true);
    }
}
