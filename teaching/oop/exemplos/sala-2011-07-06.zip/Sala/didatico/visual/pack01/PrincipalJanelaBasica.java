package didatico.visual.pack01;

public class PrincipalJanelaBasica
{

    public static void main(String[] args)
    {
        JanelaBasica janela = new JanelaBasica();
    }

}
