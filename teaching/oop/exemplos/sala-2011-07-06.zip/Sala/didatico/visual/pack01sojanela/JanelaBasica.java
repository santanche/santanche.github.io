package didatico.visual.pack01sojanela;

import javax.swing.JFrame;

public class JanelaBasica extends JFrame
{
    private static final long serialVersionUID = -3453381116112163763L;

    public JanelaBasica()
    {
        super();
        setSize(300, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
}
