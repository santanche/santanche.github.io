package didatico.visual.pack01sojanela;

public class PrincipalJanelaBasica
{
    public static void main(String[] args)
    {
        JanelaBasica janela = new JanelaBasica();
        janela.setVisible(true);
    }

}
