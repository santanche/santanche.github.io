package didatico.visual.pack00criajanela;

import javax.swing.JFrame;

public class PrincipalCriaJanela
{

    public static void main(String[] args)
    {
        JFrame janela = new JFrame();
        janela.setSize(300, 200);
        janela.setVisible(true);
        janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

}
