package didatico.visual.jigloo;

public class ClasseComum
{
    public String teste()
    {
        return "Um teste";
    }
}
