package didatico.visual;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Janela extends JFrame
{

	private static final long serialVersionUID = 1L;

	private JPanel jContentPane = null;

	private JTextField texto1 = null;

	private JPanel painelSul = null;

	private JButton botao1 = null;

	private JButton botao2 = null;

	private JButton botao3 = null;

	/**
	 * This is the default constructor
	 */
	public Janela() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(327, 118);
		this.setContentPane(getJContentPane());
		this.setTitle("Asdrubal");
		this.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent e) {
				System.exit(0);
			}
		});
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(new BorderLayout());
			jContentPane.add(getTexto1(), BorderLayout.CENTER);
			jContentPane.add(getPainelSul(), BorderLayout.SOUTH);
		}
		return jContentPane;
	}

	/**
	 * This method initializes texto1	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getTexto1() {
		if (texto1 == null) {
			texto1 = new JTextField();
		}
		return texto1;
	}

	/**
	 * This method initializes painelSul	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getPainelSul() {
		if (painelSul == null) {
			painelSul = new JPanel();
			painelSul.setLayout(new FlowLayout());
			painelSul.add(getBotao1(), null);
			painelSul.add(getBotao2(), null);
			painelSul.add(getBotao3(), null);
		}
		return painelSul;
	}

	/**
	 * This method initializes botao1	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getBotao1() {
		if (botao1 == null) {
			botao1 = new JButton();
			botao1.setText("Reco Reco");
			botao1.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
                    texto1.setText("Voc� clicou em Reco Reco");
				}
			});
		}
		return botao1;
	}

	/**
	 * This method initializes botao2	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getBotao2() {
		if (botao2 == null) {
			botao2 = new JButton();
			botao2.setText("Bol�o");
		}
		return botao2;
	}

	/**
	 * This method initializes botao3	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getBotao3() {
		if (botao3 == null) {
			botao3 = new JButton();
			botao3.setText("Azeitona");
		}
		return botao3;
	}

}  //  @jve:decl-index=0:visual-constraint="6,10"
