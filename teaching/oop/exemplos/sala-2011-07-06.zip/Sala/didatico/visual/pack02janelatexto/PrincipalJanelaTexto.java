package didatico.visual.pack02janelatexto;

public class PrincipalJanelaTexto
{
    public static void main(String[] args)
    {
        JanelaTexto janela = new JanelaTexto();
        janela.setVisible(true);
        
        janela.insereLinha("Asdrubal");
        janela.insereLinha("Quincas");
        janela.insereLinha("Doriana");
    }

}
