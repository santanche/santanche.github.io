/**
 * Program series: Progressive modularization -- second phase.
 *
 * Case study: Serial stamp program.
 * 
 * First version:
 * Adopting singleton pattern to guarantee a centralized control.
 */

package didatico.pattern.singleton.stamp.teste;

import didatico.pattern.singleton.stamp.SimpleSequenceStamp;

/**
 * @author Andre Santanche
 * @since 23 aug 2007 
 * @version 1.0
 */
public class SequenceStampTest01
{
    public static void main(String[] args)
    {
        SimpleSequenceStamp sistamp = SimpleSequenceStamp.getInstance();
        tenStamps(sistamp);
    }

    
    public static void tenStamps(SimpleSequenceStamp sistamp)
    {
        for (int s = 1; s <= 10; s++)
            System.out.println("stamp: " + sistamp.nextId());
    }
}
