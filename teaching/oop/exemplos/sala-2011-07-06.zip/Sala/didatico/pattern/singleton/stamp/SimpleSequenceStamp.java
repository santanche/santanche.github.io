/**
 * Program series: Progressive modularization -- second phase.
 *
 * Case study: Serial stamp program.
 * 
 * First version:
 * Adopting singleton pattern to guarantee a centralized control.
 */

package didatico.pattern.singleton.stamp;

/**
 * @author Andre Santanche
 * @since 23 aug 2007 
 * @version 1.0
 */
public class SimpleSequenceStamp
{
    /*
     * Static section
     */
    
    private static SimpleSequenceStamp instance = null;
	
    public static synchronized SimpleSequenceStamp getInstance()
    {
        if (instance == null)
            instance = new SimpleSequenceStamp();
        
        return instance;
    }
    
    /*
     * Instance section
     */
    
    private int lastId = 0;
    
    private SimpleSequenceStamp()
    {
    }
    
    public synchronized String nextId()
	{
	    lastId++;
        String idString = "000000000" + lastId;
        return idString.substring(idString.length() - 10, idString.length());
	}
}
