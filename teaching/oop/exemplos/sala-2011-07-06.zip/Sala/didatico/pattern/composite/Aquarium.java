package didatico.pattern.composite;

public interface Aquarium
{
    public String topAquarium();
    public String bottomAquarium();
}
