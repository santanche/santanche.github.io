package didatico.pattern.composite;

public interface Aquatic
{
    public String aquaticImage();
}
