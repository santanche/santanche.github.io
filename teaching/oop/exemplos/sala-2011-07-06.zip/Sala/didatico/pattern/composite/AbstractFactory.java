package didatico.pattern.composite;

import didatico.pattern.composite.crab.CrabFactory;
import didatico.pattern.composite.fish.FishFactory;
import didatico.pattern.composite.group.MixFactory;

public abstract class AbstractFactory
{
    public abstract Aquatic createAquatic();
    public abstract Aquarium createAquarium();
    
    public static AbstractFactory createFactory(String id)
    {
        AbstractFactory factory = null;
        if (id.equalsIgnoreCase("fish"))
            factory = new FishFactory();
        else if (id.equalsIgnoreCase("crab"))
            factory = new CrabFactory();
        else if (id.equalsIgnoreCase("group"))
            factory = new MixFactory();
        return factory;
    }
}
