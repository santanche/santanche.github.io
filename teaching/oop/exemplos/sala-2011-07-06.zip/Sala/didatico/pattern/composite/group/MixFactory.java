package didatico.pattern.composite.group;

import didatico.pattern.composite.AbstractFactory;
import didatico.pattern.composite.Aquarium;
import didatico.pattern.composite.Aquatic;
import didatico.pattern.composite.crab.Crab;
import didatico.pattern.composite.fish.Fish;
import didatico.pattern.composite.fish.FishAquarium;

public class MixFactory extends AbstractFactory
{
    @Override
    public Aquarium createAquarium()
    {
        return new FishAquarium();
    }

    @Override
    public Aquatic createAquatic()
    {
        Group theGroup = new Group();
        theGroup.addMember(new Crab());
        theGroup.addMember(new Fish());
        
        Group theSubGroup = new Group();
        theSubGroup.addMember(new Fish());
        theSubGroup.addMember(new Fish());

        theGroup.addMember(theSubGroup);
        
        return theGroup;
    }

}
