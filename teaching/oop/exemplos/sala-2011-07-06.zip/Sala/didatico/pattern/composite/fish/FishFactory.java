package didatico.pattern.composite.fish;

import didatico.pattern.composite.AbstractFactory;
import didatico.pattern.composite.Aquarium;
import didatico.pattern.composite.Aquatic;

public class FishFactory extends AbstractFactory
{
    public Aquatic createAquatic()
    {
        return new Fish();
    }

    public Aquarium createAquarium()
    {
        return new FishAquarium();
    }
}
