package didatico.pattern.composite.crab;

import didatico.pattern.composite.AbstractFactory;
import didatico.pattern.composite.Aquarium;
import didatico.pattern.composite.Aquatic;

public class CrabFactory extends AbstractFactory
{
    public Aquatic createAquatic()
    {
        return new Crab();
    }

    public Aquarium createAquarium()
    {
        return new CrabAquarium();
    }
}
