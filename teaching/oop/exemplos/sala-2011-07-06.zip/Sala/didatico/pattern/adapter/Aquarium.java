package didatico.pattern.adapter;

public interface Aquarium
{
    public String topAquarium();
    public String bottomAquarium();
}
