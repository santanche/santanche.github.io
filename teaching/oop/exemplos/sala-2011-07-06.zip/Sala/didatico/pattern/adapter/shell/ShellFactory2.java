package didatico.pattern.adapter.shell;

import didatico.pattern.adapter.fish.FishAquarium;
import didatico.pattern.adapter.AbstractFactory;
import didatico.pattern.adapter.Aquarium;
import didatico.pattern.adapter.Aquatic;

public class ShellFactory2 extends AbstractFactory
{
    public Aquatic createAquatic()
    {
        return new ShellAdapter2(new Shell());
    }

    public Aquarium createAquarium()
    {
        return new FishAquarium();
    }
}
