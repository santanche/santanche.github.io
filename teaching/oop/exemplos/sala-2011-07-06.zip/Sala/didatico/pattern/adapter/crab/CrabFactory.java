package didatico.pattern.adapter.crab;

import didatico.pattern.adapter.AbstractFactory;
import didatico.pattern.adapter.Aquarium;
import didatico.pattern.adapter.Aquatic;

public class CrabFactory extends AbstractFactory
{
    public Aquatic createAquatic()
    {
        return new Crab();
    }

    public Aquarium createAquarium()
    {
        return new CrabAquarium();
    }
}
