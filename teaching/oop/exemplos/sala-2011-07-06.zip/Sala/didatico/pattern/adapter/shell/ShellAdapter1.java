package didatico.pattern.adapter.shell;

import didatico.pattern.adapter.Aquatic;

public class ShellAdapter1 extends Shell implements Aquatic
{
    public String aquaticImage()
    {
        return draw();
    }
}
