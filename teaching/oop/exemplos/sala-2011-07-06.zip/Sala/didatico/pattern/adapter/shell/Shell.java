package didatico.pattern.adapter.shell;

public class Shell
{
    /*
        /---\
        |   |
        \---/
        <--->
     */
    
    public String draw()
    {
        return "/---\\\n" +
               "|   |\n" +
               "\\---/\n" +
               "<--->";
    }
}
