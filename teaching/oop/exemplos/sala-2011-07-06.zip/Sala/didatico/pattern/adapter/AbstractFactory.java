package didatico.pattern.adapter;

import didatico.pattern.adapter.crab.CrabFactory;
import didatico.pattern.adapter.fish.FishFactory;
import didatico.pattern.adapter.shell.ShellFactory1;
import didatico.pattern.adapter.shell.ShellFactory2;

public abstract class AbstractFactory
{
    public abstract Aquatic createAquatic();
    public abstract Aquarium createAquarium();
    
    public static AbstractFactory createFactory(String id)
    {
        AbstractFactory factory = null;
        if (id.equalsIgnoreCase("fish"))
            factory = new FishFactory();
        else if (id.equalsIgnoreCase("crab"))
            factory = new CrabFactory();
        else if (id.equalsIgnoreCase("shell-1"))
            factory = new ShellFactory1();
        else if (id.equalsIgnoreCase("shell-2"))
            factory = new ShellFactory2();
        return factory;
    }
}
