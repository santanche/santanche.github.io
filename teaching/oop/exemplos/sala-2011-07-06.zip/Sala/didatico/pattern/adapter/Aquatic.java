package didatico.pattern.adapter;

public interface Aquatic
{
    public String aquaticImage();
}
