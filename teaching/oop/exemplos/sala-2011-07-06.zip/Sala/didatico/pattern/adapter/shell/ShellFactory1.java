package didatico.pattern.adapter.shell;

import didatico.pattern.adapter.fish.FishAquarium;
import didatico.pattern.adapter.AbstractFactory;
import didatico.pattern.adapter.Aquarium;
import didatico.pattern.adapter.Aquatic;

public class ShellFactory1 extends AbstractFactory
{
    public Aquatic createAquatic()
    {
        return new ShellAdapter1();
    }

    public Aquarium createAquarium()
    {
        return new FishAquarium();
    }
}
