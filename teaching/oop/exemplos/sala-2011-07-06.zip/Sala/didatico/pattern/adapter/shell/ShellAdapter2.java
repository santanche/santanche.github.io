package didatico.pattern.adapter.shell;

import didatico.pattern.adapter.Aquatic;

public class ShellAdapter2 implements Aquatic
{
    private Shell adaptee;
    
    public ShellAdapter2(Shell adaptee)
    {
        this.adaptee = adaptee;
    }
    
    public String aquaticImage()
    {
        return adaptee.draw();
    }

}
