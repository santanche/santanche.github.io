package didatico.pattern.decorator.skate;

import didatico.pattern.decorator.Aquatic;

public class Skate implements Aquatic
{
    /*
        \---------
          0     0
    */

    private Aquatic skater;
    
    public Skate(Aquatic skater)
    {
        this.skater = skater;
    }
    
    public String aquaticImage()
    {
        String complete = skater.aquaticImage();
        complete += "\\---------\n" +
                    "    0     0\n";
        
        return complete;
    }

}
