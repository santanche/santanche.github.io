package didatico.pattern.decorator.fish;

import didatico.pattern.decorator.AbstractFactory;
import didatico.pattern.decorator.Aquarium;
import didatico.pattern.decorator.Aquatic;
import didatico.pattern.decorator.hat.Hat;
import didatico.pattern.decorator.skate.Skate;

public class FishFactory extends AbstractFactory
{
    public Aquatic createAquatic()
    {
        return new Fish();
    }

    public Aquatic createDecoratedAquatic()
    {
        return new Hat(new Skate(new Fish()));
    }

    public Aquarium createAquarium()
    {
        return new FishAquarium();
    }
}
