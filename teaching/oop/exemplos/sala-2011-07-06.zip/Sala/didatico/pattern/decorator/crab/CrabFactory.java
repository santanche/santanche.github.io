package didatico.pattern.decorator.crab;

import didatico.pattern.decorator.AbstractFactory;
import didatico.pattern.decorator.Aquarium;
import didatico.pattern.decorator.Aquatic;
import didatico.pattern.decorator.hat.Hat;
import didatico.pattern.decorator.skate.Skate;

public class CrabFactory extends AbstractFactory
{
    public Aquatic createAquatic()
    {
        return new Crab();
    }

    public Aquatic createDecoratedAquatic()
    {
        return new Hat(new Skate(new Crab()));
    }

    public Aquarium createAquarium()
    {
        return new CrabAquarium();
    }
}
