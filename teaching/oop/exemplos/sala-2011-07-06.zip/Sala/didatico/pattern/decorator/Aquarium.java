package didatico.pattern.decorator;

public interface Aquarium
{
    public String topAquarium();
    public String bottomAquarium();
}
