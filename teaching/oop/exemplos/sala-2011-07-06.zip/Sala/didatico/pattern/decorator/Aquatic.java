package didatico.pattern.decorator;

public interface Aquatic
{
    public String aquaticImage();
}
