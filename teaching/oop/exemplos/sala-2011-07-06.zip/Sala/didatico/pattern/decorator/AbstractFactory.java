package didatico.pattern.decorator;

import didatico.pattern.decorator.crab.CrabFactory;
import didatico.pattern.decorator.fish.FishFactory;

public abstract class AbstractFactory
{
    public abstract Aquatic createAquatic();
    public abstract Aquatic createDecoratedAquatic();
    public abstract Aquarium createAquarium();
    
    public static AbstractFactory createFactory(String id)
    {
        AbstractFactory factory = null;
        if (id.equalsIgnoreCase("fish"))
            factory = new FishFactory();
        else if (id.equalsIgnoreCase("crab"))
            factory = new CrabFactory();
        return factory;
    }
}
