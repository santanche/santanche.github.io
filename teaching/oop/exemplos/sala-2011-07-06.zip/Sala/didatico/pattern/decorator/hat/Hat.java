package didatico.pattern.decorator.hat;

import didatico.pattern.decorator.Aquatic;

public class Hat implements Aquatic
{
    private Aquatic aqua = null;
    
    public Hat(Aquatic aqua)
    {
        this.aqua = aqua;
    }
    
    public String aquaticImage()
    {
        return "\\____/---\\_____/\n" +
               aqua.aquaticImage();
    }

}
