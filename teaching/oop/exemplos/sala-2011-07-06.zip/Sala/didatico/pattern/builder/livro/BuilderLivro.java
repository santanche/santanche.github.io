package didatico.pattern.builder.livro;

import java.util.Date;

public interface BuilderLivro
{
    public void criaTitulo(String titulo);
    public void criaAutor(String autor);
    public void criaDataPublicacao(Date dataPublicacao);
    public void encerra();
}
