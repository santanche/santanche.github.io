package didatico.pattern.builder.livro;

import java.util.Calendar;

public class DirectorLivro
{
    public void construct(BuilderLivro b)
    {
        b.criaTitulo("Vida dos Dinossauros");
        b.criaAutor("Alcebiades");
        b.criaDataPublicacao(Calendar.getInstance().getTime());
        b.encerra();
    }
}
