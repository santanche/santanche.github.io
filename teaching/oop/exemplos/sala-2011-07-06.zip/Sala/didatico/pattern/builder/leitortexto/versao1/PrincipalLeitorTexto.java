package didatico.pattern.builder.leitortexto.versao1;

public class PrincipalLeitorTexto
{
    public static void main(String[] args)
    {
        JanelaApresentacao janela = new JanelaApresentacao();
        janela.setVisible(true);
        
        if (args.length >= 1) {
            LeitorArquivo leitor =
                new LeitorArquivo(args[0], janela);
            leitor.carregaArquivo();
        } else
            janela.insereLinha(
                    "--- Informe o nome do arquivo na chamada do programa");
    }

}
