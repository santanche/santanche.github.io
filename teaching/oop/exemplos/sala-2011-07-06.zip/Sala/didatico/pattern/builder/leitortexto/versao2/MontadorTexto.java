package didatico.pattern.builder.leitortexto.versao2;

public interface MontadorTexto
{
    public void insereLinha(String linha);
    public void notificaErro(String mensagemErro);
}
