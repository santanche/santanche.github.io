package didatico.pattern.builder.livro;

public class Principal
{

    public static void main(String[] args)
    {
        BuilderLivro build = new ConcreteBuilderBibTeX();
        DirectorLivro dir = new DirectorLivro();
        dir.construct(build);
    }

}
