package didatico.pattern.builder.leitortexto.versao1;

public interface MontadorTexto
{
    public void insereLinha(String linha);
}
