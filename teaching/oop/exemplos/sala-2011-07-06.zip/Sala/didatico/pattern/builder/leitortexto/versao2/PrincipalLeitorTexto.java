package didatico.pattern.builder.leitortexto.versao2;

public class PrincipalLeitorTexto
{
    public static void main(String[] args)
    {
        JanelaApresentacao janela = new JanelaApresentacao();
        janela.setVisible(true);
        
        if (args.length >= 1) {
            LeitorArquivo leitor =
                new LeitorArquivo(args[0], janela);
            try {
                leitor.carregaArquivo();
            } catch (ErroLeituraArquivo erro) {
                janela.notificaErro(erro.getMessage());
            }
        } else
            janela.notificaErro(
                    "--- Informe o nome do arquivo na chamada do programa");
    }

}
