package didatico.pattern.factory.s03.fish;

import didatico.pattern.factory.s03.AbstractFactory;
import didatico.pattern.factory.s03.Aquarium;
import didatico.pattern.factory.s03.Aquatic;

public class FishFactory implements AbstractFactory
{
    public Aquatic createAquatic()
    {
        return new Fish();
    }

    public Aquarium createAquarium()
    {
        return new FishAquarium();
    }
}
