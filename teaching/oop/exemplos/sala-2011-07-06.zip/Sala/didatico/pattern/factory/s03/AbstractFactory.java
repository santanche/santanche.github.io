package didatico.pattern.factory.s03;

public interface AbstractFactory
{
    public Aquatic createAquatic();
    public Aquarium createAquarium();
}
