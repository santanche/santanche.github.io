package didatico.pattern.factory.s01;

public class Fish
{
    /*   .  _
         |\/O\
         |/\_/
     */

    public String fishImage()
    {
        return ".  _\n" +
               "|\\/O\\\n" +
               "|/\\_/\n";
    }

}
