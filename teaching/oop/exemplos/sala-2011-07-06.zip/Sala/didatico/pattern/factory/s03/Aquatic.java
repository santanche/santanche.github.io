package didatico.pattern.factory.s03;

public interface Aquatic
{
    public String aquaticImage();
}
