package didatico.pattern.factory.s04.crab;

import didatico.pattern.factory.s04.AbstractFactory;
import didatico.pattern.factory.s04.Aquarium;
import didatico.pattern.factory.s04.Aquatic;

public class CrabFactory extends AbstractFactory
{
    public Aquatic createAquatic()
    {
        return new Crab();
    }

    public Aquarium createAquarium()
    {
        return new CrabAquarium();
    }
}
