package didatico.pattern.factory.s02;

public interface Aquatic
{
    public String aquaticImage();
}
