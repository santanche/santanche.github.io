package didatico.pattern.factory.s04.fish;

import didatico.pattern.factory.s04.AbstractFactory;
import didatico.pattern.factory.s04.Aquarium;
import didatico.pattern.factory.s04.Aquatic;

public class FishFactory extends AbstractFactory
{
    public Aquatic createAquatic()
    {
        return new Fish();
    }

    public Aquarium createAquarium()
    {
        return new FishAquarium();
    }
}
