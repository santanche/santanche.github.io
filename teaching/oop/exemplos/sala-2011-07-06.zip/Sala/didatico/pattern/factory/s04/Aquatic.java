package didatico.pattern.factory.s04;

public interface Aquatic
{
    public String aquaticImage();
}
