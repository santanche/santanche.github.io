package didatico.pattern.factory.s03.crab;

import didatico.pattern.factory.s03.AbstractFactory;
import didatico.pattern.factory.s03.Aquarium;
import didatico.pattern.factory.s03.Aquatic;

public class CrabFactory implements AbstractFactory
{
    public Aquatic createAquatic()
    {
        return new Crab();
    }

    public Aquarium createAquarium()
    {
        return new CrabAquarium();
    }
}
