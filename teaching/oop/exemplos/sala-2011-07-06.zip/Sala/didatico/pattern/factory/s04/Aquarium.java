package didatico.pattern.factory.s04;

public interface Aquarium
{
    public String topAquarium();
    public String bottomAquarium();
}
