package didatico.financeiro;

/**
 * Calcula as parcelas de um financiamento usando juros compostos e
 * controla o pagamento destas parcelas.
 */
public class FinanciamentoCompostoA
{
    // Atributos
	private float valor;
	private int numeroParcelas;
    private float percentualJuros,
                  pagamento[];

    /**
     * Construtor que inicializa atributos com parametros fornecidos.
     * @param valor valor do financiamento
     * @param numeroParcelas numero de parcelas
     * @param percentualJuros percentual de juros
     */
    public FinanciamentoCompostoA(float valor, int numeroParcelas, float percentualJuros)
    {
    	this.valor = valor;
    	this.numeroParcelas = numeroParcelas;
    	this.percentualJuros  = percentualJuros;
    	this.pagamento = new float[numeroParcelas];
    }
    
    /**
     * Metodo que calcula uma parcela do financiamento.
     * @param parcela numero da parcela
     * @return valor da parcela com juros
     */
    public float calculaParcela(int parcela)
    {
    	float valorParcela = 0;
    	
    	if (parcela > 0 && parcela <= numeroParcelas)
    	{
    		float saldo = valor * (1 + percentualJuros);
    		for (int p = 2; p <= parcela; p++)
    		{
    			saldo -= pagamento[p - 2];
    			saldo *= (1 + percentualJuros);
    		}
    		valorParcela = saldo / (numeroParcelas - parcela + 1);
    	}
    	
    	return valorParcela;
    }
    
    /**
     * Metodo que efetiva o pagamento de uma parcela.
     * @param parcela numero da parcela paga
     * @param valorPago valor pago pela parcela
     */
    public void pagaParcela(int parcela, float valorPago)
    {
    	if (parcela > 0 && parcela <= numeroParcelas)
    		pagamento[parcela - 1] = valorPago;
    }
}
