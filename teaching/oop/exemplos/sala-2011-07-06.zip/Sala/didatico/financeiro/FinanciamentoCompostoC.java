package didatico.financeiro;

public class FinanciamentoCompostoC extends FinanciamentoCompostoB
{
	public FinanciamentoCompostoC()
	{
		super();
	}

	public FinanciamentoCompostoC(float valor, int numeroParcelas, float percentualJuros)
	{
		super(valor, numeroParcelas, percentualJuros);
	}

	/**
     * Metodo que projeta uma parcela do financiamento.
     * @param parcela numero da parcela
     * @return valor da parcela com juros
     */
    public float projetaParcela(int parcela)
    {
    	float valorParcela = 0;
    	
    	if (parcela > 0 && parcela <= getNumeroParcelas())
    	{
    		float saldo = getValor() * (1 + getPercentualJuros());
    		for (int p = 2; p <= parcela; p++)
    		{
    			saldo -= (getNumeroParcelas() - p + 2);
    			saldo *= (1 + getPercentualJuros());
    		}
    		valorParcela = saldo / (getNumeroParcelas() - parcela + 1);
    	}
    	
    	return valorParcela;
    }
    
    public int compara(FinanciamentoCompostoC externo)
    {
    	float totalA = 0, totalB = 0;
    	
    	for (int p1 = 1; p1 <= this.getNumeroParcelas(); p1++)
    		totalA += this.projetaParcela(p1);
    	
    	for (int p2 = 1; p2 <= externo.getNumeroParcelas(); p2++)
    		totalB += externo.projetaParcela(p2);
    	
    	return (totalA < totalB) ? -1 : ((totalA == totalB) ? 0 : 1);
    }

}
