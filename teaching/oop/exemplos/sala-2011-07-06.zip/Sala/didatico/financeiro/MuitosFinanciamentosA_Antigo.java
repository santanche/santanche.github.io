package didatico.financeiro;

public class MuitosFinanciamentosA_Antigo
{
    private FinanciamentoCompostoC financiamento[];
    int proximoLivre = 0;
    
    public MuitosFinanciamentosA_Antigo(int quantidade)
    {
    	financiamento = new FinanciamentoCompostoC[quantidade];
    }
    
    public void adicionaFinanciamento(float valor, int numeroParcelas, float juros)
    {
    	if (proximoLivre < financiamento.length)
    	{
    		financiamento[proximoLivre] = new FinanciamentoCompostoC(valor, numeroParcelas, juros);
    		proximoLivre++;
    	}
    }
    
    public void adicionaFinanciamento(FinanciamentoCompostoC novoFinanciamento)
    {
    	if (proximoLivre < financiamento.length && novoFinanciamento != null)
    	{
    		financiamento[proximoLivre] = novoFinanciamento;
    		proximoLivre++;
    	}
    }
}
