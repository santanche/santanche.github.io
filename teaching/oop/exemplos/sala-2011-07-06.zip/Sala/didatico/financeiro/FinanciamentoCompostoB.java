package didatico.financeiro;

/**
 * Calcula as parcelas de um financiamento usando juros compostos e
 * controla o pagamento destas parcelas.
 */
public class FinanciamentoCompostoB
{
    // Atributos
	private float valor = 0;
	private int numeroParcelas = 1;
    private float percentualJuros = 0,
                  pagamento[] = null;

    /**
     * Construtor sem parametros.
     */
    public FinanciamentoCompostoB()
	{
		/* nada */
	}
    
    /**
     * Construtor que inicializa atributos com parametros fornecidos.
     * @param valor valor do financiamento
     * @param numeroParcelas numero de parcelas
     * @param percentualJuros percentual de juros
     */
    public FinanciamentoCompostoB(float valor, int numeroParcelas, float percentualJuros)
    {
    	setValor(valor);
    	setNumeroParcelas(numeroParcelas);
    	setPercentualJuros(percentualJuros);
    }
    
    /**
     * Metodo que calcula uma parcela do financiamento.
     * @param parcela numero da parcela
     * @return valor da parcela com juros
     */
    public float calculaParcela(int parcela)
    {
    	float valorParcela = 0;
    	
    	if (parcela > 0 && parcela <= numeroParcelas)
    	{
    		float saldo = valor * (1 + percentualJuros);
    		for (int p = 2; p <= parcela; p++)
    		{
    			saldo -= pagamento[p - 2];
    			saldo *= (1 + percentualJuros);
    		}
    		valorParcela = saldo / (numeroParcelas - parcela + 1);
    	}
    	
    	return valorParcela;
    }
    
    /**
     * Metodo que efetiva o pagamento de uma parcela.
     * @param parcela numero da parcela paga
     * @param valorPago valor pago pela parcela
     */
    public void pagaParcela(int parcela, float valorPago)
    {
    	if (parcela > 0 && parcela <= numeroParcelas)
    		pagamento[parcela - 1] = valorPago;
    }

	/**
	 * @return valor do financiamento
	 */
	public float getValor()
	{
		return valor;
	}

	/**
	 * @param valor valor do financiamento
	 */
	public void setValor(float valor)
	{
		if (valor > 0)
		    this.valor = valor;
	}
	
	/**
	 * @return numero de parcelas
	 */
	public int getNumeroParcelas()
	{
		return numeroParcelas;
	}

	/**
	 * @param numeroParcelas numero de parcelas
	 */
	public void setNumeroParcelas(int numeroParcelas)
	{
		if (numeroParcelas > 0 && pagamento == null)
		{
		    this.numeroParcelas = numeroParcelas;
		    pagamento = new float[numeroParcelas];
		}
	}

	/**
	 * @return percentual de juros
	 */
	public float getPercentualJuros()
	{
		return percentualJuros * 100;
	}

	/**
	 * @param percentualJuros percentual de juros
	 */
	public void setPercentualJuros(float percentualJuros)
	{
		this.percentualJuros = percentualJuros / 100;
	}

	/**
	 * Atraves deste metodo o objeto converte o seu estado interno em
	 * alguma forma de apresentacao em formato String.
	 */
	public String toString()
	{
    	String s = "Valor do financiamento: " + getValor() + "\n" +
    	           "Numero de parcelas: " + getNumeroParcelas() + "\n" +
    	           "Percentual de juros: " + getPercentualJuros() + "%\n" +
    	           "Pagamentos:";
    	
    	for (int p = 0; p < numeroParcelas; p++)
    		s += "\n    " + (p + 1) + ": " + pagamento[p];
    	
    	return s;
	}
}
