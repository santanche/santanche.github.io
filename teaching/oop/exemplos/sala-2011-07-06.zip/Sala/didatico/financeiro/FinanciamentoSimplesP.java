package didatico.financeiro;

/**
 * Calcula as parcelas de um financiamento usando juros simples.
 * 
 * Esta versao usa atributos publicos para efeito de ilustracao, mas
 * a boa pratica da orientacao a objetos pede atributos privados
 * (vide FinanciamentoSimples.java).
 */
public class FinanciamentoSimplesP
{
    // Atributos
	public float valor = 0;
	public int numeroParcelas = 0;
    public float percentualJuros = 0;
	
    /**
     * Construtor sem parametros.
     */
    public FinanciamentoSimplesP()
	{
		/* nada */
	}
    
    /**
     * Construtor que inicializa atributos com parametros fornecidos.
     * @param valor valor do financiamento
     * @param numeroParcelas numero de parcelas
     * @param percentualJuros percentual de juros
     */
    public FinanciamentoSimplesP(float valor, int numeroParcelas, float percentualJuros)
    {
    	this.valor = valor;
    	this.numeroParcelas = numeroParcelas;
    	this.percentualJuros = percentualJuros;
    	/*
    	 * A referencia "this" indica a instancia do objeto.
    	 * Neste caso:
    	 *     "this.valor" = atributo valor do objeto
    	 *     "valor" = parametro valor recebido pelo metodo
    	 */
    }
    
    /**
     * Metodo que calcula uma parcela do financiamento.
     * @param parcela numero da parcela (este parametro eh irrelevante pois todas as
     *        parcelas tem o mesmo valor; ele existe para manter compatibilidade com
     *        futuras classes)
     * @return valor da parcela com juros
     */
    public float calculaParcela(int parcela)
    {
    	float valorParcela = 0;
    	
    	if (parcela <= numeroParcelas && numeroParcelas > 0)
    		valorParcela = (valor / numeroParcelas) * (1 + (percentualJuros / 100));
    	
    	return valorParcela;
    }
}
