package didatico.financeiro.teste;

import didatico.financeiro.FinanciamentoSimplesP;

/**
 * Testa a classe FinanciamentoSimplesP.
 */
public class TesteFinanciamentoSimplesP
{
    public static void main(String argumentos[])
    {
    	// instancia um objeto da classe FinanciamentoSimplesP
    	FinanciamentoSimplesP financia = new FinanciamentoSimplesP();
    	
    	// atribui valores a atributos publicos
    	financia.valor = 150;
    	financia.numeroParcelas = 3;
    	financia.percentualJuros = 1;
    	
    	System.out.println("Valor do financiamento: " + financia.valor);
    	System.out.println("Numero de parcelas: " + financia.numeroParcelas);
    	System.out.println("Percentual de juros: " + financia.percentualJuros + "%");
    	
    	// aciona metodo que calcula o valor de uma parcela
    	float valorParcela = financia.calculaParcela(1);
    	System.out.println("Valor fixo da parcela: " + valorParcela);
    }
}
