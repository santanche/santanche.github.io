package didatico.financeiro.teste;

// import FinanciamentoSimples;

public class TesteFinanciamentoSimples
{
/*	public static void main(String argumentos[])
    {
        
         * Financiamento 1
         * ===============
         
    	
    	System.out.println("Financiamento 1");
    	System.out.println("===============");
    	
    	// instancia um objeto da classe FinanciamentoSimples
    	// (valor = 150, numero de parcelas = 3, percentual de juros = 1%)
    	FinanciamentoSimples financia1 = new FinanciamentoSimples(150, 3, 1);
    	
    	// apresentacao do estado interno do objeto atraves do metodo toString
    	System.out.println(financia1.toString());
    	
    	System.out.println("Valor fixo da parcela: " + financia1.calculaParcela(1));

        
         * Financiamento 2
         * ===============
         
    	
        System.out.println();
    	System.out.println("Financiamento 2");
    	System.out.println("===============");
    	
    	FinanciamentoSimples financia2 = new FinanciamentoSimples();

    	// atribuicao de valores
    	financia2.setValor(300);
    	financia2.setNumeroParcelas(4);
    	financia2.setPercentualJuros(5);
    	
        // neste caso em que nenhum metodo e especificado, aciona automaticamente
    	// o metodo toString
    	System.out.println(financia2);
    	
    	System.out.println("Valor fixo da parcela: " + financia2.calculaParcela(1));
    }
*/}
