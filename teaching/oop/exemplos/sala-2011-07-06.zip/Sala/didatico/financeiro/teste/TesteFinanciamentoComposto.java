package didatico.financeiro.teste;

import didatico.financeiro.FinanciamentoCompostoB;
import didatico.biblioteca.EntradaTecladoBasica;

public class TesteFinanciamentoComposto
{
    public static void main(String args[])
    {
    	FinanciamentoCompostoB financia = new FinanciamentoCompostoB(1000, 10, 5);
    	System.out.println(financia);
    	
    	System.out.println("Parcela 1: " + financia.calculaParcela(1));
    	System.out.print("Pagamento 1: ");
    	
    	float valorPago = EntradaTecladoBasica.leiaFloat();
    	financia.pagaParcela(1, valorPago);
    	
    	System.out.println(financia);
    	System.out.println("Parcela 2: " + financia.calculaParcela(2));
    }
}
