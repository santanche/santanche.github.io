package didatico.modularizacao;

import didatico.biblioteca.EntradaTecladoBasica;

/*
 * Resolucao da questao 04 da lista de modularizacao
 */
public class Fatorial1
{

    public static void main(String[] args)
    {
        System.out.print("Digite um numero: ");
        int n = EntradaTecladoBasica.leiaInt();
        
        int resultado = fatorial(n);
        
        System.out.println("O fatorial de " + n + " eh " + resultado);
    }

    static int fatorial(int n)
    {
        int fat = 1;
        for (int f = 2; f <= n; f++)
            fat *= f;  // equivalente a fat = fat * f;
        return fat;
    }
}
