package didatico.modularizacao;

import didatico.biblioteca.EntradaTecladoBasica;

/*
 * Resolucao da questao 04 da lista de modularizacao com modificacoes
 */
public class Fatorial2
{

    public static void main(String[] args)
    {
        System.out.print("Digite um limite: ");
        int limite = EntradaTecladoBasica.leiaInt();
        
        variosFatoriais(limite);
    }
    
    static void variosFatoriais(int limite)
    {
        for (int l = 1; l <= limite; l++)
            System.out.println("O fatorial de " + l + " eh " + fatorial(l));
    }
    
    static int fatorial(int n)
    {
        int fat = 1;
        for (int f = 2; f <= n; f++)
            fat *= f;
        return fat;
    }
}
