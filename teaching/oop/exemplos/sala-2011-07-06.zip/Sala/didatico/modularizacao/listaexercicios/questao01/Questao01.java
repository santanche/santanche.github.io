package didatico.modularizacao.listaexercicios.questao01;

import didatico.biblioteca.EntradaTecladoBasica;

public class Questao01
{
    public static void main(String[] args)
    {
        System.out.print("Digite A: ");
        double a = EntradaTecladoBasica.leiaFloat();
        System.out.print("Digite B: ");
        double b = EntradaTecladoBasica.leiaFloat();
        System.out.print("Digite C: ");
        double c = EntradaTecladoBasica.leiaFloat();

        Raizes r = calculaRaizes(a, b, c);
        
        switch (r.getStatus())
        {
            case 0 : System.out.println("Nao existem raizes reais.");
                     break;
            case 1 : System.out.println("Apenas uma raiz: " + r.getRaiz1());
                     break;
            case 2 : System.out.println("Raiz 1: " + r.getRaiz1());
                     System.out.println("Raiz 2: " + r.getRaiz2());
                     break;
        }
    }

    public static Raizes calculaRaizes(double a, double b, double c)
    {
        int status = 0;
        double raiz1 = 0, raiz2 = 0;
        
        double delta = b * b - 4 * a * c;
        if (delta == 0)
        {
            status = 1;
            raiz1 = -b / (2 * a);
        }
        else if (delta > 0)
        {
            status = 2;
            raiz1 = (-b + Math.sqrt(delta)) / (2 * a);
            raiz2 = (-b - Math.sqrt(delta)) / (2 * a);
        }
        
        Raizes resultado = new Raizes(status, raiz1, raiz2);
        return resultado;
    }
}
