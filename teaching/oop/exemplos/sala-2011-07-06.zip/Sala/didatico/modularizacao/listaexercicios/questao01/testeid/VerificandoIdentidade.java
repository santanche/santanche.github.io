package didatico.modularizacao.listaexercicios.questao01.testeid;

import didatico.biblioteca.EntradaTecladoBasica;
import didatico.modularizacao.listaexercicios.questao01.Questao01;
import didatico.modularizacao.listaexercicios.questao01.Raizes;

public class VerificandoIdentidade
{
    public static void main(String[] args)
    {
        System.out.print("Digite A: ");
        double a = EntradaTecladoBasica.leiaFloat();
        System.out.print("Digite B: ");
        double b = EntradaTecladoBasica.leiaFloat();
        System.out.print("Digite C: ");
        double c = EntradaTecladoBasica.leiaFloat();

        // esta primeira classe nao tem o metodo toString()
        // entao eh mostrada a identidade do objeto
        Raizes r1 = Questao01.calculaRaizes(a, b, c);
        System.out.println("Identidade do objeto: " + r1);
        
        // esta primeira classe tem o metodo toString()
        // entao eh mostrada implicitamente a string retornada pelo metodo toString()
        RaizesComToString r2 = new RaizesComToString(
                                 r1.getStatus(), r1.getRaiz1(), r1.getRaiz2());
        System.out.println(r2);
    }

}
