package didatico.modularizacao.listaexercicios.questao01.testeid;

import didatico.modularizacao.listaexercicios.questao01.Raizes;

public class RaizesComToString extends Raizes
{
    public RaizesComToString(int status, double raiz1, double raiz2)
    {
        super(status, raiz1, raiz2);
    }
    
    public String toString()
    {
        String resultado = "";
        switch (getStatus())
        {
            case 0 : resultado = "Nao existem raizes reais.";
                     break;
            case 1 : resultado = "Apenas uma raiz: " + getRaiz1();
                     break;
            case 2 : resultado = "Raiz 1: " + getRaiz1() + "\nRaiz 2: " + getRaiz2();
                     break;
        }
        return resultado;
    }
}
