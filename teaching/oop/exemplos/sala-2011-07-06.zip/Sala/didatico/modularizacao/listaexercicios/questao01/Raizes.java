package didatico.modularizacao.listaexercicios.questao01;

public class Raizes
{
    private int status;
    private double raiz1;
    private double raiz2;
    
    public Raizes(int status, double raiz1, double raiz2)
    {
        this.status = status;
        this.raiz1 = raiz1;
        this.raiz2 = raiz2;
    }
    
    public int getStatus()
    {
        return status;
    }

    public double getRaiz1()
    {
        return raiz1;
    }
    
    public double getRaiz2()
    {
        return raiz2;
    }
}
