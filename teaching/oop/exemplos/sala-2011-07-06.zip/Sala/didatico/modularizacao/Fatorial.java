package didatico.modularizacao;

import java.util.Scanner;

public class Fatorial
{

    /**
     * @param args
     */
    public static void main(String args[])
    {
        Scanner teclado = new Scanner(System.in);
        
        System.out.print("Digite um numero: ");
        int num = Integer.parseInt(teclado.nextLine());

        int umFatorial = fatorial(num);
        
        System.out.println("Fatorial eh: " + umFatorial);
    }

    static int fatorial(int numero)
    {
        int fat = 1;
        for (int f = numero; f >= 2; f--)
            fat *= f;
        
        return fat;
    }
    
}
