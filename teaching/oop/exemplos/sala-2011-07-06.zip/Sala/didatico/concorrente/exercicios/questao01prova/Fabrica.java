package didatico.concorrente.exercicios.questao01prova;

public class Fabrica
{
    public static void produzLote20(int codigoProduto)
    {
        System.out.println("Produzir lote de produto " +
                           codigoProduto);
    }
}
