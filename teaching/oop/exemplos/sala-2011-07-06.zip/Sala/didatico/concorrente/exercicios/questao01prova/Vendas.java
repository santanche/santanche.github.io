package didatico.concorrente.exercicios.questao01prova;

import java.util.Scanner;

public class Vendas extends Thread
{
    private Pedidos centralPedidos;
    
    public Vendas(Pedidos centralPedidos)
    {
        this.centralPedidos = centralPedidos;
    }
    
    public void run()
    {
        while(true)
        {
            Scanner entrada = new Scanner(System.in);
            System.out.println("Digite codigo: ");
            int codigoProduto = 
                Integer.parseInt(entrada.nextLine());
            System.out.println("Digite quantidade: ");
            int quantProduto = 
                Integer.parseInt(entrada.nextLine());
            centralPedidos.fazPedido(codigoProduto,
                                     quantProduto);
        }
    }
}
