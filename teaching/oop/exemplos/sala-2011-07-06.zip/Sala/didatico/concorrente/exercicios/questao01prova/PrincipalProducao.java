package didatico.concorrente.exercicios.questao01prova;

public class PrincipalProducao
{
    public static void main(String[] args)
    {
        Pedidos centralPedidos = new Pedidos();
        
        Vendas asVendas = new Vendas(centralPedidos);
        Producao aProducao = new Producao(centralPedidos);
        
        asVendas.start();
        aProducao.start();
    }
}
