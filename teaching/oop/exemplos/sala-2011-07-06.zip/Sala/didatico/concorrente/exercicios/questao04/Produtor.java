package didatico.concorrente.exercicios.questao04;

public class Produtor extends Thread
{
    private PilhaConcorrente aPilha;
    private int quantidade;
    
    public Produtor(PilhaConcorrente aPilha, int quantidade)
    {
        this.aPilha = aPilha;
        this.quantidade = quantidade;
    }
    
    public void run()
    {
        for (int i = 1; i <= quantidade; i++)
        {
            int numeroAleatorio = (int)(Math.random() * 100);
            aPilha.empilha(numeroAleatorio);
        }
    }
}
