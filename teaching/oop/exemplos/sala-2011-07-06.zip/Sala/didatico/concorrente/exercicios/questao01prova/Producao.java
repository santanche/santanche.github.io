package didatico.concorrente.exercicios.questao01prova;

public class Producao extends Thread
{
    private Pedidos centralPedidos;
    
    public Producao(Pedidos centralPedidos)
    {
        this.centralPedidos = centralPedidos;
    }
    
    public void run()
    {
        while (true)
        {
            int codigoProduto =
                centralPedidos.retiraProximoLote();
            Fabrica.produzLote20(codigoProduto);
        }
    }
}
