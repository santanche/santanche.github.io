package didatico.concorrente.exercicios.questao01prova;

public class Pedidos
{
    private int total = 0;
    private int pedidosProduto[];
    
    public Pedidos()
    {
        pedidosProduto = new int[10];
    }
    
    public synchronized void fazPedido(int codigoProduto,
                                       int quantProduto)
    {
        if (quantProduto > 3000 ||
            codigoProduto < 0 || codigoProduto > 9)
            System.out.println("Pedido invalido");
        else
        {
            while (total + quantProduto > 3000)
            {
                try {
                    wait();
                } catch (InterruptedException e) {
                    // nada
                }
            }
            
            pedidosProduto[codigoProduto] += quantProduto;
            total += quantProduto;
            notifyAll();
        }
    }
    
    public synchronized int retiraProximoLote()
    {
        int cp;
        do {
            for (cp = 0; cp <= 9 && pedidosProduto[cp] < 20;
                 cp++)
                /* nada */ ;
            if (cp > 9)
                try {
                    wait();
                } catch (InterruptedException e) {
                    /* nada */ 
                }
        } while(cp > 9);
        
        pedidosProduto[cp] -= 20;
        total -= 20;
        notifyAll();
        return cp;
    }
}
