package didatico.exercicios.lista3;

public class ControleCaminhao extends Controle
{
    public static void main(String args[])
    {
    	int maiorCapacidade = 0;
    	Caminhao maiorCaminhao = null;
    	
    	System.out.print("Digite o tipo do caminhao: ");
    	String tipoCaminhao = leString();
    	
    	while (tipoCaminhao != null && !tipoCaminhao.equalsIgnoreCase("fim"))
    	{
            Caminhao umCaminhao = null;
            if (tipoCaminhao.equalsIgnoreCase("alfa"))
            	umCaminhao = new CaminhaoAlfa();
            else if (tipoCaminhao.equalsIgnoreCase("beta"))
            	umCaminhao = new CaminhaoBeta();
            	
    		if (umCaminhao != null)
    		{
    			System.out.print("Quantidade de Pluviometros: ");
    			int qPluvio = leInteiro();
    			int capacidadeTotal = 0;

    			for (int p = 1; p <= qPluvio; p++)
    			{
    				System.out.print("Tipo do Pluviometro: ");
    				String tipoPluvio = leString();
    				Pluviometro umPluvio = new Pluviometro(tipoPluvio);
                    if (umCaminhao.inserePluviometro(umPluvio))
                    	capacidadeTotal += umPluvio.getCapacidade();
    			}
    			
    			if (capacidadeTotal > maiorCapacidade)
    			{
    				maiorCapacidade = capacidadeTotal;
    				maiorCaminhao = umCaminhao;
    			}
    		}
    		
    		System.out.print("Digite o tipo de caminhao: ");
    		tipoCaminhao = leString();
    	}
    	
    	System.out.println("Caminhao de maior capacidade:");
    	System.out.println(maiorCaminhao);
    }
}
