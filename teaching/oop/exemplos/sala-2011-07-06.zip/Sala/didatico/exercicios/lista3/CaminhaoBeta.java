package didatico.exercicios.lista3;

import java.util.Enumeration;
import java.util.Hashtable;

public class CaminhaoBeta extends Caminhao
{
    Hashtable<String,Pluviometro> listaPluvio;
    
    public CaminhaoBeta()
    {
    	listaPluvio = new Hashtable<String,Pluviometro>();
    }

	@Override
	public boolean inserePluviometro(Pluviometro novo)
	{
		boolean inseriu = false;
		
		if (!listaPluvio.contains(novo.getTipo()))
		{
			listaPluvio.put(novo.getTipo(), novo);
			inseriu = true;
		}
		
		return inseriu;
	}

	public String toString()
	{
		String resultado = "Beta\n";
		
		Enumeration<Pluviometro> lPluvio = listaPluvio.elements();
		
		Pluviometro umPluvio = lPluvio.nextElement();
		while (umPluvio != null)
		{
			resultado += umPluvio.getTipo() + "\n";
			umPluvio = lPluvio.nextElement();
		}
		
		return resultado;
	}
}
