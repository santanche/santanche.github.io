package didatico.exercicios.lista3;

import java.util.Hashtable;

public class CaminhaoBeta_manha extends Caminhao
{
    private Hashtable<String,Pluviometro> listaPluvio; 
	
    public CaminhaoBeta_manha()
    {
    	listaPluvio = new Hashtable<String,Pluviometro>();
    }
    
	@Override
	public boolean inserePluviometro(Pluviometro novo)
	{
		boolean inseriu = false;
		if (!listaPluvio.contains(novo.getTipo()))
		{
			listaPluvio.put(novo.getTipo(), novo);
			inseriu = true;
		}
		
		return inseriu;
	}

}
