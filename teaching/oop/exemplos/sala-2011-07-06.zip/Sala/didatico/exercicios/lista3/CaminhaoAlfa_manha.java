package didatico.exercicios.lista3;

import java.util.Vector;

public class CaminhaoAlfa_manha extends Caminhao
{
    private Vector<Pluviometro> listaPluvio;
	private int pesoTotal = 0;
	
	public CaminhaoAlfa_manha()
	{
		listaPluvio = new Vector<Pluviometro>();
	}
    
	
	@Override
	public boolean inserePluviometro(Pluviometro novo)
	{
		boolean inseriu = false;
		if (pesoTotal + novo.getPeso() <= 5000)
		{
			pesoTotal += novo.getPeso();
			listaPluvio.addElement(novo);
			inseriu = true;
		}
		
		return inseriu;
	}

	public String toString()
	{
		String resultado = "Alfa\n";
		int tamanho = listaPluvio.size();
		for (int p = 0; p < tamanho; p++)
		{
			Pluviometro pluvio = listaPluvio.elementAt(p);
			resultado += pluvio.getTipo() + "\n";
		}
		return resultado;
	}
}