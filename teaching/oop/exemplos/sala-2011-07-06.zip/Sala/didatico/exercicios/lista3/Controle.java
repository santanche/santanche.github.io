package didatico.exercicios.lista3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Controle
{
    /*
     * Le uma String pelo teclado.
     * 
     * Retorna null se houver algum erro na leitura.
     */
    public static String leString()
    {
    	BufferedReader entrada = new BufferedReader(new InputStreamReader(System.in));
        String leitura = null;
        
    	try {
    	    leitura = entrada.readLine();
    	} catch (IOException erro) {
    	}
    	
    	return leitura;
    }
    
     /*
     * Le um numero inteiro pelo teclado.
     * 
     * Retorna zero se houver algum erro na leitura.
     */
    public static int leInteiro()
    {
        int leituraInt = 0;
    	String leituraStr = leString();
    	
    	if (leituraStr != null)
    	try {
    		leituraInt = Integer.parseInt(leituraStr);
    	} catch (NumberFormatException erro) {
    	}
    	
    	return leituraInt;
    }
}
