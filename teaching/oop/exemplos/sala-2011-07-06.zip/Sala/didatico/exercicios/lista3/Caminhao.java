package didatico.exercicios.lista3;

public abstract class Caminhao
{
    public Caminhao()
    {
    }
    
    public abstract boolean inserePluviometro(Pluviometro novo);
}
