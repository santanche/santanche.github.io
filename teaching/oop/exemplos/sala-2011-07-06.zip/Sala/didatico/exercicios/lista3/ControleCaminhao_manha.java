package didatico.exercicios.lista3;

public class ControleCaminhao_manha extends Controle
{
    public static void main(String args[])
    {
    	int maiorCapacidade = 0;
    	Caminhao maiorCaminhao = null;
    	
    	System.out.print("Digite o tipo de caminhao: ");
    	String tipo = leString();
    	
    	while (tipo != null && !tipo.equalsIgnoreCase("fim"))
    	{
    		// Caminhao umCaminhao = (tipo.equalsIgnoreCase("alfa")) ? new CaminhaoAlfa() : ((tipo.equalsIgnoreCase("beta") ? new CaminhaoBeta() : null));
    		Caminhao umCaminhao = null;
    		if (tipo.equalsIgnoreCase("alfa"))
    			umCaminhao = new CaminhaoAlfa_manha();
    		else if (tipo.equalsIgnoreCase("beta"))
    			umCaminhao = new CaminhaoBeta_manha();
    		
    		if (umCaminhao != null)
    		{
    		    System.out.print("Digite o numero de pluviometros: ");
    		    int nPluvio = leInteiro();
    		    int capacidade = 0;
    		    for (int p = 1; p <= nPluvio; p++)
    		    {
    		    	String tipoPluvio = leString();
    		    	Pluviometro umPluvio = new Pluviometro(tipoPluvio);
    		    	if (umCaminhao.inserePluviometro(umPluvio))
    		    		capacidade += umPluvio.getCapacidade();
    		    }
    		    
    		    if (capacidade > maiorCapacidade)
    		    {
    		    	maiorCapacidade = capacidade;
    		    	maiorCaminhao = umCaminhao;
    		    }
    		}
    	}
    }
}
