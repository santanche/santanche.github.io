package didatico.java.reflexao;

public class AppTeste01 {

    /**
     * @param args
     */
    public static void main(String[] args) {
       System.out.println("teste");

    }

}
