package didatico.java.data;

import java.text.DateFormat;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

public class DiaDaSemana
{
    public static void main(String[] args)
    {
        Scanner teclado = new Scanner(System.in);
        System.out.print("Digite uma data: ");
        String dataString = teclado.nextLine();
        
        DateFormat df = DateFormat.getDateInstance();
        try {
            Date umaData = df.parse(dataString);
            
            Calendar calendario = Calendar.getInstance();
            calendario.setTime(umaData);
            
            System.out.println("Data digitada: " + umaData);
            System.out.println("Dia da semana: " +
                               calendario.get(Calendar.DAY_OF_WEEK));
        } catch (ParseException e) {
            System.out.println("Data digitada errada.");
        }

    }

}
