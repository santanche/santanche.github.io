package didatico.java.data;

import java.text.DateFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.Scanner;

public class CriandoData
{
    public static void main(String[] args)
    {
        Scanner teclado = new Scanner(System.in);
        System.out.print("Digite uma data: ");
        String dataString = teclado.nextLine();
        
        DateFormat df = DateFormat.getDateInstance();
        try {
            Date umaData = df.parse(dataString);
            System.out.println("Data digitada: " + umaData);
        } catch (ParseException e) {
            System.out.println("Data digitada errada.");
        }

    }

}
