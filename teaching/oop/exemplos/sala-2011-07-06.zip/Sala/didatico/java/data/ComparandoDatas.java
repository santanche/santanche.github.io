package didatico.java.data;

import java.text.DateFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.Scanner;

public class ComparandoDatas
{
    public static void main(String[] args)
    {
        Scanner teclado = new Scanner(System.in);
        System.out.print("Digite primeira data: ");
        String dataString1 = teclado.nextLine();
        System.out.print("Digite segunda data: ");
        String dataString2 = teclado.nextLine();
        
        DateFormat df = DateFormat.getDateInstance();
        try {
            Date data1 = df.parse(dataString1);
            Date data2 = df.parse(dataString2);
            
            int comparacao = data1.compareTo(data2);
            if (comparacao == 0)
                System.out.println("Datas iguais.");
            else if (comparacao < 0)
                System.out.println("Primeira data anterior a segunda data.");
            else
                System.out.println("Primeira data posterior a segunda data.");
        } catch (ParseException e) {
            System.out.println("Data digitada errada.");
        }

    }

}
