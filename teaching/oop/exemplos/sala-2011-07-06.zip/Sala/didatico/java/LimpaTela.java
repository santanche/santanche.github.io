package didatico.java;

import java.util.Scanner;

public class LimpaTela
{
    public static void main(String args[])
    {
        System.out.println("Este eh um teste");
        System.out.println("----------------");
        System.out.println("Este eh um teste");
        System.out.println("----------------");
        System.out.println("Este eh um teste");
        System.out.println("----------------");
        System.out.println("Este eh um teste");
        System.out.println("----------------");
        System.out.println("Este eh um teste");
        System.out.println("----------------");
        Scanner teclado = new Scanner(System.in);
        System.out.println("Digite <enter>");
        teclado.nextLine();
    }
}
