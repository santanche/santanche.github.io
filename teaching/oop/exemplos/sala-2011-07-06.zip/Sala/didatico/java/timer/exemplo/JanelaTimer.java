package didatico.java.timer.exemplo;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;

import didatico.java.timer.EscutaMetronomo;
import didatico.java.timer.Metronomo;

public class JanelaTimer extends JFrame implements EscutaMetronomo
{
    private static final long serialVersionUID = 7630427919896092638L;

    JLabel labelContador;
    int contador = 0;
    
    public JanelaTimer()
    {
        super();
        setSize(200, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        labelContador = new JLabel("" + contador);
        getContentPane().add(labelContador, BorderLayout.CENTER);
        
        Metronomo metro = new Metronomo(this, 1000);
        metro.inicia();
    }
    
    public static void main(String args[])
    {
        JanelaTimer j = new JanelaTimer();
        j.setVisible(true);
    }
    
    public void batida()
    {
        contador++;
        labelContador.setText("" + contador);
    }
}
