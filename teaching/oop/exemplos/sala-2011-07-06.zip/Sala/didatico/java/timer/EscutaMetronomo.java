package didatico.java.timer;

public interface EscutaMetronomo
{
	public void batida();
}
