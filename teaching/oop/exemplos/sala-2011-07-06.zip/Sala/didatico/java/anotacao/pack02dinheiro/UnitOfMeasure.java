package didatico.java.anotacao.pack02dinheiro;

public @interface UnitOfMeasure
{
    public String value();
}
