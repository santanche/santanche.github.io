package didatico.java.anotacao.pack03metaanotacao;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface MetaanotacaoMetodo
{
    public String value();
}
