package didatico.java.anotacao.pack02dinheiro;

public interface RequestPrice
{
    
}
