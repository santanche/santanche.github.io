package didatico.vetor.listaexercicios;

import didatico.biblioteca.EntradaTecladoBasica;

public class Questao03
{
    public static void main(String[] args)
    {
        String autorizados[] = new String[200];
        int tamanho = 0;
        
        // primeira etapa -- carrega autorizados
        System.out.println("Cadastro de pessoas autorizadas");
        System.out.println("-------------------------------\n");
        String pessoa;
        do {
            System.out.print("Digite o nome da pessoa autorizada:");
            pessoa = EntradaTecladoBasica.leiaString();
            if (!pessoa.equalsIgnoreCase("fim")) {
                autorizados[tamanho] = pessoa;
                tamanho++;
            }
        } while (tamanho < 200 && !pessoa.equalsIgnoreCase("fim"));
        
        // segunda etapa -- verifica autorizados
        System.out.println("\n\nVerificacao de autorizados");
        System.out.println("==========================\n");
        do {
            System.out.print("Digite o nome da pessoa que quer entrar:");
            pessoa = EntradaTecladoBasica.leiaString();
            if (!pessoa.equalsIgnoreCase("fim"))
            {
                int pos;
                for (pos = 0;
                     pos < tamanho && !pessoa.equalsIgnoreCase(autorizados[pos]);
                     pos++)
                    /* nada */ ;
                if (pos < tamanho)
                    System.out.println("Autorizado a entrar\n");
                else
                    System.out.println("Nao autorizado a entrar\n");
            }
        } while (!pessoa.equalsIgnoreCase("fim")); 
    }

}
