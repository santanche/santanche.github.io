package didatico.vetor.listaexercicios.questao06;

import java.util.Vector;

import didatico.biblioteca.EntradaTecladoBasica;

public class Questao06Modificada
{
    public static void main(String args[])
    {
        Vector<String> candidatos;
        candidatos = new Vector<String>();
        
        System.out.println("Etapa 1: Lista de Candidatos");
        System.out.println("----------------------------\n");
        
        System.out.print("Digite o nome do candidato: ");
        String nome = EntradaTecladoBasica.leiaString();
        
        while (!nome.equalsIgnoreCase("Fim"))
        {
            candidatos.addElement(nome);
            
            System.out.print("Digite o nome do candidato: ");
            nome = EntradaTecladoBasica.leiaString();
        }
        
        System.out.println("\nEtapa 2: Votacao");
        System.out.println("----------------------------\n");
        
        int tamanho = candidatos.size();
        int apuracao[] = new int[tamanho];
        
        System.out.println("Digite a lista de votos:");
        
        System.out.print("Digite seu voto (nome do candidato): ");
        String voto = EntradaTecladoBasica.leiaString();

        while (!voto.equalsIgnoreCase("Fim"))
        {
            // procura posicao do candidato no Vector
            int c;
            for (c = 0;
                 c < tamanho && !voto.equalsIgnoreCase(candidatos.elementAt(c));
                 c++)
                /* nada */ ;
            
            // registra voto no array, na posicao encontrada
            if (c < tamanho)
                apuracao[c]++;
            else
                System.out.println("Voto invalido!");

            System.out.print("Digite seu voto (nome do candidato): ");
            voto = EntradaTecladoBasica.leiaString();
        }
        
        int vencedor = 0;
        for (int v = 1; v < tamanho; v++)
            if (apuracao[v] > apuracao[vencedor])
                vencedor = v;
        
        System.out.println("O vencedor eh " + candidatos.elementAt(vencedor) +
                           " com " + apuracao[vencedor] + " votos");
    }
}
