package didatico.vetor.listaexercicios.questao06;

import didatico.biblioteca.EntradaTecladoBasica;

public class Questao06
{

    public static void main(String[] args)
    {
        int apuracao[];
        apuracao = new int[30];
        
        System.out.print("Digite seu voto: ");
        int voto = EntradaTecladoBasica.leiaInt();
        while (voto != 0)
        {
            if (voto < 0 || voto > 30)
                System.out.println("Voto invalido!");
            else
                apuracao[voto - 1]++;

            System.out.print("Digite seu voto: ");
            voto = EntradaTecladoBasica.leiaInt();
        }
        
        int maior = 0;
        for (int m = 1; m < 30; m++)
            if (apuracao[m] > apuracao[maior])
                maior = m;
        
        System.out.println("O vencedor eh: " + (maior+1) + " com " +
                           apuracao[maior] + " votos");
    }

}
