package didatico.comerciante.memoria;

import didatico.comerciante.excecoes.MercadoriaNaoDisponivel;
import didatico.comerciante.excecoes.ValorNaoDisponivel;
import didatico.comerciante.interfaces.Caixa;
import didatico.comerciante.interfaces.Cidade;
import didatico.comerciante.interfaces.Comerciante;
import didatico.comerciante.interfaces.Mercadoria;

public class CidadeMemoria_manha implements Cidade
{
    private String nomeCidade;
    private Mercadoria mercadoriasDisponiveis[];
    
    public CidadeMemoria_manha(String nomeCidade, Mercadoria mercadoriasDisponiveis[])
    {
    	this.nomeCidade = nomeCidade;
    	this.mercadoriasDisponiveis = mercadoriasDisponiveis;
    }
	
	public String getNomeCidade()
	{
		return nomeCidade;
	}

	public Mercadoria[] getMercadoriasDisponiveis()
	{
		return mercadoriasDisponiveis;
	}

	public void compraMercadoria(Comerciante comprador, String aMercadoria, float quantidade)
	            throws MercadoriaNaoDisponivel, ValorNaoDisponivel
	{
		Mercadoria disponivel = null;
		
		if (mercadoriasDisponiveis != null)
		{
			for (int m = 0; m < mercadoriasDisponiveis.length && disponivel == null; m++)
			{
				if (mercadoriasDisponiveis[m].getNome().equalsIgnoreCase(aMercadoria))
					disponivel = mercadoriasDisponiveis[m];
			}
			
			if (disponivel == null)
				throw new MercadoriaNaoDisponivel();
			else
			{
				Caixa caixaComprador = comprador.getCaixa();
				float valorCompra = quantidade * disponivel.getValorCompra();
				if (caixaComprador.getSaldo() < valorCompra)
					throw new ValorNaoDisponivel();
				else {
					caixaComprador.debitaValor(valorCompra);
					Mercadoria comprada = disponivel.entraMercadoria(quantidade);
					comprador.poeNaSacola(comprada);
				}
			}
		}
		
		
	}

	public void vendeMercadoria(Comerciante vendedor, String aMercadoria, float quantidade)
	{
		/* implementar */
	}
}
