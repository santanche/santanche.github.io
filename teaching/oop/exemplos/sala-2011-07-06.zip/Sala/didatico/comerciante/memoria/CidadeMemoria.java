package didatico.comerciante.memoria;

import didatico.comerciante.excecoes.MercadoriaNaoDisponivel;
import didatico.comerciante.excecoes.QuantidadeNaoDisponivel;
import didatico.comerciante.excecoes.ValorNaoDisponivel;
import didatico.comerciante.interfaces.Caixa;
import didatico.comerciante.interfaces.Cidade;
import didatico.comerciante.interfaces.Comerciante;
import didatico.comerciante.interfaces.Mercadoria;

public class CidadeMemoria implements Cidade
{
    private String nomeCidade;
    private Mercadoria mercadoriasDisponiveis[];
    
    public CidadeMemoria(String nomeCidade, Mercadoria mercadoriasDisponiveis[])
    {
    	this.nomeCidade = nomeCidade;
    	this.mercadoriasDisponiveis = mercadoriasDisponiveis;
    }
    
	public String getNomeCidade()
	{
		return nomeCidade;
	}

	public Mercadoria[] getMercadoriasDisponiveis()
	{
		return mercadoriasDisponiveis;
	}

	public void compraMercadoria(Comerciante comprador, String aMercadoria, float quantidade)
	            throws MercadoriaNaoDisponivel, QuantidadeNaoDisponivel, ValorNaoDisponivel
	{
		if (mercadoriasDisponiveis == null)
			throw new MercadoriaNaoDisponivel();
		else
		{
			Mercadoria disponivel = null;
			for (int m = 0; m < mercadoriasDisponiveis.length && disponivel == null; m++)
			{
				if (aMercadoria.equalsIgnoreCase(mercadoriasDisponiveis[m].getNome()))
				    disponivel = mercadoriasDisponiveis[m];
			}
			if (disponivel == null)
				throw new MercadoriaNaoDisponivel();
			else
			{
				if (disponivel.getQuantidade() < quantidade)
				    throw new QuantidadeNaoDisponivel();
				else
				{
					float preco = quantidade * disponivel.getValorCompra();
					Caixa caixaComprador = comprador.getCaixa();
					if (preco > caixaComprador.getSaldo())
						throw new ValorNaoDisponivel();
					else
					{
						caixaComprador.debitaValor(preco);
						Mercadoria comprada = disponivel.saiMercadoria(quantidade);
						comprador.poeNaSacola(comprada);
					}
				}
			}
		}
	}

	public void vendeMercadoria(Comerciante vendedor, String aMercadoria, float quantidade)
	            throws MercadoriaNaoDisponivel
	{
	}
}
