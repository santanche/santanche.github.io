package didatico.comerciante.memoria;

import didatico.comerciante.excecoes.QuantidadeNaoDisponivel;
import didatico.comerciante.interfaces.Mercadoria;

public class MercadoriaMemoria implements Mercadoria
{
    private String nome;
    private float quantidade,
                  valorCompra,
                  valorVenda;
    
    public MercadoriaMemoria(String nome, float quantidade, float valorCompra, float valorVenda)
    {
    	this.nome = nome;
    	this.quantidade = quantidade;
    	this.valorCompra = valorCompra;
    	this.valorVenda = valorVenda;
    }
    
	public String getNome()
	{
		return nome;
	}
	
	public float getQuantidade()
	{
		return quantidade;
	}

	public float getValorCompra()
	{
		return valorCompra;
	}

	public float getValorVenda()
	{
		return valorVenda;
	}

	public Mercadoria entraMercadoria(float quantidade)
	{
		this.quantidade += quantidade;
		return new MercadoriaMemoria(nome, quantidade, valorCompra, valorVenda);
	}

	public Mercadoria saiMercadoria(float quantidade) throws QuantidadeNaoDisponivel
	{
		if (quantidade > this.quantidade)
			throw new QuantidadeNaoDisponivel();
		else {
			this.quantidade -= quantidade;
			return new MercadoriaMemoria(nome, quantidade, valorCompra, valorVenda);
		}
	}
}
