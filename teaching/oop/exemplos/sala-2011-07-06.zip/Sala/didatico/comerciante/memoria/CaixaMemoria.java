package didatico.comerciante.memoria;

import didatico.comerciante.excecoes.ValorNaoDisponivel;
import didatico.comerciante.interfaces.Caixa;

public class CaixaMemoria implements Caixa
{
    private float saldo;
	
	public CaixaMemoria()
	{
		this(0);
	}
    
	public CaixaMemoria(float saldoInicial)
	{
		saldo = saldoInicial;
	}
	
	public float getSaldo()
	{
		return saldo;
	}

	public void debitaValor(float valor) throws ValorNaoDisponivel
	{
		if (valor > saldo)
			throw new ValorNaoDisponivel();
	}

	public void creditaValor(float valor)
	{
		saldo += valor;
	}
}
