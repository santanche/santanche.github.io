package didatico.comerciante.memoria;

import didatico.comerciante.interfaces.Comerciante;
import didatico.comerciante.interfaces.Mundo;

public class MundoMemoria implements Mundo
{
	private String cidadesMundo[] = {
			"Tecolandia",
			"Berilandia",
			""
	};
	
	private CidadeMemoria asCidades[];
	
	public String[] getCidadesMundo()
	{
		return cidadesMundo;
	}
	
	public void viajaParaCidade(Comerciante oComerciante, String nomeCidade)
	{
		
	}
}
