package didatico.comerciante.excecoes;

public class ValorNaoDisponivel extends Exception
{
    public ValorNaoDisponivel()
    {
    	super();
    }
    
    public ValorNaoDisponivel(String mensagem)
    {
    	super(mensagem);
    }
}
