package didatico.comerciante.excecoes;

public class MercadoriaNaoDisponivel extends Exception
{
    public MercadoriaNaoDisponivel()
    {
    	super();
    }
    
    public MercadoriaNaoDisponivel(String mensagem)
    {
    	super(mensagem);
    }
}
