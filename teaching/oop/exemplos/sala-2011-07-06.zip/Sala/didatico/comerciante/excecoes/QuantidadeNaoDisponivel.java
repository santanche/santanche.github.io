package didatico.comerciante.excecoes;

public class QuantidadeNaoDisponivel extends Exception
{
	public QuantidadeNaoDisponivel()
	{
		super();
	}

	public QuantidadeNaoDisponivel(String mensagem) {
		super(mensagem);
	}
}
