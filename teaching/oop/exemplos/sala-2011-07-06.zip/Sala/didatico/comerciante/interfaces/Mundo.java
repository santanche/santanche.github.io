package didatico.comerciante.interfaces;

public interface Mundo
{
    public String[] getCidadesMundo();
    
    public void viajaParaCidade(Comerciante oComerciante, String nomeCidade);
}
