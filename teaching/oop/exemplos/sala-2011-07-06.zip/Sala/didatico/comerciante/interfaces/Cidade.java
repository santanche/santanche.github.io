package didatico.comerciante.interfaces;

import didatico.comerciante.excecoes.MercadoriaNaoDisponivel;
import didatico.comerciante.excecoes.QuantidadeNaoDisponivel;
import didatico.comerciante.excecoes.ValorNaoDisponivel;

public interface Cidade
{
    public String getNomeCidade();

    public Mercadoria[] getMercadoriasDisponiveis();
    
    public void compraMercadoria(Comerciante comprador, String aMercadoria, float quantidade)
                throws MercadoriaNaoDisponivel, QuantidadeNaoDisponivel, ValorNaoDisponivel;
    public void vendeMercadoria(Comerciante vendedor, String aMercadoria, float quantidade)
                throws MercadoriaNaoDisponivel;
}










