package didatico.comerciante.interfaces;

import didatico.comerciante.excecoes.QuantidadeNaoDisponivel;

public interface Comerciante
{
    public Cidade getCidadeCorrente();
    public Caixa getCaixa();
    public Mercadoria[] getSacola();
    
    public void viajaParaCidade(Cidade aCidade);
    
    public void poeNaSacola(Mercadoria aMercadoria);
    public void tiraDaSacola(Mercadoria aMercadoria) throws QuantidadeNaoDisponivel;
}
