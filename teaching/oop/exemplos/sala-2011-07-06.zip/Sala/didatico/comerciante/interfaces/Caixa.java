package didatico.comerciante.interfaces;

import didatico.comerciante.excecoes.ValorNaoDisponivel;

public interface Caixa
{
    public float getSaldo();
    
    public void debitaValor(float valor) throws ValorNaoDisponivel;
    public void creditaValor(float valor);
}
