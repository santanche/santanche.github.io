package didatico.comerciante.interfaces;

import didatico.comerciante.excecoes.QuantidadeNaoDisponivel;

public interface Mercadoria
{
    public String getNome();
    public float getQuantidade();
    public float getValorCompra();
    public float getValorVenda();
    
    public Mercadoria saiMercadoria(float quantidade) throws QuantidadeNaoDisponivel;
    public Mercadoria entraMercadoria(float quantidade);
}
