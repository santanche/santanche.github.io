package didatico.armazenamento.utilidades;

import java.io.File;

public class DiretorioCorrente
{
    public static void main(String args[])
    {
        File diretorioCorrente = new File("");
        System.out.println("Diretorio corrente: " +
                           diretorioCorrente.getAbsolutePath());
    }
}
