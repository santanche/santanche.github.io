package didatico.armazenamento.bancodados.pack03prepared;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import didatico.armazenamento.bancodados.lib.Database;

public class Insercao03ComPrepare
{

    public static void main(String args[])
    {
        try {
            Database bd = Database.getInstance();
            Connection dbConexao = bd.getConnection();

            insereMarcador(dbConexao);
            
            bd.releaseConnection();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public static void insereMarcador(Connection conexao)
    {

        try {
            Scanner teclado = new Scanner(System.in);
            System.out.print("Digite o Titulo: ");
            String titulo = teclado.nextLine();
            System.out.print("Digite o Categoria: ");
            String categoria = teclado.nextLine();
            System.out.print("Digite o Endereco: ");
            String endereco = teclado.nextLine();
            System.out.print("Digite o Acessos: ");
            int acessos = Integer.parseInt(teclado.nextLine());
            
            PreparedStatement comando = conexao.prepareStatement(
                    "INSERT INTO Marcadores VALUES (?, ?, ?, ?)");

            comando.setString(1, titulo);
            comando.setString(2, categoria);
            comando.setString(3, endereco);
            comando.setInt(4, acessos);
            
            comando.executeUpdate();
            comando.close();
            
            System.out.println("Insercao executada com sucesso!");
        } catch (SQLException erro) {
            erro.printStackTrace();
        }
    }

}