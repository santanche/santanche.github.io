SELECT * FROM Marcadores;

SELECT * FROM Taxonomia;

SELECT * FROM Marcadores WHERE Titulo='Correios';