package didatico.armazenamento.bancodados.pack02taxi;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ConsultaTaxiDerbyJoin
{

    public static void main(String[] args)
    {
        try
        {
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
            Connection conexao = DriverManager.getConnection("jdbc:derby:didatico\\armazenamento\\bancodados\\bd\\cloudscape\\ltpiii;create=true", "", "");
            Statement comando = conexao.createStatement();
            ResultSet resultado = comando.executeQuery(
                    "SELECT Cl.Nome NomeCliente, Co.DataPedido, Co.Placa, T.Modelo " +
                    "FROM Cliente Cl, Corrida Co, Taxi T " +
                    "WHERE Cl.CliId = Co.CliId AND Co.Placa = T.Placa");
            
            while (resultado.next()) {
                String nome = resultado.getString("NomeCliente");
                Date dataPedido = resultado.getDate("DataPedido");
                String placa = resultado.getString("Placa");
                String modelo = resultado.getString("Modelo");
                
                System.out.print("Nome: " + nome);
                System.out.print("; Data pedido: " + dataPedido);
                System.out.print("; Placa: " + placa);
                System.out.println("; Modelo: " + modelo);
            }
            
            comando.close();
            conexao.close();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
