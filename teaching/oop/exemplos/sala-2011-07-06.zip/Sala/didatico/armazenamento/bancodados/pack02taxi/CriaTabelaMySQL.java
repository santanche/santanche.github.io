package didatico.armazenamento.bancodados.pack02taxi;

import java.sql.*;

public class CriaTabelaMySQL
{
    public static void main(String args[])
    {
         try {
            Class.forName("org.gjt.mm.mysql.Driver");
            
            Connection conexao = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/ltpiv", "root", "thelab");
           
            Statement comando = conexao.createStatement();
            
            System.out.println("criando tabela...");
            
            comando.executeUpdate("CREATE TABLE Corrida (" +
                                    "CliId INTEGER(4) UNSIGNED ZEROFILL NOT NULL, " +
                                    "Placa VARCHAR(7) NOT NULL, " +
                                    "DataPedido DATE, " +
                                    "PRIMARY KEY (CliId, Placa, DataPedido) )");
            
            System.out.println("tabela criada!");
            
            comando.close();
            conexao.close();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
