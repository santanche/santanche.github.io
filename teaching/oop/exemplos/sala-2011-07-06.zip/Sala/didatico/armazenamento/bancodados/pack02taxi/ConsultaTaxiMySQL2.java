package didatico.armazenamento.bancodados.pack02taxi;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ConsultaTaxiMySQL2
{

    public static void main(String[] args)
    {
        try
        {
            Class.forName("org.gjt.mm.mysql.Driver");
            Connection conexao = DriverManager.getConnection("jdbc:mysql://localhost:3306/sala", "root", "thelab");
            Statement comando = conexao.createStatement();
            ResultSet resultado = comando.executeQuery("SELECT * FROM Taxi");
            
            boolean existeProximo = resultado.next();
            while (existeProximo) {
                String placa = resultado.getString("Placa");
                String marca = resultado.getString("Marca");
                String modelo = resultado.getString("Modelo");
                int anofab = resultado.getInt("AnoFab");
                
                System.out.print("Placa: " + placa);
                System.out.print("; Marca: " + marca);
                System.out.print("; Modelo: " + modelo);
                System.out.println("; Ano Fabricacao: " + anofab);
                
                existeProximo = resultado.next();
            }
            
            comando.close();
            conexao.close();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
