package didatico.armazenamento.bancodados.pack02taxi;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ConsultaTaxiMySQL1
{

    public static void main(String[] args)
    {
        try
        {
            Class.forName("org.gjt.mm.mysql.Driver");
            Connection conexao = DriverManager.getConnection("jdbc:mysql://localhost:3306/sala", "root", "thelab");
            Statement comando = conexao.createStatement();
            ResultSet resultado = comando.executeQuery("SELECT * FROM Taxi");
            
            boolean existeProximo = resultado.next();
            if (existeProximo) {
                String placa = resultado.getString("Placa");
                System.out.println("Placa: " + placa);
            }
            
            comando.close();
            conexao.close();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
