package didatico.armazenamento.bancodados.pack02taxi;

import java.sql.*;

public class CriaTabelaDerby
{
    public static void main(String args[])
    {
         try {
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
            
            Connection conexao = DriverManager.getConnection(
                    "jdbc:derby:didatico\\armazenamento\\bancodados\\bd\\cloudscape\\ltpiii;create=true", "", "");
           
            Statement comando = conexao.createStatement();
            
            System.out.println("criando tabela...");
            
            comando.executeUpdate("CREATE TABLE Corrida (" +
                                    "CliId VARCHAR(4) NOT NULL, " +
                                    "Placa VARCHAR(7) NOT NULL, " +
                                    "DataPedido DATE, " +
                                    "PRIMARY KEY (CliId, Placa, DataPedido) )");
            
            System.out.println("tabela criada!");
            
            comando.close();
            conexao.close();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
