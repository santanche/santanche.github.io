package didatico.armazenamento.bancodados.pack05swing;

import java.awt.BorderLayout;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import didatico.armazenamento.bancodados.lib.Database;

public class ApresentaTabela extends JFrame
{
    private static final long serialVersionUID = -5784745538806307149L;

    /*
     * Secao da Instancia
     */
    
    JTable campoTabela;
    JScrollPane rolamento;

    Database banco;
    Connection conexao;

    public ApresentaTabela()
    {
        super();
        setBounds(0, 0, 400, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Vector<String> nomeColunas = new Vector<String>();

        nomeColunas.addElement("T�tulo");
        nomeColunas.addElement("Endere�o");
        nomeColunas.addElement("Acessos");
        nomeColunas.addElement("Categoria");

        conectaBase();

        Vector<Object> conteudo = acessaBase();

        campoTabela = new JTable(conteudo, nomeColunas);

        rolamento = new JScrollPane(campoTabela);
        rolamento.setBounds(55, 56, 325, 150);

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(rolamento, BorderLayout.CENTER);
    }


    void conectaBase()
    {
        try {
            banco = Database.getInstance();
            
            conexao = banco.getConnection();
        } catch (ClassNotFoundException erro) {
            System.out.println(erro.getMessage());
        } catch (IOException erro) {
            System.out.println(erro.getMessage());
        } catch (SQLException erro) {
            System.out.println("Erro no SQL: " + erro.getMessage());
        }
    }


    Vector<Object> acessaBase()
    {
        Vector<Object> aux = new Vector<Object>();

        try {
            Statement comando = conexao.createStatement();

            ResultSet resultado = comando.executeQuery("SELECT Titulo, Endereco, Acessos, Categoria FROM Marcadores");

            while (resultado.next())
            {
                Vector<Object> subAux = new Vector<Object>();

                subAux.addElement(resultado.getString("Titulo"));
                subAux.addElement(resultado.getString("Endereco"));
                subAux.addElement(new Integer(resultado.getInt("Acessos")));
                subAux.addElement(resultado.getString("Categoria"));

                aux.addElement(subAux);
            }
        } catch (SQLException erro) {
            System.out.println("Erro no SQL: " + erro.getMessage());
        }

        return aux;
    }
    
    /*
     * Secao Estatica da Aplicacao
     */

    static ApresentaTabela janela;

    public static void main(String argumentos[])
    {
        janela = new ApresentaTabela();
        janela.setVisible(true);
    }
}
 