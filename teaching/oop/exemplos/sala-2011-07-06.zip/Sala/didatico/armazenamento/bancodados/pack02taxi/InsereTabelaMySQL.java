package didatico.armazenamento.bancodados.pack02taxi;

import java.sql.*;

public class InsereTabelaMySQL
{
    public static void main(String args[])
    {
         try {
            Class.forName("org.gjt.mm.mysql.Driver");
            
            Connection conexao = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/ltpiii", "root", "thelab");
           
            Statement comando = conexao.createStatement();
            
            System.out.println("inserindo tabela...");
            
            comando.executeUpdate(
                    "INSERT INTO Cliente VALUES ('1830', 'Melissa', '834.521.765-22')");
            
            System.out.println("inserido!");
            
            comando.close();
            conexao.close();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
