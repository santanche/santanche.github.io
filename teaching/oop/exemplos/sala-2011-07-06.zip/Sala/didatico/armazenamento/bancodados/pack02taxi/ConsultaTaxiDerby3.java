package didatico.armazenamento.bancodados.pack02taxi;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ConsultaTaxiDerby3
{

    public static void main(String[] args)
    {
        try
        {
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
            Connection conexao = DriverManager.getConnection("jdbc:derby:didatico\\armazenamento\\bancodados\\bd\\cloudscape\\ltpiii;create=true", "", "");
            Statement comando = conexao.createStatement();
            ResultSet resultado = comando.executeQuery("SELECT * FROM Taxi");
            
            while (resultado.next()) {
                String placa = resultado.getString("Placa");
                String marca = resultado.getString("Marca");
                String modelo = resultado.getString("Modelo");
                int anofab = resultado.getInt("AnoFab");
                
                System.out.print("Placa: " + placa);
                System.out.print("; Marca: " + marca);
                System.out.print("; Modelo: " + modelo);
                System.out.println("; Ano Fabricacao: " + anofab);
            }
            
            comando.close();
            conexao.close();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
