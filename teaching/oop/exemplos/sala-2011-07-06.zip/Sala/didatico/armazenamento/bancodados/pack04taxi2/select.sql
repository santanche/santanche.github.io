-- Marca e modelo dos taxis que estao na fila
SELECT T.Marca, T.Modelo
       FROM Taxi2 T, Motorista M, Fila F 
       WHERE T.Placa = M.Placa AND
             M.CNH = F.CNH;

-- Marca e modelo dos taxis que estao na fila (sem repeticao)
SELECT DISTINCT T.Marca, T.Modelo
       FROM Taxi2 T, Motorista M, Fila F 
       WHERE T.Placa = M.Placa AND
             M.CNH = F.CNH;

-- Marca e modelo dos taxis que estao na fila com quantidades
SELECT T.Marca, T.Modelo, COUNT(*)
       FROM Taxi2 T, Motorista M, Fila F 
       WHERE T.Placa = M.Placa AND
             M.CNH = F.CNH
       GROUP BY T.Marca, T.Modelo;
             
-- Data/Hora entrada, nome e modelo dos taxis na fila
SELECT Fila.DataHoraIn, Motorista.Nome, Taxi2.Modelo
       FROM Fila, Motorista, Taxi2
       WHERE Motorista.CNH = Fila.CNH AND
             Motorista.Placa = Taxi2.Placa;

-- Quais as zonas que tem taxi na fila (com repeticao)
SELECT Fila.Zona FROM Fila;

-- Quais as zonas que tem taxi na fila (sem repeticao)
SELECT DISTINCT Fila.Zona FROM Fila;

-- Quais as zonas que tem taxi na fila (sem repeticao)
SELECT Zona
       FROM Fila
       GROUP BY Zona;

-- Quantos taxis estao na fila das zonas atendidas
SELECT Zona, COUNT(*)
       FROM Fila
       GROUP BY Zona;

-- Quantos taxis estao na fila das zonas atendidas
-- (coluna COUNT com nome)       
SELECT Zona, COUNT(*) Quantidade
       FROM Fila
       GROUP BY Zona;
       
-- Zona, quilometragem e data/hora da fila
SELECT Zona, KmIn, DataHoraIn FROM Fila;
       
-- Menor quilometragem em cada zona
SELECT Zona, MIN(KmIn) FROM Fila GROUP BY Zona;

-- Proximo taxi a ser chamado em cada zona (menor data/hora entrada)
SELECT Zona, MIN(DataHoraIn) FROM Fila
       GROUP BY Zona;

-- Maior data/hora de entrada para cada zona
SELECT Zona, MAX(DataHoraIn) FROM Fila
       GROUP BY Zona;

-- Zona, menor km, media km, maior data/hora para cada zona
SELECT Zona, MIN(KmIn), AVG(KmIn), MAX(DataHoraIn) FROM Fila
       GROUP BY Zona;
       
-- Maior data/hora dentre os taxis da zona com km <= 5000       
SELECT Zona, MAX(DataHoraIn) FROM Fila
       WHERE KmIn <= 5000 GROUP BY Zona;

-- Maior data/hora apenas para zonas cuja maxima km <= 5000
SELECT Zona, MAX(DataHoraIn) FROM Fila GROUP BY Zona
       HAVING MAX(KmIn) <= 5000;

-- Zonas que tem mais de um taxi na fila
SELECT Zona FROM Fila GROUP BY Zona HAVING COUNT(*)>1;