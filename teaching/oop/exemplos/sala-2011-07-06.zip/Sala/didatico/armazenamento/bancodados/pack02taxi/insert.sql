INSERT INTO Cliente VALUES ('1532', 'Asdr�bal', '448.754.253-65');
INSERT INTO Cliente VALUES ('1755', 'Doriana', '567.387.387-44');
INSERT INTO Cliente VALUES ('1780', 'Quincas', '546.373.762-02');

INSERT INTO Taxi VALUES ('DAE6534', 'Ford', 'Fiesta', 1999);
INSERT INTO Taxi VALUES ('DKL4598', 'Wolkswagen', 'Gol', 2001);
INSERT INTO Taxi VALUES ('DKL7878', 'Ford', 'Fiesta', 2001);
INSERT INTO Taxi VALUES ('JDM8776', 'Wolkswagen', 'Santana', 2002);
INSERT INTO Taxi VALUES ('JJM3692', 'Chevrolet', 'Corsa', 1999);

INSERT INTO Corrida VALUES ('1755', 'DAE6534', '2003-02-15');
INSERT INTO Corrida VALUES ('1780', 'JDM8776', '2003-02-18');

