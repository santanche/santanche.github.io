package didatico.armazenamento.arquivo;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

public class GravacaoArquivoTexto1i
{

    public static void main(String argumentos[])
    {
        FileWriter saida;

        try {
            saida = new FileWriter("saida.txt");

            gravaTecodonte(saida);

            saida.close();
            
            System.out.println("Gravacao concluida com sucesso");
        } catch (IOException erro) {
            System.out.println("N�o consegui criar o arquivo");
        }
    }
    
    public static void gravaTecodonte(Writer saida)
    {
        try {
            saida.write('T');
            saida.write('e');
            saida.write('c');
            saida.write('o');
            saida.write('d');
            saida.write('o');
            saida.write('n');
            saida.write('t');
            saida.write('e');
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
