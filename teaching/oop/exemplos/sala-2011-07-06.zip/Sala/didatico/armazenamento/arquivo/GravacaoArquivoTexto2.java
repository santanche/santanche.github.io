package didatico.armazenamento.arquivo;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class GravacaoArquivoTexto2
{

    public static void main(String argumentos[])
    {
        FileWriter arquivo;
        PrintWriter formatado;

        try {
            arquivo = new FileWriter("saida2.txt");

            formatado = new PrintWriter(arquivo);

            formatado.println("Tecodonte");

            formatado.close();
            
            System.out.println("Gravacao realizada com sucesso");
        } catch (IOException erro) {
            System.out.println("N�o consegui criar o arquivo");
        }
    }
}
