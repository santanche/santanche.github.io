package didatico.armazenamento.arquivo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class LeituraArquivoTexto4
{
	public static void main(String args[])
    {
		// truque para pegar a referencia do arquivo no mesmo diretoria da classe
		String nomeTexto =
		    LeituraArquivoTexto1.class.getResource(args[0]).getPath();
		
    	try {
    		FileReader arquivo = new FileReader(nomeTexto);
    	    BufferedReader entradaTexto = new BufferedReader(arquivo);
    	    
    	    String linha = entradaTexto.readLine();
    	    while (linha != null)
    	    {
    	    	System.out.println(linha);
    	    	linha = entradaTexto.readLine();
    	    }
    	    
    	    entradaTexto.close();
    	} catch (IOException erro) {
    		erro.printStackTrace();
    	}
    }
}
