package didatico.armazenamento.arquivo;

import java.io.IOException;

public class NumeraLinhasPrincipal
{
    public static void main(String args[])
    {
    	try {
    	    NumeraLinhas nl = new NumeraLinhas("entrada.txt", "saida.txt");
    	    nl.numera();
    	} catch (IOException erro1) {
    		erro1.printStackTrace();
    	} catch (Miseravao erro2) {
    		erro2.printStackTrace();
    	}
    }
}
