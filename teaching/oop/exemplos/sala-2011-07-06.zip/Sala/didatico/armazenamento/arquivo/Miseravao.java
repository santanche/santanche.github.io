package didatico.armazenamento.arquivo;

public class Miseravao extends Exception
{
    private static final long serialVersionUID = -4742970964034656270L;

    public Miseravao()
    {
    	super();
    }
    
    public Miseravao(String mensagem)
    {
    	super(mensagem);
    }
}
