package didatico.armazenamento.arquivo;

import java.io.FileReader;
import java.io.IOException;

public class LeituraArquivoTexto1
{
	public static void main(String args[])
    {
    	try {
    		FileReader arquivo = new FileReader("saida.txt");
    	    
    	    int caractere = arquivo.read();
    	    while (caractere != -1)
    	    {
    	    	System.out.println((char)caractere);
    	    	caractere = arquivo.read();
    	    }
    	    
    	    arquivo.close();
    	} catch (IOException erro) {
    		erro.printStackTrace();
    	}
    }
}
