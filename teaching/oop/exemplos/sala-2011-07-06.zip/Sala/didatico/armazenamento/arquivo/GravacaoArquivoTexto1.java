package didatico.armazenamento.arquivo;

import java.io.FileWriter;
import java.io.IOException;

public class GravacaoArquivoTexto1
{

    public static void main(String argumentos[])
    {
        FileWriter arquivo;

        try {
            arquivo = new FileWriter("saida.txt");

            arquivo.write('T');
            arquivo.write('e');
            arquivo.write('c');
            arquivo.write('o');
            arquivo.write('d');
            arquivo.write('o');
            arquivo.write('n');
            arquivo.write('t');
            arquivo.write('e');

            arquivo.close();
            
            System.out.println("Gravacao concluida com sucesso");
        } catch (IOException erro) {
            System.out.println("N�o consegui criar o arquivo");
        }
    }
}
