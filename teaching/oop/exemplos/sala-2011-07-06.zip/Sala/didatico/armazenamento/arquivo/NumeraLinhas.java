package didatico.armazenamento.arquivo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class NumeraLinhas
{
	BufferedReader br;
	PrintWriter pw;
	
	public NumeraLinhas(String arquivoEntrada, String arquivoSaida) throws IOException
    {
    	br = abreArquivoEntrada(arquivoEntrada);
    	pw = abreArquivoSaida(arquivoSaida);
    }
	
	BufferedReader abreArquivoEntrada(String nomeArquivo) throws IOException
	{
		/*
		FileReader arquivo = new FileReader(nomeArquivo);
		BufferedReader formatado = new BufferedReader(arquivo);
		return formatado;
		*/
		
		return new BufferedReader(new FileReader(nomeArquivo));
	}
	
	PrintWriter abreArquivoSaida(String nomeArquivo) throws IOException
	{
		return new PrintWriter(new FileWriter(nomeArquivo));
	}
	
	public void numera() throws Miseravao, IOException
	{
		if (br == null || pw == null)
			throw new Miseravao("Nao existe entrada ou saida");
		else {
			int nLinha = 1;
			String linha = br.readLine();
			while (linha != null) {
				pw.println(nLinha + " " + linha);
				nLinha++;
				linha = br.readLine();
			}
			br.close();
			pw.close();	
		}
			
	}
}
