/*
 * Neste exemplo sao usadas tres funcoes para leitura pelo teclado da
 * biblioteca didatico.biblioteca.EntradaTeclado.Basica.
 */

package didatico.entrada;

import didatico.biblioteca.EntradaTecladoBasica;

public class TesteEntradaTecladoBasica
{
    public static void main(String argumentos[])
    {
    	String digitadoString = null;
    	int digitadoInt = 0;
    	float digitadoFloat = 0;

    	System.out.print("Digite uma string: ");
    	digitadoString = EntradaTecladoBasica.leiaString();
    	
    	System.out.print("Digite um numero inteiro: ");
    	digitadoInt = EntradaTecladoBasica.leiaInt();
    	
    	System.out.print("Digite um numero real: ");
    	digitadoFloat = EntradaTecladoBasica.leiaFloat();
    	
    	System.out.println("==========");
    	System.out.println("Voce digitou:");
    	System.out.println("    string: " + digitadoString);
    	System.out.println("    inteiro: " + digitadoInt);
    	System.out.println("    real: " + digitadoFloat);
    }
}
