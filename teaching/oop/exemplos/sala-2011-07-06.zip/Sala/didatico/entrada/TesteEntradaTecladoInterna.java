/*
 * Neste exemplo sao criadas tres funcoes para leitura pelo teclado.
 * As tres funcoes sao testadas no modulo principal.
 */

package didatico.entrada;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class TesteEntradaTecladoInterna
{
    public static void main(String argumentos[])
    {
    	String digitadoString = null;
    	int digitadoInt = 0;
    	float digitadoFloat = 0;

    	System.out.print("Digite uma string: ");
    	digitadoString = leiaString();
    	
    	System.out.print("Digite um numero inteiro: ");
    	digitadoInt = leiaInt();
    	
    	System.out.print("Digite um numero real: ");
    	digitadoFloat = leiaFloat();
    	
    	System.out.println("==========");
    	System.out.println("Voce digitou:");
    	System.out.println("    string: " + digitadoString);
    	System.out.println("    inteiro: " + digitadoInt);
    	System.out.println("    real: " + digitadoFloat);
    }
    
    /*
     * Le uma String pelo teclado.
     * 
     * Retorna null se houver algum erro na leitura.
     */
    public static String leiaString()
    {
    	BufferedReader entrada = new BufferedReader(new InputStreamReader(System.in));
        String leitura = null;
        
    	try {
    	    leitura = entrada.readLine();
    	} catch (IOException erro) {
    	}
    	
    	return leitura;
    }
    
    /*
     * Le um numero inteiro pelo teclado.
     * 
     * Retorna zero se houver algum erro na leitura.
     */
    public static int leiaInt()
    {
        int leituraInt = 0;
    	String leituraStr = leiaString();
    	
    	if (leituraStr != null)
    	try {
    		leituraInt = Integer.parseInt(leituraStr);
    	} catch (NumberFormatException erro) {
    	}
    	
    	return leituraInt;
    }

    /*
     * Le um numero real pelo teclado.
     * 
     * Retorna zero se houver algum erro na leitura.
     */
    public static float leiaFloat()
    {
        float leituraFloat = 0;
    	String leituraStr = leiaString();
    	
    	if (leituraStr != null)
    	try {
    		leituraFloat = Float.parseFloat(leituraStr);
    	} catch (NumberFormatException erro) {
    	}
    	
    	return leituraFloat;
    }
}
