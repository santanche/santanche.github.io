package didatico.entrada;

import didatico.biblioteca.EntradaTecladoBasica;

public class CalculaDiasVida
{

    public static void main(String[] args)
    {
        int idade, diasVida;
        System.out.print("Digite sua idade: ");
        idade = EntradaTecladoBasica.leiaInt();
        diasVida = idade * 365;
        System.out.println("Voce tem aproximadamente " + diasVida + " dias de vida");
    }

}
