package didatico.excessao;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class LeituraArquivoTexto1e
{
	public static void main(String args[])
    {
	    leArquivo();
    }
	
	public static void leArquivo()
	{
	    BufferedReader entradaTexto = null;
	    
	    try {
            FileReader arquivo = new FileReader("texto.txt");
            entradaTexto = new BufferedReader(arquivo);
            
            String linha = entradaTexto.readLine();
            while (linha != null)
            {
                System.out.println(linha);
                linha = entradaTexto.readLine();
            }
        } catch (FileNotFoundException erro) {
            System.out.println("Erro: o arquivo nao existe!");
	    } catch (IOException erro) {
            erro.printStackTrace();
        } finally {
            if (entradaTexto != null)
                try {
                    entradaTexto.close();
                } catch (IOException erro) {
                    System.out.println("Erro ao fechar o arquivo.");
                }
        }
	}
}
