package didatico.excessao;

import didatico.biblioteca.EntradaTecladoBasica;

public class LeituraMesInvalida
{
    public static void main(String args[])
    {
        String mesExtenso[] = {
                "janeiro",
                "fevereiro",
                "marco",
                "abril",
                "maio",
                "junho",
                "julho",
                "agosto",
                "setembro",
                "outubro",
                "novembro",
                "dezembro"
        };
        
        try {
            int umMes = leMes();
            System.out.println("Mes por extenso: " +
                               mesExtenso[umMes - 1]);
        } catch (MesInvalidoException erro) {
            System.out.println(erro.getMessage());
        }
    }
    
    public static int leMes() throws MesInvalidoException
    {
        System.out.print("Digite o mes: ");
        int mes = EntradaTecladoBasica.leiaInt();
        
        if (mes < 1 || mes > 12)
            throw new MesInvalidoException(
                               "Mes " + mes + " invalido");
        
        return mes;
    }
}
