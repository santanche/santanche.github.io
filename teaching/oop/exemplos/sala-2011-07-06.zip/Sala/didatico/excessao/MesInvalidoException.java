package didatico.excessao;

public class MesInvalidoException extends Exception
{
    private static final long serialVersionUID = -2512571411999165845L;

    public MesInvalidoException()
    {
        super();
    }
    
    public MesInvalidoException(String message)
    {
        super(message);
    }
}
