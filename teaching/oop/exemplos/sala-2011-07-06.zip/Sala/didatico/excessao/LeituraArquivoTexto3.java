package didatico.excessao;

import java.io.BufferedReader;
import java.io.FileReader;

public class LeituraArquivoTexto3
{
	public static void main(String args[])
    {
	    try {
	        atravessador();
	    } catch (Exception erro) {
	        System.out.println("Erro no main");
	    }
    }
	
	public static void atravessador() throws Exception
	{
	    leArquivo();
	}
	
	public static void leArquivo() throws Exception
	{
        String nomeTexto = LeituraArquivoTexto3.class.getResource("texto2.txt").getPath();
    
        FileReader arquivo = new FileReader(nomeTexto);
        BufferedReader entradaTexto = new BufferedReader(arquivo);
        
        String linha = entradaTexto.readLine();
        while (linha != null)
        {
            System.out.println(linha);
            linha = entradaTexto.readLine();
        }
        
        entradaTexto.close();
	}
}
