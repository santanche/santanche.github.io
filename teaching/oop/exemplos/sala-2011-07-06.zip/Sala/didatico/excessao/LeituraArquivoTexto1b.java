package didatico.excessao;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class LeituraArquivoTexto1b
{
	public static void main(String args[])
    {
	    leArquivo();
    }
	
	public static void leArquivo()
	{
        try {
            FileReader arquivo = new FileReader("texto.txt");
            BufferedReader entradaTexto = new BufferedReader(arquivo);
            
            String linha = entradaTexto.readLine();
            while (linha != null)
            {
                System.out.println(linha);
                linha = entradaTexto.readLine();
            }
            
            entradaTexto.close();
        } catch (IOException erro) {
            System.out.println(erro.getMessage());
        }
	}
}
