package didatico.excessao;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class LeituraArquivoTexto2
{
	public static void main(String args[])
    {
	    try {
	        leArquivo();
	    } catch (IOException erro) {
	        System.out.println("Erro no main");
	    }
    }
	
	public static void leArquivo() throws IOException
	{
        FileReader arquivo = new FileReader("texto.txt");
        BufferedReader entradaTexto = new BufferedReader(arquivo);
        
        String linha = entradaTexto.readLine();
        while (linha != null)
        {
            System.out.println(linha);
            linha = entradaTexto.readLine();
        }
        
        entradaTexto.close();
	}
}
