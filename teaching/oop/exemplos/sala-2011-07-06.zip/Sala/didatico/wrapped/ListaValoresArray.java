package didatico.wrapped;

public class ListaValoresArray
{
    public static void main(String args[])
    {
        System.out.println("*** Lista com wrapper manual");
        
        Object lista1[] = new Object[4];
        
        lista1[0] = "Asdrubal";
        lista1[1] = new Integer(15);
        lista1[2] = new Float(16.4f);
        lista1[3] = new Boolean(true);
        
        for (int l = 0; l < lista1.length; l++)
            System.out.println(lista1[l]);
        
        System.out.println("\n*** Lista com wrapper automatico");
        
        Object lista2[] = new Object[4];
        
        lista2[0] = "Asdrubal";
        lista2[1] = 15;
        lista2[2] = 16.4f;
        lista2[3] = true;
        
        for (int l = 0; l < lista2.length; l++)
            System.out.println(lista2[l]);
    }
}
