package didatico.wrapped;

import java.util.Vector;

public class ListaValoresVector
{
    public static void main(String args[])
    {
        System.out.println("*** Lista com wrapper manual");
        
        Vector<Object> lista1 = new Vector<Object>();
        
        lista1.add("Asdrubal");
        lista1.add(new Integer(15));
        lista1.add(new Float(16.4f));
        lista1.add(new Boolean(true));
        
        for (Object o : lista1)
            System.out.println(o);
        
        System.out.println("\n*** Lista com wrapper automatico");
        
        Vector<Object> lista2 = new Vector<Object>();
        
        lista2.add("Asdrubal");
        lista2.add(15);
        lista2.add(16.4f);
        lista2.add(true);
        
        for (Object o : lista2)
            System.out.println(o);
    }
}
