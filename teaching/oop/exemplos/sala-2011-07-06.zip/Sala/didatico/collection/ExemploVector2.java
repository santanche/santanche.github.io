package didatico.collection;

import java.util.Vector;

public class ExemploVector2
{
    public static void main(String args[])
    {
        Vector<String> lista = new Vector<String>();

        System.out.println("*** Antes da Interface List padrao:");
        lista.addElement("Doriana");
        lista.addElement("Asdrubal");
        lista.addElement("Alcebiades");
        for (int i = 0; i < lista.size(); i++)
            System.out.println(lista.elementAt(i));
        
        System.out.println("\n*** Depois da Interface List padrao:");
        lista.add("Melissa");
        lista.add("Zandor");
        lista.add("Bonerges");
        for (int i = 0; i < lista.size(); i++)
            System.out.println(lista.get(i));
    }
}
