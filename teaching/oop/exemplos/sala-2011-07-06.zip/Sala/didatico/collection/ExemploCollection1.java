package didatico.collection;

import java.util.Collection;
import java.util.Iterator;
import java.util.Vector;

public class ExemploCollection1
{
    public static void main(String args[])
    {
        Vector<String> lista = new Vector<String>();
        
        adicionaElementos(lista);
        listaElementos(lista);
    }
    
    public static void adicionaElementos(Collection<String> lista)
    {
        lista.add("Doriana");
        lista.add("Asdrubal");
        lista.add("Alcebiades");
    }
    
    public static void listaElementos(Collection<String> lista)
    {
        System.out.println("*** Primeira versao do iterator:");
        Iterator<String> itera = lista.iterator();
        while (itera.hasNext())
            System.out.println(itera.next());
        
        System.out.println("*** Segunda versao do iterator:");
        for (String e : lista)
            System.out.println(e);
    }
}
