package didatico.collection;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Vector;

public class ExemploCollection2
{
    public static void main(String args[])
    {
        System.out.println("### Trabalhando com Vector");
        Vector<String> lista1 = new Vector<String>();
        adicionaElementos(lista1);
        listaElementos(lista1);
        
        System.out.println("\n### Trabalhando com ArrayList");
        ArrayList<String> lista2 = new ArrayList<String>();
        adicionaElementos(lista2);
        listaElementos(lista2);
        
        System.out.println("\n### Trabalhando com HashSet");
        HashSet<String> conjunto = new HashSet<String>();
        adicionaElementos(conjunto);
        listaElementos(conjunto);
    }
    
    public static void adicionaElementos(Collection<String> colecao)
    {
        colecao.add("Doriana");
        colecao.add("Asdrubal");
        colecao.add("Alcebiades");
    }
    
    public static void listaElementos(Collection<String> colecao)
    {
        System.out.println("*** Primeira versao do iterator:");
        Iterator<String> itera = colecao.iterator();
        while (itera.hasNext())
            System.out.println(itera.next());
        
        System.out.println("*** Segunda versao do iterator:");
        for (String e : colecao)
            System.out.println(e);
    }
}
