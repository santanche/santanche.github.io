package didatico.collection;

import java.util.Vector;

public class ExemploVector1
{
    public static void main(String args[])
    {
        Vector<String> lista = new Vector<String>();

        lista.addElement("Doriana");
        lista.addElement("Asdrubal");
        lista.addElement("Alcebiades");
        for (int i = 0; i < lista.size(); i++)
            System.out.println(lista.elementAt(i));
    }
}
