package didatico.collection;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Vector;

public class ExemploVectorArrayList
{
    public static void main(String args[])
    {
        System.out.println("### Trabalhando com Vector");
        Vector<String> lista1 = new Vector<String>();
        adicionaElementos(lista1);
        listaElementos(lista1);

        System.out.println("\n### Trabalhando com ArrayList");
        ArrayList<String> lista2 = new ArrayList<String>();
        adicionaElementos(lista2);
        listaElementos(lista2);
    }
    
    public static void adicionaElementos(Collection<String> lista)
    {
        lista.add("Doriana");
        lista.add("Asdrubal");
        lista.add("Alcebiades");
    }
    
    public static void listaElementos(List<String> lista)
    {
        for (int i = 0; i < lista.size(); i++)
            System.out.println(lista.get(i));
    }
}
