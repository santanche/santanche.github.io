package didatico.collection;

import java.util.Hashtable;
import java.util.Map;

public class ExemploHashtable
{
    public static void main(String args[])
    {
        Hashtable<Long,String> tabela =
                     new Hashtable<Long,String>();
        
        adicionaElementos(tabela);
        consultaElementos(tabela);
    }
    
    public static void adicionaElementos(Map<Long,String> tabela)
    {
        tabela.put(23467589756L, "Asdrubal");
        tabela.put(56372918273L, "Melissa");
        tabela.put(47658376458L, "Bonerges");
    }
    
    public static void consultaElementos(Map<Long,String> tabela)
    {
        System.out.println("cpf: 563.729.182-73; " +
                           tabela.get(56372918273L));

        System.out.println("cpf: 476.583.764-58; " +
                           tabela.get(47658376458L));

        System.out.println("cpf: 234.675.897-56; " +
                           tabela.get(23467589756L));
    }
}
