package didatico.estruturas.repeticao;

import java.util.Scanner;

public class NumerosPrimos
{

    /**
     * Verifica se um numero eh primo.
     * 
     * @param args n�o eh usado
     */
    public static void main(String[] args)
    {
        Scanner teclado = new Scanner(System.in);    
        
        System.out.print("Digite um numero: ");
        int numero = Integer.parseInt(teclado.nextLine());
        
        boolean ehPrimo = true;
        int c = 2;
        while (ehPrimo && c < numero) {
            if (numero % c == 0)
                ehPrimo = false;
            c++;
        }
        
        if (ehPrimo)
            System.out.println("� um n�mero primo");
        else
            System.out.println("N�o � um n�mero primo");
    }

}
