package didatico.estruturas.repeticao;

import didatico.biblioteca.EntradaTecladoBasica;

// Exercicio numero 06 da lista de repeticao
public class NumerosIguais
{

    public static void main(String[] args)
    {
        int numeroA, numeroB;
        
        System.out.print("Digite um numero: ");
        numeroA = EntradaTecladoBasica.leiaInt();
        
        do {
            System.out.print("Digite outro numero: ");
            numeroB = EntradaTecladoBasica.leiaInt();
        } while (numeroB != numeroA);
        
        System.out.println("Foi digitado um numero igual ao primeiro");
    }

}
