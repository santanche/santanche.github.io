package didatico.estruturas.repeticao;

import didatico.biblioteca.EntradaTecladoBasica;

// Exercicio numero 06 da lista de repeticao (adaptado para String)
public class NomesIguais
{

    public static void main(String[] args)
    {
        String nomeA, nomeB;
        
        System.out.print("Digite um nome: ");
        nomeA = EntradaTecladoBasica.leiaString();
        
        do {
            System.out.print("Digite outro nome: ");
            nomeB = EntradaTecladoBasica.leiaString();
        } while (!nomeB.equalsIgnoreCase(nomeA));
        
        System.out.println("Foi digitado um nome igual ao primeiro");
    }

}
