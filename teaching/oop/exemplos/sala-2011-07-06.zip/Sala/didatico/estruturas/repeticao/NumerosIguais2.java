package didatico.estruturas.repeticao;

import java.util.Scanner;

public class NumerosIguais2
{
    public static void main(String args[])
    {
        Scanner teclado = new Scanner(System.in);
        
        System.out.print("Digite um n�mero: ");
        int primeiroNumero = Integer.parseInt(teclado.nextLine());
        
        int numero;
        do {
            System.out.print("Digite outro n�mero: ");
            numero = Integer.parseInt(teclado.nextLine());
        } while (primeiroNumero != numero);
        
        System.out.println("*** Fim ***");
    }
}
