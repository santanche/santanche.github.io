package didatico.estruturas.repeticao;

import java.util.Scanner;

public class NomesIguais2
{

    public static void main(String[] args)
    {
        Scanner teclado = new Scanner(System.in);
        
        System.out.print("Digite um nome: ");
        String primeiroNome = teclado.nextLine();
        
        String nome;
        do {
            System.out.print("Digite outro nome: ");
            nome = teclado.nextLine();
        } while (!primeiroNome.equals(nome));
        
        System.out.println("*** Fim ***");
    }

}
