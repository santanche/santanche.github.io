package didatico.estruturas.condicional;

import didatico.biblioteca.EntradaTecladoBasica;

public class AumentoSalarialFloat
{

    /*
     Resolucao do exercicio 02 da lista de repeticao
     (com float)
     */
    public static void main(String[] args)
    {
        String nome;
        System.out.print("Digite o nome do funcionario: ");
        nome = EntradaTecladoBasica.leiaString();
        
        float salarioAtual;
        System.out.print("Digite o salario atual: ");
        salarioAtual = EntradaTecladoBasica.leiaFloat();
        
        float salarioReajustado;
        if (salarioAtual <= 150)
            salarioReajustado = salarioAtual * 1.25f;
        else if (salarioAtual <= 300)
            salarioReajustado = salarioAtual * 1.20f;
        else if (salarioAtual <= 600)
            salarioReajustado = salarioAtual * 1.15f;
        else
            salarioReajustado = salarioAtual * 1.10f;
        
        System.out.println("Nome: " + nome);
        System.out.println("Salario atual: " + salarioAtual);
        System.out.println("Salario reajustado: " + salarioReajustado);
    }

}
