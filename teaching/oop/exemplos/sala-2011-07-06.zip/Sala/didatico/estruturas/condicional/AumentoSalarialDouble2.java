package didatico.estruturas.condicional;

import java.util.Scanner;

public class AumentoSalarialDouble2
{
    /*
     Resolucao do exercicio 02 da lista de repeticao
     (com double)
     - versao sem uso da biblioteca EntradaTecladoBasica
    */
   public static void main(String args[])
   {
       String nome, strSalario;
       double salario;
       
       Scanner teclado = new Scanner(System.in);
       
       System.out.print("Digite o nome: ");
       nome = teclado.nextLine();
       
       System.out.print("Digite o sal�rio: ");
       strSalario = teclado.nextLine();
       salario = Double.parseDouble(strSalario);
       
       if (salario <= 150)
           salario *= 1.25;
       else if (salario <= 300)
           salario *= 1.2;
       else if (salario <= 600)
           salario *= 1.15;
       else
           salario *= 1.1;
       
       System.out.println(nome + " seu novo sal�rio � " + salario);
   }
}
