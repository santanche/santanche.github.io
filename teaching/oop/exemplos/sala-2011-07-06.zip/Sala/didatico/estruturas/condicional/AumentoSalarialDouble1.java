package didatico.estruturas.condicional;

import didatico.biblioteca.*;

public class AumentoSalarialDouble1
{
    /*
     Resolucao do exercicio 02 da lista de repeticao
     (com double)
     */
    public static void main(String args[])
    {
        String nome;
        double salario;
        
        System.out.print("Digite o nome: ");
        nome = EntradaTecladoBasica.leiaString();
        
        System.out.print("Digite o sal�rio: ");
        salario = EntradaTecladoBasica.leiaFloat();
        
        if (salario <= 150)
            salario *= 1.25;
        else if (salario <= 300)
            salario *= 1.2;
        else if (salario <= 600)
            salario *= 1.15;
        else
            salario *= 1.1;
        
        System.out.println(nome + " seu novo sal�rio � " + salario);
    }
}
