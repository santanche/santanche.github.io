package didatico.gerais;

public class Principal
{
    public static void main(String argumentos[])
    {
    	System.out.println(UmaClasse.quadrado(5));
    }
}
