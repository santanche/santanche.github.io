package didatico.gerais.estatico;

public class PrincipalNaoEstatico01
{
    public static void main(String[] args)
    {
        ContadorNaoEstatico contador = new ContadorNaoEstatico();
        
        for (int i = 1; i <=10; i++)
            System.out.println("Contador: " + contador.nextId());
    }
}
