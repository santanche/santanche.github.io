package didatico.gerais.estatico;

public class ContadorNaoEstatico
{
    private int lastId = 0;
    
    public int nextId()
    {
        lastId++;
        return lastId;
    }
}
