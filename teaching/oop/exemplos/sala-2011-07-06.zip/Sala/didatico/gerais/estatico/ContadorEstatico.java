package didatico.gerais.estatico;

public class ContadorEstatico
{
    private static int lastId = 0;
    
    public static int nextId()
    {
        lastId++;
        return lastId;
    }
}
