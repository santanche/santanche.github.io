package didatico.gerais.estatico;

public class PrincipalNaoEstatico02
{
    public static void main(String[] args)
    {
        ContadorNaoEstatico contadorA = new ContadorNaoEstatico(),
                            contadorB = new ContadorNaoEstatico();
        
        for (int i = 1; i <= 10; i++)
        {
            System.out.println("Contador A: " + contadorA.nextId());
            System.out.println("Contador B: " + contadorB.nextId());
        }

    }
}
