package didatico.gerais.estatico;

public class PrincipalEstatico02
{
    public static void main(String[] args)
    {
        ContadorEstatico contadorA = new ContadorEstatico(),
                         contadorB = new ContadorEstatico();
        
        for (int i = 1; i <= 10; i++)
        {
            System.out.println("Contador A: " + contadorA.nextId());
            System.out.println("Contador B: " + contadorB.nextId());
        }

    }

}
