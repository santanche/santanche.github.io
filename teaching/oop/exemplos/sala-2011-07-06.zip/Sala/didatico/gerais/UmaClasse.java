package didatico.gerais;

public class UmaClasse
{
    public static final float PI = 3.1416f;
	
	private static int contador = 0;
	
	public static int quadrado(int valor)
    {
		return valor * valor;
    }
	
	public static int proximoValor()
	{
		contador++;
		return contador;
	}
}
