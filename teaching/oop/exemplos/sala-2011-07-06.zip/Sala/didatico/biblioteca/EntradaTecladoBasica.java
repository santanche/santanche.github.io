/*
 * Biblioteca de funcoes de leitura de dados pelo teclado.
 * Estas funcoes nao acusam ocorrencia de erro na leitura.
 */
package didatico.biblioteca;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class EntradaTecladoBasica
{
    /*
     * Le uma String pelo teclado.
     * 
     * Retorna null se houver algum erro na leitura.
     */
    public static String leiaString()
    {
    	BufferedReader entrada = new BufferedReader(new InputStreamReader(System.in));
        String leitura = null;
        
    	try {
    	    leitura = entrada.readLine();
    	} catch (IOException erro) {
    	}
    	
    	return leitura;
    }
    
    /*
     * Le uma caractere pelo teclado.
     * 
     * Retorna ' ' se houver algum erro na leitura.
     */
    public static char leiaChar()
    {
    	BufferedReader entrada = new BufferedReader(new InputStreamReader(System.in));
        String leitura = null;
        
    	try {
    	    leitura = entrada.readLine();
    	} catch (IOException erro) {
    	}
    	
    	return (leitura == null || leitura.length() == 0) ? ' ' : leitura.charAt(0);
    }
    
    /*
     * Le um numero inteiro pelo teclado.
     * 
     * Retorna zero se houver algum erro na leitura.
     */
    public static int leiaInt()
    {
        int leituraInt = 0;
    	String leituraStr = leiaString();
    	
    	if (leituraStr != null)
    	try {
    		leituraInt = Integer.parseInt(leituraStr);
    	} catch (NumberFormatException erro) {
    	}
    	
    	return leituraInt;
    }

    /*
     * Le um numero real pelo teclado.
     * 
     * Retorna zero se houver algum erro na leitura.
     */
    public static float leiaFloat()
    {
        float leituraFloat = 0;
    	String leituraStr = leiaString();
    	
    	if (leituraStr != null)
    	try {
    		leituraFloat = Float.parseFloat(leituraStr);
    	} catch (NumberFormatException erro) {
    	}
    	
    	return leituraFloat;
    }
}
