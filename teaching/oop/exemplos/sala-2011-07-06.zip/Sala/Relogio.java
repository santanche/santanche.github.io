import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Timer;

public class Relogio implements ActionListener
{
    Timer tempo;
    
    public Relogio()
    {
    	System.out.println("Vou inicializar o relogio");
        tempo = new Timer(1000, this);
    	tempo.start();
    }
    
    public void actionPerformed(ActionEvent evt)
    {
    	System.out.println("passou mais um segundo");
    }
}
