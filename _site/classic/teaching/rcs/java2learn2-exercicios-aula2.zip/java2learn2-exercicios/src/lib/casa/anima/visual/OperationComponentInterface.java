package lib.casa.anima.visual;

import java.awt.Component;

public interface OperationComponentInterface
{
  public Component getVisual();
}