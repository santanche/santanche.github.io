package lib.casa.casa.util;

public interface ImageCollectionProducer
{
  public int getNumberId();
}
