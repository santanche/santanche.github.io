package lib.casa.anima.message;

public interface DCCInterface
{
  public String getIdentifier();
  public boolean taggedMessage(String theMessage);
}