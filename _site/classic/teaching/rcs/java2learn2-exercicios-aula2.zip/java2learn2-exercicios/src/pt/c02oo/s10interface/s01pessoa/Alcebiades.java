package pt.c02oo.s10interface.s01pessoa;

public class Alcebiades implements Alguem
{
    public String getNome()
    {
        return "Alcebiades";
    }
}
