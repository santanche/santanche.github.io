package pt.c02oo.s10interface.s01pessoa;

public interface Alguem
{
    public String getNome();
}
