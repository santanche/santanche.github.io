package pt.c02oo.s06heranca.s01individuo;

public class Alguem
{
    public String getNome()
    {
    	return "alguem (genericamente)";
    }
}
