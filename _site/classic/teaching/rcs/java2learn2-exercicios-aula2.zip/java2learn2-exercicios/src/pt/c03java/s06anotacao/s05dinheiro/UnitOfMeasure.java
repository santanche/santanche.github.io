package pt.c03java.s06anotacao.s05dinheiro;

public @interface UnitOfMeasure {
    public Currency value();
}
