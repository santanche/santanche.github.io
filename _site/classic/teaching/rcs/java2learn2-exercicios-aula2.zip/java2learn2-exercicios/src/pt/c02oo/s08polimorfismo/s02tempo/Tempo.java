package pt.c02oo.s08polimorfismo.s02tempo;

public class Tempo
{
    public long quantidade()
    {
        return 0;
    }

    public String toString()
    {
        return "";
    }
}
