package pt.c06patterns.factory.s07zebatata.produto;

import javax.swing.JComponent;

public interface Nariz
{
    public JComponent getVisual();
}
