package pt.c02oo.s09abstrata.s02tempo;

public abstract class Tempo
{
    public abstract long quantidade();

    public abstract String toString();
}
