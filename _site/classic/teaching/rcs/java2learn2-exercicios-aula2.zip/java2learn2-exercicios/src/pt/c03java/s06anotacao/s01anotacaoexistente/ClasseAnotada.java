package pt.c03java.s06anotacao.s01anotacaoexistente;

public class ClasseAnotada {

   @Deprecated
   public static float getPI() {
      return 3.1416f;
   }
}
