package pt.c03java.s05wrapping;

public class App01SimplesWrapping {

   public static void main(String[] args) {
      int x = 10;
      
      Integer xw = new Integer(10);
      
      Integer xwa = 10;
      
      int xa = xw;
      
      int xu = xw.intValue();

   }

}
