package pt.c06patterns.factory.s08zebatata.produto;

import javax.swing.JComponent;

public interface Boca
{
    public JComponent getVisual();
    public void abre();
    public void fecha();
}
