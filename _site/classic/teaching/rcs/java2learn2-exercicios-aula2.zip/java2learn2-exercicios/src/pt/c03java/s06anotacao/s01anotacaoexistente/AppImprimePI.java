package pt.c03java.s06anotacao.s01anotacaoexistente;

public class AppImprimePI {

   public static void main(String args[]) {
      System.out.println("Pi: " + ClasseAnotada.getPI());
   }
   
}
