package pt.c06patterns.composite;

public interface Aquatic
{
    public String aquaticImage();
}
