package pt.c02oo.s14exonline.q01generalizada;

public class Compara
{
    public static boolean eq(String p1, String p2)
    {
        return true;
    }
}
