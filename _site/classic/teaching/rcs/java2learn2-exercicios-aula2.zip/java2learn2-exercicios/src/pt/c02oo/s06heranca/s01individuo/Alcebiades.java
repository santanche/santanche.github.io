package pt.c02oo.s06heranca.s01individuo;

public class Alcebiades extends Alguem
{
    public String getNome()
    {
        return "Alcebiades";
    }
}
