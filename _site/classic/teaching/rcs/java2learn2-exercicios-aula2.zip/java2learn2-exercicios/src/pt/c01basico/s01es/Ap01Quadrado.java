package pt.c01basico.s01es;

public class Ap01Quadrado
{
    public static void main(String args[])
    {
        int numero = 5;
        System.out.println("Numero: " + numero);
        
        int quadrado = numero * numero;
        System.out.println("Quadrado do numero: " + quadrado);
    }
}
