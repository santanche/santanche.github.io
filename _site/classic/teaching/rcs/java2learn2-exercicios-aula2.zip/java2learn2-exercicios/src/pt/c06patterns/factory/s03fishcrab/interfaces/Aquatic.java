package pt.c06patterns.factory.s03fishcrab.interfaces;

public interface Aquatic
{
    public String aquaticImage();
}
