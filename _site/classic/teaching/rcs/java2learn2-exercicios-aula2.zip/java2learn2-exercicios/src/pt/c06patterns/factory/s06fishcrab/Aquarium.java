package pt.c06patterns.factory.s06fishcrab;

public interface Aquarium
{
    public String topAquarium();
    public String bottomAquarium();
}
