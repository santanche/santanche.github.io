package pt.c06patterns.factory.s05fishcrab.fish;

import pt.c06patterns.factory.s05fishcrab.Aquarium;

public class FishAquarium implements Aquarium
{
    public String topAquarium()
    {
        return "+----------------+\n" +
               "|                |";
    }


    public String bottomAquarium()
    {
        return "|                |\n" + 
               "+----------------+";
    }
}
