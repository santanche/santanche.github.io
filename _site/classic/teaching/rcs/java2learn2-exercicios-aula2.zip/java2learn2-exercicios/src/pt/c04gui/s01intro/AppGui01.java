package pt.c04gui.s01intro;

import javax.swing.JFrame;

public class AppGui01
{

    public static void main(String[] args)
    {
        JFrame janela = new JFrame();
        janela.setSize(300, 200);
        janela.setVisible(true);
        janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

}
