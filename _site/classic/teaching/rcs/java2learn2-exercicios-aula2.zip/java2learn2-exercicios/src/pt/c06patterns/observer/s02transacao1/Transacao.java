package pt.c06patterns.observer.s02transacao1;

/* Questao 01 da lista de Design Patterns e
 * questao de prova de 2015.1
 */
public interface Transacao {
   
   public void movimento(float valorMovimento);

}