package pt.c06patterns.factory.s05fishcrab;

public interface Aquarium
{
    public String topAquarium();
    public String bottomAquarium();
}
