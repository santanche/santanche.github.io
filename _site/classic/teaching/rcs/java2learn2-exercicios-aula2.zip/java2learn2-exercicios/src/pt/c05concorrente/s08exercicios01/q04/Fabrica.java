package pt.c05concorrente.s08exercicios01.q04;

public class Fabrica
{
    public static void produzLote20(int codigoProduto)
    {
        System.out.println("Produzir lote de produto " +
                           codigoProduto);
    }
}
