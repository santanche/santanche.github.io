package pt.c06patterns.factory.s05fishcrab;

public interface Aquatic
{
    public String aquaticImage();
}
