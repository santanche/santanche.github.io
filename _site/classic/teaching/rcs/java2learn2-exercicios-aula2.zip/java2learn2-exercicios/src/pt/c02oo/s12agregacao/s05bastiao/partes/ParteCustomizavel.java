package pt.c02oo.s12agregacao.s05bastiao.partes;

public interface ParteCustomizavel extends Parte
{
    public void mudaCaracteristica(String caracteristica,
                                   String valor);
}
