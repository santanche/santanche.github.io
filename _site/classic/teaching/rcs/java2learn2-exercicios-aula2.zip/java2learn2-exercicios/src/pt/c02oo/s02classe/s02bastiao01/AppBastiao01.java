package pt.c02oo.s02classe.s02bastiao01;

public class AppBastiao01
{
    public static void main(String[] args)
    {
        Bastiao theBastian;
        theBastian = new Bastiao();
        theBastian.aparece();
    }

}
