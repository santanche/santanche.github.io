package pt.c02oo.s10interface.s02tempo;

public interface Tempo
{
    public long quantidade();

    public String toString();
}
