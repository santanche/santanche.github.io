package pt.c02oo.s08polimorfismo.s06tiam;

public class App2001a {

   public static void main(String[] args) {
      Tiam machine = new Hal();
      
      machine.list();
   }

}
