package pt.c06patterns.factory.s01fishcrab;

public class Fish
{
    /*   .  _
         |\/O\
         |/\_/
     */

    public String fishImage()
    {
        return ".  _\n" +
               "|\\/O\\\n" +
               "|/\\_/\n";
    }

}
