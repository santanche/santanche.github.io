package pt.c04gui.s07eventopeixe.s02eventotexto;

public interface PeixeSubject
{
    public void addPeixeListener(PeixeListener listener);
    public void removePeixeListener(PeixeListener listener);
}