package pt.c06patterns.factory.s06fishcrab;

public interface Aquatic
{
    public String aquaticImage();
}
