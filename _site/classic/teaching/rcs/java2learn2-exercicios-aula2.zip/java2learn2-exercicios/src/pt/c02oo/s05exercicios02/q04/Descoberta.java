package pt.c02oo.s05exercicios02.q04;

public class Descoberta {

}
