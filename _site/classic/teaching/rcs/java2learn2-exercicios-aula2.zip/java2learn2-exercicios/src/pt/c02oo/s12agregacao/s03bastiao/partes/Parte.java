package pt.c02oo.s12agregacao.s03bastiao.partes;

public interface Parte
{
   public void aparece();
   public void mudaCaracteristica(String caracteristica,
                                  String valor);
}
