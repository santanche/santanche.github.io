package pt.c02oo.s09abstrata.s01pessoa;

public class Melissa extends Alguem
{
    public String getNome()
    {
        return "Melissa";
    }
}
