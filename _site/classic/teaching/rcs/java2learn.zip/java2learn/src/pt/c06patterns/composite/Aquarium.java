package pt.c06patterns.composite;

public interface Aquarium
{
    public String topAquarium();
    public String bottomAquarium();
}
