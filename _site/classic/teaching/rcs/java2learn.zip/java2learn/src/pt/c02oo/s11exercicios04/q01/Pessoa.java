package pt.c02oo.s11exercicios04.q01;

//representa genericamente uma pessoa
public interface Pessoa
{
    public String getCPF(); // retorna o CPF da pessoa
    public String getNome();  // retorna o nome da pessoa
}