package pt.c02oo.s02classe.s01circulo02;

public class Circulo {
   int centroX, centroY;
   int raio;
   
   double area() {
      return Math.PI * raio * raio;
   }
}
