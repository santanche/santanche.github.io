package pt.c02oo.s10interface.s05tiam;

public interface Tiai {
   public String first();
   public String next();
}
