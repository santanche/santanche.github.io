package pt.c02oo.s08polimorfismo.s01pessoa;

public class Alguem
{
    public String getNome()
    {
    	return "alguem (genericamente)";
    }
}
