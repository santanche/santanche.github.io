package pt.c02oo.s12agregacao.s05bastiao.partes;

public class Nariz implements Parte
{
    public void aparece()
    {
        System.out.print("*");
    }

}
