package pt.c06patterns.factory.s04fishcrab.interfaces;

public interface Aquatic
{
    public String aquaticImage();
}
