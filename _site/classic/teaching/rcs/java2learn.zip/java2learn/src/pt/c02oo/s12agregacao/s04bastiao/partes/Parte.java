package pt.c02oo.s12agregacao.s04bastiao.partes;

public abstract class Parte
{
   public abstract void aparece();
   
   public void mudaCaracteristica(String caracteristica,
                                  String valor)
   {
       /* nada */
   }
}
