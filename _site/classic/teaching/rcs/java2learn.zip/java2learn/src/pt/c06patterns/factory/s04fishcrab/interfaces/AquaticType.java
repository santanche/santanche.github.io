package pt.c06patterns.factory.s04fishcrab.interfaces;

public enum AquaticType {
   SWEET,
   MARINE
}
