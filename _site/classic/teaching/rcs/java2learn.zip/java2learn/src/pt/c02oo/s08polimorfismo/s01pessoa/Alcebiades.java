package pt.c02oo.s08polimorfismo.s01pessoa;

public class Alcebiades extends Alguem
{
    public String getNome()
    {
        return "Alcebiades";
    }
}
