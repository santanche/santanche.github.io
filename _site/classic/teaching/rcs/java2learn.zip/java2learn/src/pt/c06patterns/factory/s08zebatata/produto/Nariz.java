package pt.c06patterns.factory.s08zebatata.produto;

import javax.swing.JComponent;

public interface Nariz
{
    public JComponent getVisual();
}
