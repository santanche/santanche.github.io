package pt.c02oo.s06heranca.s01individuo;

public class Melissa extends Alguem
{
    public String getNome()
    {
        return "Melissa";
    }
}
