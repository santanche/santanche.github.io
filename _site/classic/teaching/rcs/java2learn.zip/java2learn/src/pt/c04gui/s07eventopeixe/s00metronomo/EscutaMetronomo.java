package pt.c04gui.s07eventopeixe.s00metronomo;

public interface EscutaMetronomo
{
	public void batida();
}
