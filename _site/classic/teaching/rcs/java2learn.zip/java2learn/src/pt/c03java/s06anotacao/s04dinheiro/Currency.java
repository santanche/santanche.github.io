package pt.c03java.s06anotacao.s04dinheiro;

public enum Currency {
  DOLLAR,
  REAL,
  EURO
}
