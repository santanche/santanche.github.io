package pt.c04gui.s02janela;

public class AppGui02
{

    public static void main(String[] args)
    {
        new JanelaBasica();
    }

}
