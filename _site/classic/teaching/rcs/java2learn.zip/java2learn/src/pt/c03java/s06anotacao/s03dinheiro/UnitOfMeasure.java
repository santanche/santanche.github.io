package pt.c03java.s06anotacao.s03dinheiro;

public @interface UnitOfMeasure {
    public String sigla();
    public String descricao();
}
