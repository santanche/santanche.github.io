package pt.c04gui.s07eventopeixe.s01basico;

public interface PeixeInterface
{
    public int getTamanho();
    public void setTamanho(int tamanho);
    
    public void alimenta();
}
