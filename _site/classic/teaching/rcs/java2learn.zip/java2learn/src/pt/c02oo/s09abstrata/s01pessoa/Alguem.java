package pt.c02oo.s09abstrata.s01pessoa;

public abstract class Alguem
{
    public abstract String getNome();
}
