package pt.c04gui.s06eventobotao;

public class AppGui05
{

    public static void main(String[] args)
    {
        new JanelaBotaoTexto();
        
    }

}
