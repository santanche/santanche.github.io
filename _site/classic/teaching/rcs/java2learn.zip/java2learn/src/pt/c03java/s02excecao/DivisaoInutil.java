package pt.c03java.s02excecao;

public class DivisaoInutil extends Exception {
	
	public DivisaoInutil() {
		super();
	}
	
	public DivisaoInutil(String message) {
		super(message);
	}
}