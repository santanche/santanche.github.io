package pt.c06patterns.builder.leitortexto.versao1;

public interface TextoAbstractBuilder
{
    public void insereLinha(String linha);
}
