package pt.c02oo.s09abstrata.s05tiam;

public class App2001b {

   public static void main(String[] args) {
      Tiam machine = new Hal();
      
      machine.list();
   }

}
