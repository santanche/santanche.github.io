package pt.c02oo.s12agregacao.s05bastiao.partes;

public interface Parte
{
   public void aparece();
}
