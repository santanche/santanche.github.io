package pt.c02oo.s10interface.s01pessoa;

public class Melissa implements Alguem
{
    public String getNome()
    {
        return "Melissa";
    }
}
