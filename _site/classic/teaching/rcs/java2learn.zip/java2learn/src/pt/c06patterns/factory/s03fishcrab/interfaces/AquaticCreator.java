package pt.c06patterns.factory.s03fishcrab.interfaces;


public interface AquaticCreator {

   public Aquatic createAquatic();

}
