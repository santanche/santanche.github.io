package pt.c04gui.s03campotexto1;

public class AppGui03
{

    public static void main(String[] args)
    {
        JanelaTexto janela = new JanelaTexto();
        
        janela.insereLina("Tum tum");
        janela.insereLina("Quem eh?");
        janela.insereLina("Sou eu");
    }

}
