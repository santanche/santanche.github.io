package pt.c02oo.s05exercicios02.q04;

public class Gabarito
{
    public char respostaQuestao(int numeroQuestao)
    {
        return ' ';
    }
}
