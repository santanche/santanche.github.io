package pt.c02oo.s06heranca.s02tempo;

public class Tempo {
}
