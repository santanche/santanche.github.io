package pt.c04gui.s07eventopeixe.s03eventografico;

public interface PeixeInterface
{
    public int getTamanho();
    public void setTamanho(int tamanho);
    
    public void alimenta();
}
