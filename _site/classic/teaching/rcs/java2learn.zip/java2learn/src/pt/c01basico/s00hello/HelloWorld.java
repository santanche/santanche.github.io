package pt.c01basico.s00hello;

public class HelloWorld {
  public static void main(String args[]) {
	  System.out.println("O dinossauro pulou na lama.");
  }
}
