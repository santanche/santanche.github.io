package pt.c06patterns.factory.s02fishcrab;

public interface Aquatic
{
    public String aquaticImage();
}
