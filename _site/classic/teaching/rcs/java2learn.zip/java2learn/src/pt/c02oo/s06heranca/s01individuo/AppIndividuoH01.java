package pt.c02oo.s06heranca.s01individuo;

public class AppIndividuoH01 {

	public static void main(String[] args) {
        Alguem a = new Alguem();
        Alcebiades b = new Alcebiades();
        Melissa c = new Melissa();
        
        System.out.println("Nome a: " + a.getNome());
        System.out.println("Nome b: " + b.getNome());
        System.out.println("Nome c: " + c.getNome());
	}

}
