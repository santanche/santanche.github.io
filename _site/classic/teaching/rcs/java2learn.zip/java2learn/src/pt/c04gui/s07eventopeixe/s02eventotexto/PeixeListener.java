package pt.c04gui.s07eventopeixe.s02eventotexto;

import java.util.EventListener;

public interface PeixeListener extends EventListener
{
    public void novoTamanho(int tamanho);
}
