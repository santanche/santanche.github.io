package lib.casa.casa.component.image;

public interface ImageComponent
{
}
