#include <stdio.h>

int main()
{
   int resultado = (4.0 / 8) * 8;
   printf("resultado: %d", resultado);

   return 0;
}
