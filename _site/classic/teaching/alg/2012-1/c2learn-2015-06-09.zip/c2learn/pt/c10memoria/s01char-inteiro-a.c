#include <stdio.h>

int main() {
   unsigned char n;

   printf("Digite um numero: ");
   scanf("%d", &n);

   printf("Voce digitou: %c", n);

   return 0;
}
