#include <stdio.h>

int main() {
   char login[51];

   puts("Digite seu login: ");
   gets(login);

   puts("Voce esta logado");
   return 0;
}
