void iniciaTestes();
void testeChar(char valorTeste, char valorReferencia);
void testeInt(int valorTeste, int valorReferencia);
void testeLong(long valorTeste, long valorReferencia);
void testeFloat(float valorTeste, float valorReferencia);
void testeDouble(double valorTeste, double valorReferencia) ;
void testeStr(char *valorTeste, char *valorReferencia);
void relatorioTestes();
