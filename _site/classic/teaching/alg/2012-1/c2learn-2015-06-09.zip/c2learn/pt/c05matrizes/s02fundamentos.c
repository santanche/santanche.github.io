#include <stdio.h>

int main() {
   int vetor[5];

   printf("Digite um valor: ");
   scanf("%d", &vetor[0]);
   printf("Digite um valor: ");
   scanf("%d", &vetor[1]);
   printf("Digite um valor: ");
   scanf("%d", &vetor[2]);
   printf("Digite um valor: ");
   scanf("%d", &vetor[3]);
   printf("Digite um valor: ");
   scanf("%d", &vetor[4]);

   // printf("Voce digitou: %d", vetor[1]);

   return 0;
}
