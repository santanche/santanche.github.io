#include <stdio.h>

int main() {
   int x = 5;

   printf("x: %d", x);

   return 0;
}
