#include <stdio.h>

int main() {
   int cont = 1;

   while (cont <= 5) {
      printf("%d ", cont);
      cont++;
   }

   return 0;
}
