#include <stdio.h>

int main()
{
   float resultado = (int)(7.0 / 4);
   printf("resultado: %f", resultado);

   return 0;
}
