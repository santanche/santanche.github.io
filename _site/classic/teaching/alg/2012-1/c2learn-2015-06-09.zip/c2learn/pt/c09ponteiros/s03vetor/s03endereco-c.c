#include <stdio.h>

int main() {
   int x[5] = {3, 4, 8, 7, 9};

   printf("%d", *(x+3));

   return 0;
}
