#include <stdio.h>

int main() {
   int cont = 0;

   cont++;
   printf("%d ", cont);
   cont++;
   printf("%d ", cont);
   cont++;
   printf("%d ", cont);
   cont++;
   printf("%d ", cont);
   cont++;
   printf("%d ", cont);

   return 0;
}
