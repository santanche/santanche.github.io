#include <stdio.h>

int main()
{
   float resultado = 5.0 / 4;
   printf("resultado: %f", resultado);

   return 0;
}
