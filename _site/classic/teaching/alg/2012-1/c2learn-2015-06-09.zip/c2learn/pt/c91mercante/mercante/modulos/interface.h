int mainMenu();
void showEstado();
void ativaOpcao(int opcao);
void iPrograma();
