#include <stdio.h>

int main() {
   int x;

   x = 1;
   printf("%d ", x);
   x = 2;
   printf("%d ", x);
   x = 3;
   printf("%d ", x);
   x = 4;
   printf("%d ", x);
   x = 5;
   printf("%d ", x);

   return 0;
}
