#include <stdio.h>

int main() {
   int x = 0;

   x++;
   printf("%d ", x);
   x++;
   printf("%d ", x);
   x++;
   printf("%d ", x);
   x++;
   printf("%d ", x);
   x++;
   printf("%d ", x);

   return 0;
}
