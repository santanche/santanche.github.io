#include <stdio.h>

main()
{
    char nome[100];

    printf("Digite um nome: ");
    scanf("%s", nome);
    printf("Bem vindo ao clube %s \n", nome);
}
