#include <stdio.h>

int main()
{
   int resultado = ((float)4 / 8) * 8;
   printf("resultado: %d", resultado);

   return 0;
}
