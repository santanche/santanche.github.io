#include <stdio.h>

int main() {
   int cont = 0;

   do {
      cont++;
      printf("%d ", cont);
   } while (cont < 5);

   return 0;
}
