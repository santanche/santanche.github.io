#include <stdio.h>

int main() {
   int cont = 0;

   while (cont < 5) {
      cont++;
      printf("%d ", cont);
   }

   return 0;
}
