#include <stdio.h>

int main() {
   int cont;

   for (cont = 1; cont <= 5; cont++)
      printf("%d ", cont);

   return 0;
}
