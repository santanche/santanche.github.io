#include <stdio.h>

int main()
{
    int a;
    a = 3;
    printf("Valor de a: %d", a);
    
    return 0;
}
