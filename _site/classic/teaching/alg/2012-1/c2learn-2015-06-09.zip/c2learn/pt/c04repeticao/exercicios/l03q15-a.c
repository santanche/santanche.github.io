#include <stdio.h>

int main() {
   int segundos = 0;

   while (segundos < 60) {
      printf("%d\n", segundos);
      segundos++;
   }

   return 0;
}
