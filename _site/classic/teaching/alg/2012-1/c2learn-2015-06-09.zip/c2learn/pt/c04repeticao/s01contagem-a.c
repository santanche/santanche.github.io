#include <stdio.h>

int main() {
   printf("%d ", 1);
   printf("%d ", 2);
   printf("%d ", 3);
   printf("%d ", 4);
   printf("%d ", 5);

   return 0;
}
