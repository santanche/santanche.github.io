/*
Serie de Programas: Modularizacao progressiva

Header usado pelo programa bits05.c
*/

void inicializa();
int proximoNumeroCombinacoes();
