#include <stdio.h>

int main()
{
   float resultado = 5.0 / 4;
   printf("resultado: %.2f", resultado);

   return 0;
}
