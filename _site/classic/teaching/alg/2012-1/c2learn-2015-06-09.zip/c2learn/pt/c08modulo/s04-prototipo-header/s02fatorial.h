int calculaFatorial(int numero);
