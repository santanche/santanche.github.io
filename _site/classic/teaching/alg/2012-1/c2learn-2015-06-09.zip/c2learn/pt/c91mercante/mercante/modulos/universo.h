int registro(char* nomePlaneta, char* chavePrivada);
