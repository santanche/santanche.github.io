#include <stdio.h>

main()
{
    int valor, quadrado;

    printf("Digite um numero: ");
    scanf("%d", &valor);
    quadrado = valor*valor;
    printf("O quadrado deste numero eh: %d \n", quadrado);
}
