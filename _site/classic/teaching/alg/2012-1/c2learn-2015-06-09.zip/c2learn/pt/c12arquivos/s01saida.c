#include <stdio.h>

int main() {
   printf("Doriana %d\n", 7800);
   printf("Quincas %d\n", 3200);
   printf("Zandor %d\n", 1800);

   return 0;
}
