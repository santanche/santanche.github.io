#include <stdio.h>

int main()
{
   int resultado = (4 / 8) * 8;
   printf("resultado: %d", resultado);

   return 0;
}
