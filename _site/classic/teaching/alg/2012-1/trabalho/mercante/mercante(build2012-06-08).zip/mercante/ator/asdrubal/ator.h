void programa();
int ativaAtor(char* strInstrucao,
              char *paramStr, int paramInt, int valor);
int quadrado(int numero);
int cadastra(char *nome);
int aposta(char *nome, int valor);
void autoteste();
