#include "linguagem.h"

static char *instrucoes[TOTAL_INSTRUCOES] = {
   "viaja",
   "indica",
   "compra",
   "vende",
   "saca"
};

char** getInstrucoes() {
   return instrucoes;
}
