#define TOTAL_INSTRUCOES 5

typedef enum {
   instrDesconhecida = -1,
   instrViaja,
   instrIndica,
   instrCompra,
   instrVende,
   instrSaca
} TipoInstrucao;

char** getInstrucoes();
