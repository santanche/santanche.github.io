#define CAPACIDADE_NAVE 10

void inicializaNave();
int getCelulasOcupadas();
int getCelulasLivres();
int* getCelulas();
int ocupaCelula(TipoMercadoria mercadoria, int quantidade);
int desocupaCelula(TipoMercadoria mercadoria, int quantidade);
int mercadoriaNaNave();
