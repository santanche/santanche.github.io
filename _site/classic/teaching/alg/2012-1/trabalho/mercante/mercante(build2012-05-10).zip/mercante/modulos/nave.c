#include "mercadoria.h"
#include "nave.h"
#include "status.h"

static int celula[TOTAL_MERCADORIAS];
static int celulasOcupadas = 0;

void inicializaNave() {
   int c;
   for (c = 0; c < TOTAL_MERCADORIAS; c++)
      celula[c] = 0;
}

int getCelulasOcupadas() {
   return celulasOcupadas;
}

int getCelulasLivres() {
   return CAPACIDADE_NAVE - celulasOcupadas;
}

int* getCelulas() {
   return celula;
}

int ocupaCelula(TipoMercadoria mercadoria, int quantidade) {
   int status = STATUS_SUCESSO;
   if (celulasOcupadas + quantidade > CAPACIDADE_NAVE)
      status = STATUS_NAVE_CHEIA;
   else if (mercadoria <= merNada && mercadoria >= TOTAL_MERCADORIAS)
      status = STATUS_MERCADORIA_INEXISTENTE;
   else {
      celulasOcupadas += quantidade;
      celula[mercadoria] += quantidade;
   }

   return status;
}

int desocupaCelula(TipoMercadoria mercadoria, int quantidade) {
   int status = STATUS_SUCESSO;
   if (mercadoria <= merNada && mercadoria >= TOTAL_MERCADORIAS)
      status = STATUS_MERCADORIA_INEXISTENTE;
   else if (celula[mercadoria] < quantidade)
      status = STATUS_MERCADORIA_INSUFICIENTE;
   else {
      celulasOcupadas -= quantidade;
      celula[mercadoria] -= quantidade;
   }

   return status;
}

int mercadoriaNaNave() {
   int m = 0;
   int mercadoriaIndicada = getMercadoriaIndicada();
   if (mercadoriaIndicada > merNada)
      m = celula[mercadoriaIndicada];
   return m;
}
