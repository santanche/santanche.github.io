#define TOTAL_INICIAL_PLANETAS 12
#define TOTAL_MAXIMO_PLANETAS 100
#define PRECO_PASSAGEM  5

typedef enum {
   plaNada = -1,
   plaMantor,
   plaZintor,
   plaAsdropolis,
   plaZeta,
   plaBantor,
   plaTander,
   plaNova,
   plaPindora,
   plaCastor,
   plaRa,
   plaRe,
   plaRi
} TipoPlaneta;

typedef struct {
   int preco,
       disponivel;
} RegMercadoriaPlaneta;

typedef struct {
   RegMercadoriaPlaneta *mercadorias;
} RegPlaneta;

int getNumeroPlanetas();
char** getNomePlanetas();
char* getNomePlaneta(TipoPlaneta planeta);
void iGetNomePlanetas();
RegPlaneta* getDadosPlanetas();
void inicializaPlanetas();
RegMercadoriaPlaneta* precosPlaneta();
void adicionaPlaneta(char *nomePlaneta);
