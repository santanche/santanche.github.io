#define TOTAL_MERCADORIAS 5

typedef enum {
   merNada = -1,
   merCabeca,
   merCorpo,
   merBraco,
   merPerna,
   merRobo
} TipoMercadoria;

typedef struct {
   int  basePreco,
        variacaoPreco,
        baseDisponivel,
        variacaoDisponivel;
} RegMercadoria;

char** getNomeMercadorias();
char* getNomeMercadoria(TipoMercadoria mercadoria);
RegMercadoria* getDadosMercadorias();
int indicaMercadoria(TipoMercadoria mercadoria);
void iIndicaMercadoria();
TipoMercadoria getMercadoriaIndicada();
char *getNomeMercadoriaIndicada();
