#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "caixa.h"
#include "mercadoria.h"
#include "planeta.h"
#include "robo.h"
#include "linguagem.h"

#include "ator01.h"

void programa() {
   /** Programa de exemplo, deve ser substituido pelo trabalho **/

   // use este comando para obter a lista das instrucoes
   char** instrucoes = getInstrucoes();
   int i;
   printf("Lista de instrucoes: ");
   for (i = 0; i < TOTAL_INSTRUCOES; i++)
      printf("%s; ", instrucoes[i]);
   printf("\n\n");

   // viaja(plaTander);
   executaInstrucao("viaja", instrViaja, "Tander", plaTander);

   // indicaMercadoria(merBraco);
   executaInstrucao("indica", instrIndica, "braco", merBraco);

   // compraMercadoria(5);
   executaInstrucao("compra", instrCompra, "5", 5);

   // viaja(plaBantor);
   executaInstrucao("viaja", instrViaja, "Bantor", plaBantor);

   // vendeMercadoria(5);
   executaInstrucao("vende", instrVende, "5", 5);
}

void executaInstrucao(char* strInstrucao, TipoInstrucao codInstrucao,
                      char *paramStr, int paramInt) {
   printf("{%s,%d,%s,%d} ", strInstrucao, codInstrucao,
                          paramStr, paramInt);

   switch (codInstrucao) {
      case instrViaja: viaja(paramInt); break;
      case instrIndica: indicaMercadoria(paramInt); break;
      case instrCompra: compraMercadoria(paramInt); break;
      case instrVende: vendeMercadoria(paramInt); break;
      case instrSaca: saca(paramInt); break;
      default: break;
   }
}
