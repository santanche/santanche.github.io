void programa();
void executaInstrucao(char* strInstrucao, int codInstrucao,
                      char *paramStr, int paramInt);
