int getSaldoCaixa();
int debitaCaixa(int valor);
int creditaCaixa(int valor);
int saca(int valor);
