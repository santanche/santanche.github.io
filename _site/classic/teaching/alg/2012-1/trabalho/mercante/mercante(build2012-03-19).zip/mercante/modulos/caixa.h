int getSaldoCaixa();
int debitaCaixa(int valor);
