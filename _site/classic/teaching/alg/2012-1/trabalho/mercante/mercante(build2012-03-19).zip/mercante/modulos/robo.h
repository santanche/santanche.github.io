int compraMercadoria(int quantidade);
void iCompraMercadoria();
