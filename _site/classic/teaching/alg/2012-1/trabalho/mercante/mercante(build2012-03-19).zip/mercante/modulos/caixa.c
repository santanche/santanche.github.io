#include "status.h"

static int saldoCaixa = 500;

int getSaldoCaixa() {
   return saldoCaixa;
}

int debitaCaixa(int valor) {
   int status = STATUS_SUCESSO;
   if (saldoCaixa < valor)
      status = STATUS_SALDO_INSUFICIENTE;
   else
      saldoCaixa -= valor;
   return status;
}
