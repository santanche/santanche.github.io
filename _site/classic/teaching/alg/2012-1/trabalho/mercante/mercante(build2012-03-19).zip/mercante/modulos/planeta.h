#define TOTAL_PLANETAS 12
#define PRECO_PASSAGEM 20

typedef enum {
   plaMantor,
   plaZintor,
   plaAsdropolis,
   plaZeta,
   plaBantor,
   plaTander,
   plaNova,
   plaPindora,
   plaCastor,
   plaRa,
   plaRe,
   plaRi
} TipoPlaneta;

typedef struct {
   int preco,
       disponivel;
} RegMercadoriaPlaneta;

typedef struct {
   RegMercadoriaPlaneta *mercadorias;
} RegPlaneta;

char** getNomePlanetas();
void iGetNomePlanetas();
int getPlanetaCorrente();
RegPlaneta* getDadosPlanetas();
char* getNomePlanetaCorrente();
void inicializaPlanetas();
void showMercadorias();
int viaja(TipoPlaneta destino);
void iViaja();
