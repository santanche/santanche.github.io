#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "status.h"
#include "planeta.h"
#include "caixa.h"
#include "mercadoria.h"

static char* nomePlaneta[TOTAL_PLANETAS] = {
   "Mantor",
   "Zintor",
   "Asdropolis",
   "Zeta",
   "Bantor",
   "Tander",
   "Nova",
   "Pindora",
   "Castor",
   "Ra",
   "Re",
   "Ri"
};

static RegPlaneta dadosPlanetas[TOTAL_PLANETAS];

static int planetaCorrente = plaMantor;

char** getNomePlanetas() {
   return nomePlaneta;
}

void iGetNomePlanetas() {
   puts("\n+-----------------+");
   puts(  "|   [PLANETAS]    |");
   puts(  "| nn | planeta    |");
   puts(  "+----+------------+");
   int p;
   for (p = 0; p < TOTAL_PLANETAS; p++)
      printf("| %2d | %-10s |\n", p, nomePlaneta[p]);
   puts(  "+-----------------+");
}

RegPlaneta* getDadosPlanetas() {
   return dadosPlanetas;
}

int getPlanetaCorrente() {
   return planetaCorrente;
}

char* getNomePlanetaCorrente() {
   return nomePlaneta[planetaCorrente];
}

void inicializaPlanetas() {
   RegMercadoria *dadosMercadorias = getDadosMercadorias();

   srand (time(NULL));

   int p;
   for (p = 0; p < TOTAL_PLANETAS; p++) {
      dadosPlanetas[p].mercadorias =
         malloc(sizeof(RegMercadoriaPlaneta)*TOTAL_MERCADORIAS);
      int m;
      for (m = 0; m < TOTAL_MERCADORIAS; m++) {
         dadosPlanetas[p].mercadorias[m].preco =
            dadosMercadorias[m].basePreco +
            (rand() % dadosMercadorias[m].variacaoPreco);
         dadosPlanetas[p].mercadorias[m].disponivel =
            dadosMercadorias[m].baseDisponivel +
            (rand() % dadosMercadorias[m].variacaoDisponivel);
      }
   }
}

void iGetMercadoriasPlaneta() {
   puts("\n+---------------------------------+");
   puts(  "|          [MERCADORIAS]          |");
   puts(  "| nn | mercadoria | preco | quant |");
   puts(  "|----|------------|-------|-------|");

   RegMercadoria *dadosMercadorias = getDadosMercadorias();

   int m;
   for (m = 0; m < TOTAL_MERCADORIAS; m++)
      printf("| %2d | %-10s | %5d | %5d |\n",
             m, dadosMercadorias[m].nome,
             dadosPlanetas[planetaCorrente].mercadorias[m].preco,
             dadosPlanetas[planetaCorrente].mercadorias[m].disponivel);

   puts("+---------------------------------+");
}

int viaja(TipoPlaneta destino) {
   int status = STATUS_SUCESSO;
   if (destino < 0 || destino >= TOTAL_PLANETAS)
      status = STATUS_PLANETA_INEXISTENTE;
   else {
      planetaCorrente = destino;
      status = debitaCaixa(PRECO_PASSAGEM);
   }
   return status;
}

void iViaja() {
   int nPlaneta;
   puts("\n>>>>>>>>>>");
   printf("> planeta destino: ");
   scanf("%d", &nPlaneta);

   int status = viaja(nPlaneta);
   if (status == STATUS_SUCESSO)
      puts("> Viagem realizada com sucesso.");
   else if (status == STATUS_SALDO_INSUFICIENTE)
      puts("> Voce nao tem dinheiro suficiente para viajar.");
   else if (status == STATUS_PLANETA_INEXISTENTE)
      puts("> O planeta destino escolhido nao existe.");

   puts(">>>>>>>>>>");
}
