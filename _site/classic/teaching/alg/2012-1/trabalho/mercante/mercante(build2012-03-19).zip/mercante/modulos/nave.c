#include "mercadoria.h"
#include "nave.h"
#include "status.h"

static RegCelula celula[CAPACIDADE_NAVE];
static int celulasOcupadas = 0;

int getCelulasOcupadas() {
   return celulasOcupadas;
}

RegCelula* getCelulas() {
   return celula;
}

int ocupaCelula(TipoMercadoria mercadoria, int quantidade) {
   celulasOcupadas++;
   celula[celulasOcupadas-1].mercadoria = mercadoria;
   celula[celulasOcupadas-1].quantidade = quantidade;

   return STATUS_SUCESSO;
}
