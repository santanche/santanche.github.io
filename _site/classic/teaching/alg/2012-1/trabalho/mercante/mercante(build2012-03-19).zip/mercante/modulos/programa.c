#include "caixa.h"
#include "mercadoria.h"
#include "planeta.h"
#include "robo.h"

/* === Funcoes
int getSaldoCaixa()
int indicaMercadoria(TipoMercadoria mercadoria)
int viaja(TipoPlaneta destino)
int compraMercadoria(int quantidade)
*/

/* === Planetas
typedef enum {
   plaMantor,
   plaZintor,
   plaAsdropolis,
   plaZeta,
   plaBantor,
   plaTander,
   plaNova,
   plaPindora,
   plaCastor,
   plaRa,
   plaRe,
   plaRi
} TipoPlaneta;
*/

/* === Mercadorias
typedef enum {
   merCabeca,
   merCorpo,
   merBraco,
   merPerna,
   merRobo,
   merNada
} TipoMercadoria;
*/
void programa() {

}
