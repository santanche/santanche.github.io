#include "planeta.h"
#include "mercadoria.h"
#include <stdio.h>

int main()
{
   inicializaPlanetas();

   int opcao = 0;
   do {
      opcao = mainMenu();
   } while (opcao != 9);

   return 0;
}
