#define TOTAL_MERCADORIAS 5

typedef enum {
   merCabeca,
   merCorpo,
   merBraco,
   merPerna,
   merRobo,
   merNada
} TipoMercadoria;

typedef struct {
   char *nome;
   int  basePreco,
        variacaoPreco,
        baseDisponivel,
        variacaoDisponivel;
} RegMercadoria;

RegMercadoria* getDadosMercadorias();
int indicaMercadoria(TipoMercadoria mercadoria);
void iIndicaMercadoria();
TipoMercadoria getMercadoriaIndicada();
char *getNomeMercadoriaIndicada();
