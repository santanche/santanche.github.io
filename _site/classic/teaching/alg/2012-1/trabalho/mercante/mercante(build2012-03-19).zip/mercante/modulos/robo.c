#include "planeta.h"
#include "caixa.h"
#include "mercadoria.h"
#include "nave.h"
#include "robo.h"
#include "status.h"

int compraMercadoria(int quantidade) {
   int status = STATUS_SUCESSO;

   int planetaCorrente = getPlanetaCorrente();
   TipoMercadoria mercadoriaIndicada = getMercadoriaIndicada();
   RegPlaneta *dadosPlaneta = getDadosPlanetas();
   RegMercadoriaPlaneta dadosIndicada =
      dadosPlaneta[planetaCorrente].mercadorias[mercadoriaIndicada];

   int gasto = quantidade * dadosIndicada.preco;
   if (quantidade <= dadosIndicada.disponivel &&
       gasto <= getSaldoCaixa()) {
      debitaCaixa(gasto);
      ocupaCelula(mercadoriaIndicada, quantidade);
   } else
      status = STATUS_SALDO_INSUFICIENTE;

   return status;
}

void iCompraMercadoria() {
   int quantidade;
   puts("\n>>>>>>>>>>");
   printf("> quantidade: ");
   scanf("%d", &quantidade);

   int status = compraMercadoria(quantidade);
   if (status == STATUS_SUCESSO)
      puts("> Compra realizada com sucesso.");
   else if (status == STATUS_SALDO_INSUFICIENTE)
      puts("> Voce nao tem dinheiro suficiente para comprar.");

   puts(">>>>>>>>>>");
}
