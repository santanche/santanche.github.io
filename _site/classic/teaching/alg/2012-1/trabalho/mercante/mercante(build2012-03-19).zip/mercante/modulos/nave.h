#define CAPACIDADE_NAVE 10

typedef struct {
   TipoMercadoria mercadoria;
   int quantidade;
} RegCelula;

int getCelulasOcupadas();
RegCelula* getCelulas();
int ocupaCelula(TipoMercadoria mercadoria, int quantidade);
