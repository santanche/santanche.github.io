#include "planeta.h"
#include "mercadoria.h"
#include "caixa.h"
#include "nave.h"
#include "robo.h"
#include "programa.h"

int mainMenu() {
   int opcao;

   showEstado();

   puts("1. Relacao de planetas");
   puts("2. Viajar");
   puts("3. Mercadorias no planeta");
   puts("4. Indicar mercadoria");
   puts("5. Comprar mercadoria");
   puts("8. Ativa programa");
   puts("9. Sair");

   printf("Digite sua opcao: ");
   scanf("%d", &opcao);

   ativaOpcao(opcao);

   return opcao;
}

void showEstado() {
   puts("\n#==================================#");
   printf("# planeta: %-23s #\n", getNomePlanetaCorrente());
   printf("# caixa:   %-23d #\n", getSaldoCaixa());

   if (getMercadoriaIndicada() != merNada)
      printf("# mercadoria indicada: %-10s  #\n",
             getNomeMercadoriaIndicada());

   int ocupadas = getCelulasOcupadas();
   if (ocupadas > 0) {
      puts("# ocupacao da nave:                #");
      puts("# | mercadoria | quant |           #");
      puts("# +------------+-------+           #");
   }

   RegCelula* celula = getCelulas();
   RegMercadoria* dadosMercadoria = getDadosMercadorias();
   int c;
   for (c = 0; c < ocupadas; c++)
      printf("# | %-10s | %5d |           #\n",
             dadosMercadoria[celula[c].mercadoria].nome,
             celula[c].quantidade);

   puts(  "#==================================#\n");
}

void ativaOpcao(int opcao) {
    switch (opcao) {
       case 1 : iGetNomePlanetas(); break;
       case 2 : iViaja(); break;
       case 3 : iGetMercadoriasPlaneta(); break;
       case 4 : iIndicaMercadoria(); break;
       case 5 : iCompraMercadoria(); break;
       case 8 : programa(); break;
    }
}
