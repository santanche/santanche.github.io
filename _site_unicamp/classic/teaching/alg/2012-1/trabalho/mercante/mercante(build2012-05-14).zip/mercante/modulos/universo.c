#include <string.h>

#include "planeta.h"
#include "status.h"
#include "robo.h"

int registro(char* nomePlaneta, char* chavePrivada) {
   int status = STATUS_SUCESSO;
   char complemento[100] = "registro ";

   adicionaPlaneta(nomePlaneta);
   strcat(complemento, nomePlaneta);

   monitorStatus(status, complemento);

   return status;
}
