#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#include "status.h"
#include "planeta.h"
#include "caixa.h"
#include "mercadoria.h"

static char* nomePlanetas[TOTAL_MAXIMO_PLANETAS] = {
   "Mantor",
   "Zintor",
   "Asdropolis",
   "Zeta",
   "Bantor",
   "Tander",
   "Nova",
   "Pindora",
   "Castor",
   "Ra",
   "Re",
   "Ri"
};

static RegPlaneta dadosPlanetas[TOTAL_MAXIMO_PLANETAS];

static int numeroPlanetas = TOTAL_INICIAL_PLANETAS;

int getNumeroPlanetas() {
   return numeroPlanetas;
}

char** getNomePlanetas() {
   return nomePlanetas;
}

char* getNomePlaneta(TipoPlaneta planeta) {
   char *nPlaneta = "Desconhecido";
   if (planeta >= 0 || planeta < numeroPlanetas)
      nPlaneta = nomePlanetas[planeta];
   return nPlaneta;
}

void iGetNomePlanetas() {
   puts("\n+-----------------+");
   puts(  "|   [PLANETAS]    |");
   puts(  "| nn | planeta    |");
   puts(  "+----+------------+");
   int p;
   for (p = 0; p < numeroPlanetas; p++)
      printf("| %2d | %-10s |\n", p, nomePlanetas[p]);
   puts(  "+-----------------+");
}

RegPlaneta* getDadosPlanetas() {
   return dadosPlanetas;
}

void inicializaPlanetas() {
   srand (time(NULL));

   int p;
   for (p = 0; p < numeroPlanetas; p++)
      dadosPlanetas[p].mercadorias = precosPlaneta();
}

RegMercadoriaPlaneta* precosPlaneta() {
   RegMercadoria *dadosMercadorias = getDadosMercadorias();

   RegMercadoriaPlaneta* mercadorias =
      malloc(sizeof(RegMercadoriaPlaneta)*TOTAL_MERCADORIAS);
   int m;
   for (m = 0; m < TOTAL_MERCADORIAS; m++) {
      mercadorias[m].preco =
         dadosMercadorias[m].basePreco +
         (rand() % dadosMercadorias[m].variacaoPreco);
      mercadorias[m].disponivel =
         dadosMercadorias[m].baseDisponivel +
         (rand() % dadosMercadorias[m].variacaoDisponivel);
   }
   return mercadorias;
}

void adicionaPlaneta(char *nomePlaneta) {
   char* np = malloc(strlen(nomePlaneta) + 1);
   strcpy(np, nomePlaneta);
   nomePlanetas[numeroPlanetas] = np;
   dadosPlanetas[numeroPlanetas].mercadorias = precosPlaneta();
   numeroPlanetas++;
}
