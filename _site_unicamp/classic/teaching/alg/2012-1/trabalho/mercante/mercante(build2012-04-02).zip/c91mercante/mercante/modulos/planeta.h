#define TOTAL_PLANETAS 12
#define PRECO_PASSAGEM  5

typedef enum {
   plaNada = -1,
   plaMantor,
   plaZintor,
   plaAsdropolis,
   plaZeta,
   plaBantor,
   plaTander,
   plaNova,
   plaPindora,
   plaCastor,
   plaRa,
   plaRe,
   plaRi
} TipoPlaneta;

typedef struct {
   int preco,
       disponivel;
} RegMercadoriaPlaneta;

typedef struct {
   RegMercadoriaPlaneta *mercadorias;
} RegPlaneta;

char** getNomePlanetas();
char* getNomePlaneta(TipoPlaneta planeta);
void iGetNomePlanetas();
RegPlaneta* getDadosPlanetas();
void inicializaPlanetas();
