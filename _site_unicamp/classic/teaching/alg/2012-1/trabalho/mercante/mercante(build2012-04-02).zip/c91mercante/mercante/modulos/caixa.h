int getSaldoCaixa();
int debitaCaixa(int valor);
int creditaCaixa(int valor);
