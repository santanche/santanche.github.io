#include "planeta.h"
#include "mercadoria.h"
#include "nave.h"
#include "interface.h"
#include "robo.h"
#include "programa.h"

int main() {
   inicializaPlanetas();
   inicializaNave();

   setEstadoMonitor(monitorAtivoBreve);
   programa();

   return 0;
}
