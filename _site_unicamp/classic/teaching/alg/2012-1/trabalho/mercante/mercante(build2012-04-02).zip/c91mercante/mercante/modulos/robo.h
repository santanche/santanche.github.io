typedef enum {
   monitorInativo,
   monitorAtivoBreve,
   monitorAtivoCompleto
} TipoMonitor;

int getEstadoMonitor();
int setEstadoMonitor(TipoMonitor estado);
void monitorStatus(int status, char *complemento);
int getPlanetaCorrente();
int viaja(TipoPlaneta destino);
void iViaja();
void iGetMercadoriasPlaneta();
int compraMercadoria(int quantidade);
void iCompraMercadoria();
int vendeMercadoria(int quantidade);
void iVendeMercadoria();


