#include "status.h"

static int saldoCaixa = 30000;

int getSaldoCaixa() {
   return saldoCaixa;
}

int debitaCaixa(int valor) {
   int status = STATUS_SUCESSO;
   if (valor < 0)
      status = STATUS_VALOR_INVALIDO;
   else if (saldoCaixa < valor)
      status = STATUS_SALDO_INSUFICIENTE;
   else
      saldoCaixa -= valor;
   return status;
}

int creditaCaixa(int valor) {
   int status = STATUS_SUCESSO;
   if (valor < 0)
      status = STATUS_VALOR_INVALIDO;
   else
      saldoCaixa += valor;
   return status;
}
